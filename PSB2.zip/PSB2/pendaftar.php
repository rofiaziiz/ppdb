	<?php
					$query=mysql_fetch_array(mysql_query("select * from konfigurasi where id='4'"));
					$nilai=$query['nilai'];
					$ab = $nilai;
					
					$query2=mysql_fetch_array(mysql_query("select * from konfigurasi where id='1'"));
					$get_limit=$query2['nilai'];
					

				if ($ab == 'Tampilkan')
				{
				?>
				<center>
					<h3>PENGUMUMAN PENGUMUMAN AKHIR</h3>
				</center>

					<table width="90%"align="center" border="2px black" >
					<thead>
						<tr bgcolor=orange>
							<th>Peringkat</th>
							<th>NISN</th>
							<th width=260>Nama</th>
							<th width=200>Asal Sekolah</th>
							<th>Total Nilai</th>
							<th>Ket.</th>
						</tr>
				</thead>
				<tbody>
				<?php
					$tahun = date('Y');
					
					$sql = mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4' ");
						
						$no=0;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>Diterima</td>';
								echo '</tr>';
							}
						?>
				</tbody>
				<tbody>
				<?php
					$tahun = date('Y');
					
					$unggulan=mysql_num_rows(mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4'"));
					
					$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata

							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$unggulan.",".$get_limit." ");
						
						$no=$unggulan;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>Diterima</td>';
								echo '</tr>';
							}
						?>
					</tbody>
					<tbody>
					<?php
						
						$limittolak = $get_limit + $unggulan;
						$tahun = date('Y');
							$sql = mysql_query("SELECT  biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata


							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$limittolak.",100000 ");
		
									$no=$get_limit + $unggulan;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
													echo '<td>Ditolak</td>';
											echo '</tr>';
										}
									?>
						</tbody>
					</table>
				<br>
				Ket. <br>
				- Bagi Siswa yang dinyatakan diterima, Silahkan datang ke sekolah smart cibinong untuk melakukan daftar ulang dan ujian pembagian kelas. 
				<?
				}	
				else 
				{
				echo'<h2>Jurnal Pendaftaran</h2>
				<p>Pada jurnal pendaftaran ini Anda dapat memantau peringkat terbaru PPDB.
					</p>';
				?>


				 <font color="black" size="2" >
				 <?
				 $th = date('Y');
				 $kuota=(mysql_query("SELECT * FROM biodata limit 3,1"));
				 $total=mysql_num_rows(mysql_query("SELECT * FROM biodata where   date_format(tgl_daftar,'%Y') = '$th'"));
				 $total_v=mysql_num_rows(mysql_query("SELECT * FROM biodata where verifikasi ='Sudah' AND date_format(tgl_daftar,'%Y') = '$th'"));
				 $d_kota=mysql_num_rows(mysql_query("SELECT * FROM biodata where   date_format(tgl_daftar,'%Y') = '$th' AND kabupaten ='wonogiri' OR kabupaten ='Wonogiri' OR kabupaten ='WONOGIRI' "));
				 ?>
				 <strong>
				<marquee direction="left">
				 Kuota Penerimaan Siswa Baru: 
					 <?php       
					 $sql = mysql_query("SELECT * FROM konfigurasi 
					limit 0,1 ");
					while ($tampil = mysql_fetch_array($sql)) {
					echo $tampil['nilai'];}
					?> Siswa -
					 Total Pendaftar: <?php echo $total; ?> Siswa - 
					 Calon Siswa Terverifikasi: <?php echo $total_v; ?> Siswa 
					 </font>
					 </marquee>
					 </strong>

					<table width="100%"align="center" border="2px black" >
					<thead>
						<tr bgcolor=orange>
							<th>Rank.</th>
							<th>NISN</th>
							<th width=260>Nama</th>
							<th width=200>Asal Sekolah</th>
							<th>Total Nilai</th>
							<th>Ket.</th>
						</tr>
				</thead>
				<tbody>
				<?php
					$tahun = date('Y');
				
					$unggulan=mysql_num_rows(mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4'"));
					
					$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata

							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit 0,".$get_limit." ");
						
						$no=$unggulan;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td bgcolor=gold></td>';
								echo '</tr>';
							}
						?>
					</tbody>
					<tbody>
					<?php
						
						$tahun = date('Y');
							$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata

							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$get_limit.",100000 ");
		
									$no=$get_limit + $unggulan;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
													echo '<td bgcolor=red></td>';
											echo '</tr>';
										}
									?>
						</tbody>
					</table>
									<br>
									Ket. <br>
									<img src="images/yel.png" width=27>: Kategori posisi aman<br>
									<img src="images/red.png" width=27>: Kategori posisi tidak aman<br>
									- Jurnal akan terus berubah sebelum pendaftaran ditutup.

						<?
						}
						?>