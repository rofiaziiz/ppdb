

<link rel="stylesheet" href="css/bootstrap.min" type="text/css" media="all">
<?php
$nisn=$_POST['nisn'];
$password=$_POST['password'];

$query=mysql_query("select * from biodata where nisn='$nisn' and password='$password'");
if(mysql_num_rows($query)==0)
{
$query=mysql_query("select * from biodata_tk where nisn='$nisn' and password='$password'");
}
if(mysql_num_rows($query)==0)
{
$query=mysql_query("select * from biodata_sd where nisn='$nisn' and password='$password'");
}

$cek=mysql_num_rows($query);
$row=mysql_fetch_array($query);
$id_utama=$row['id_utama'];

if($cek){
	$_SESSION['id_utama']=$id_utama;
	header('Location:home.php');
}else{
	?>


<h4><strong><img src="images/belum.png" width="20" height="20"> Maaf, NISN atau password anda salah. </strong></h4>
 Silahkan periksa kembali NISN dan password anda.<br>
 Atau silahkan menghubungi panitia untuk memperbaiki akun anda.

<br><br><br><br><br><br><br>

<br><br><br><br><br><br><br>

<br><br><br>




	<?php
}
?>