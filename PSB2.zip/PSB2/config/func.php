<?php
include"koneksi.php";

	function _get_limit_mhs(){
		$sql = "select * from konfigurasi where nama='limit_mahasiswa'";
		$res = mysql_query($sql);
		$row = mysql_fetch_array($res);
		
		$get_limit = $row['nilai'];
		return $get_limit;}
		
	function _get_limit_sd(){
		$sql = "select * from konfigurasi where nama='limit_sd'";
		$res = mysql_query($sql);
		$row = mysql_fetch_array($res);
		
		$get_limit_sd = $row['nilai'];
		return $get_limit_sd;}
		
	function _get_limit_tk(){
		$sql = "select * from konfigurasi where nama='limit_tk'";
		$res = mysql_query($sql);
		$row = mysql_fetch_array($res);
		
		$get_limit_tk = $row['nilai'];
		return $get_limit_tk;}
		
	function _get_limit_tgl(){
		$sql = "select * from konfigurasi where nama='limit_tanggal'";
		$res = mysql_query($sql);
		while ($tampil = mysql_fetch_array($res)) {
		
		$get_limit = $tampil['nilai'];
		}
		
		return $get_limit;
	}

?>