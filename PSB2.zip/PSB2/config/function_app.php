<?php 
$host="localhost";
$user="root";
$password="";
$database="psb2";



$koneksi=mysql_connect($host,$user,$password);
mysql_select_db($database,$koneksi);

if($koneksi){
	//echo "berhasil koneksi";
}else{
	echo "gagal koneksi";
}


function app($id)
 { 
 
$app_q = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = '$id'"));

 return $app_q['nilai'];
 } 

 ?>
 
 