<?php
$host="localhost";
$user="root";
$password="";
$database="psb2";



$koneksi=mysql_connect($host,$user,$password);
mysql_select_db($database,$koneksi);





?>