<img src="images/smanja.jpg" width="599" height="380" border="none" />
					<?php
					$sql = mysql_query("SELECT * FROM seting limit 3,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
					$art = ($tampil['nilai']);
						echo "
			
						";
						echo"

						<p>$art</p>
						 
				
						";
					;}
					?>