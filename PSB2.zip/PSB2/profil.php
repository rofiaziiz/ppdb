<h2>Data Pendaftar</h2>
<div id="main"> <a name="TemplateInfo"></a>

    <form action="?page=simpan_account" enctype="multipart/form-data"  method="post" name="postform">
    
    <?php
	$query=mysql_fetch_array(mysql_query("SELECT  * FROM biodata WHERE id_utama='$id_utama'"));
	$nama_depan=$query['nama'];
	$jenis_kel=$query['jenis_kel'];
	$tempat_lahir=$query['tempat_lahir'];
	$tgl_lahir=$query['tgl_lahir'];
	$agama=$query['agama'];
	$desa=$query['desa'];
	$kecamatan=$query['kecamatan'];
	$pass=$query['password'];
	$photo=$query['photo'];
	$telepon=$query['telepon'];
	$sekolah=$query['sekolah'];
	$nisn=$query['nisn'];
	$ayah=$query['ayah'];
	$kerja_ayah=$query['kerja_ayah'];
	$ibu=$query['ibu'];
	$penghasilan=$query['penghasilan'];
	$ind=$query['ind'];
	$ingg=$query['ingg'];
	$mat=$query['mat'];
	$ipa=$query['ipa'];
	$jumlah=$query['jumlah'];
	?>
  
    <table width="499" border="0">

     <tr>
      <td width="153"><strong>Nomor Pendaftaran</strong></td>
      <td width="1">&nbsp;</td>
      <td width="271"><span class="style1"><b><?php
					$sql = mysql_query("SELECT * FROM seting limit 5,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?><?php echo $id_utama; ?></span></b></td>
    </tr>
	<tr>
      <td width="113"><strong>NISN</strong></td>
      <td width="1">&nbsp;</td>
      <td width="271"><span class="style1"><?php echo $nisn; ?></span></td>
    </tr>
    <tr>
      <td width="113"><strong>Nama Lengkap</strong></td>
      <td width="1">&nbsp;</td>
      <td width="271"><span class="style1"><?php echo $nama; ?></span></td>
    </tr>
    <tr>
      <td><strong>Jenis Kelamin</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $jenis_kel; ?></span></td>
    </tr>
    <tr>
      <td><strong>TTL</strong></td>
      <td>&nbsp;</td>
	  <td><span class="style1"><?php echo $tempat_lahir. ' , '.$tgl_lahir; ?></span></td>    
    </tr>
     <tr>
      <td><strong>Agama</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $agama; ?></span></td>
    </tr>

    <tr>
      <td><strong>Alamat</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $desa;?></span>      </td>
    </tr>
    <tr>
      <td><strong>No. Telp</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $telepon;?></span>      </td>
    </tr>

    <tr>
      <td><strong>Sekolah Asal</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $sekolah;?></span>      </td>
    </tr>

       <tr>
      <td><strong>Nama Ayah</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $ayah;?></span>      </td>
    </tr>
        </tr>
       <tr>
      <td><strong>Pekerjaan Ayah</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $kerja_ayah;?></span>      </td>
    </tr>
    <tr>
      <td><strong>Nama Ibu</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $ibu;?></span>      </td>
    </tr>
    <tr>
      <td><strong>Penghasilan</strong></td>
      <td>&nbsp;</td>
      <td>
        <span class="style1"><?php echo $penghasilan;?></span>      </td>
    </tr>
<tr>
       <td><strong><center></center></strong></td>
      <td>&nbsp;</td>
    </tr>
	
	
	
	
<tr>
       <td><strong><center>NILAI UJIAN NASIONAL</center></strong></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Bahasa Indonesia</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $ind;?></span></td>
    </tr>
    <tr>
      <td><strong>Bahasa Inggris</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $ingg;?></span></td>
    </tr>
    <tr>
      <td><strong>Matematika</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $mat;?></span></td>
    </tr>
    <tr>
      <td><strong>IPA</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $ipa;?></span></td>
    </tr>
    <tr>
      <td><strong>Jumlah Nilai</strong></td>
      <td>&nbsp;</td>
      <td><span class="style1"><?php echo $jumlah;?></span></td>
    </tr>
    <tr>
      <td colspan="3"><p></p></td>
    </tr>
    </table>
    
  </form>
