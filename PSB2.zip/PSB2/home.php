<?php session_start();

if(isset($_SESSION['id_utama'])){
	include "config/koneksi.php";
	include "config/tanggal.php";
	include "config/inc.tanggal.php";
	include "config/batasnilai.php";
		include "config/function_app.php";
	
	if(isset($_GET['id_utama'])){
		$id_utama=$_GET['id_utama'];
	}
	
	if(empty($_GET['id_utama'])){
		$id_utama=$_SESSION['id_utama'];
	}
	
	$query=mysql_fetch_array(mysql_query("SELECT * FROM biodata where id_utama='$id_utama'"));
	
	$nama=$query['nama'];
	$sekolah=$query['sekolah'];
	$mat=$query['mat'];
	$nisn=$query['nisn'];
	$jenis_kel=$query['jenis_kel'];
	$verifikasi=$query['verifikasi'];
	$photo=$query['photo'];
	$jumlah=$query['jumlah'];
	$prestasi=$query['prestasi'];
?>
<!DOCTYPE html>
<html>
	<head>
		<title>PPDB Online  - <?php echo ucwords($nama);?></title>
		    <meta charset="utf-8">


		   
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="stylesheet" href="css/user.css" type="text/css" />
        <link rel="shortcut icon" href="images/logo2c.png" type="image/x-icon">
		<script>
		$(function() {
			$("#tgl").datepicker({ dateFormat :'yy-mm-dd', minDate : 0, maxDate: "1W + 0D"}).val();
		});
		</script>
    
    <link rel="stylesheet" href="media/css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="media/css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="media/css/style.css" type="text/css" media="all">
<script type="text/javascript" src="media/js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="media/js/cufon-yui.js"></script>
<script type="text/javascript" src="media/js/cufon-replace.js"></script>
<script type="text/javascript" src="media/js/Molengo_400.font.js"></script>
<script type="text/javascript" src="media/js/Expletus_Sans_400.font.js"></script>

	</head>
	<body id="page3">
<div class="body1">
  <div class="main">
    <!-- header -->
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
                      <?php
						$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama = 'halaman' AND nilai_d = '2' OR nilai_d = '3' ORDER BY nilai_c ASC");
							while ($tampil = mysql_fetch_array($sql)) {
							echo '<li><a href="?page=hal&id='.$tampil['id'].'">'.$tampil['nilai'].'</a></li>';
						
						}
						?>

                    </ul>

      </div>
      <div class="wrapper">
        <h1><a href="home.php" id="logo">Learn Center</a></h1>
      </div>
      <div id="slogan">PPDB Online<span>Sekolah Smart Cibinong</span> </div>
      <ul class="banners">

      </ul>
    </header>
	
		 
  </div>
</div>
<div class="body2">
  <div class="main">
    <!-- content -->
    <section id="content">
      <div class="box1">
        <div class="wrapper">
		<article class="col1">
            <div class="pad_left1">

			  <p class="pad_bot1 pad_top2">
				<?php 
				if(isset($_GET['page'])){
					$page=htmlentities($_GET['page']);
				}else{
					$page="home-user";
				}
				
				$file="$page.php";
				$cek=strlen($page);
				
				if($cek>30 || !file_exists($file) || empty($page)){
					include ("home-user.php?page=hal&id=29");
				}else{
					include ($file);
				}
				?>
				</p>
		</div>
		</article>
		
		 <article class="col2 pad_left2">

					<div id="nama">
					 <h3 align=center>Informasi Calon Peserta Didik</h3>
			<img id="foto-peserta" src="./photo/<?php echo $photo;?>" width="110" height="130" style="border:none"/>
			
			 <table><br>
			 <?php
	// $query=mysql_fetch_array(mysql_query("select * from biodata inner join biodata_tk inner join biodata_sd where id_utama='$id_utama'"));
	// $verifikasi=$query['verifikasi'];
	if ($verifikasi == 'Sudah'){
		echo 'Anda telah melakukan verifikasi berkas';
	} else {
		echo 'Anda belum melakukan verifikasi berkas';
		
	}
	?>
			 <tr>
				<td><b>Nama</b></td>
				<td>: <?php echo $nama; ?> </td>
			</tr>
			 <tr>
				<td><b>No. Daftar</b></td>
				<td>:<?php
					$sql = mysql_query("SELECT * FROM seting limit 5,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?><?php echo $id_utama; ?></td>
			</tr>
			<tr>
				<td><b>NISN</b></td>
				<td>: <?php echo $nisn; ?> </td>
			</tr>
			<tr>
				<td><b>Asal Sekolah</b></td>
				<td>: <?php echo $sekolah; ?> </td>
			</tr>

			
			</table><br>
			</div>
            <ul class="list1">

            	<?php 

            	if($verifikasi == 'Sudah'){ ?>
            	 <li><a href="cetak/kartu/siswa.cetak.php?id=<?php echo $id_utama; ?>" target="_blank">Cetak Kartu Pendaftaran</a></li>	
            	 <?php
            	}

            	?>
             
			  <li><a href="home.php?page=profil">Biodata</a></li>
			  
			  	<?php
				$get_nilai = _get_limit_nilai();
				$query=mysql_fetch_array(mysql_query("select * from biodata where id_utama='$id_utama'"));
				$prestasi=$query['prestasi'];
				$nilaiprestasi = $prestasi;

				$nilaisiswa =  $jumlah + $prestasi;  
				if($nilaisiswa >= $get_nilai ){
				?>

				 <!-- <li><a href="home.php?page=ujian">Ujian Seleksi Kelas</a></li> -->
				<?php
				}
				else{
				}
				?>

              <li><a href="logout.php" onClick="return confirm('Apakah Anda yakin akan keluar?')">Logout</a></li>
            </ul>

			</article>
                      
               

   </div>
      </div>
    </section>
    <!-- content -->
    <!-- footer -->
    <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_7">
                <h3>Alamat:</h3>
                <p class="col_address"> 
                  Alamat:<br>
                  Email: </strong> </p>
                  <?php echo app('skl_alamat'); ?><br>
                  <?php echo app('skl_email'); ?></p>
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Telepon Interaktif: </span><span class="call2"><?php echo app('skl_telp'); ?></span> </article>
              <article class="col_5 pad_left2">Copyright &copy; <a href="#"><?php echo app('skl_nama'); ?></a> All Rights Reserved<br>
                Owner : <a target="_blank" href="#">Cahya Adi Saputra</a></article>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- / footer -->
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
                    
    				
    		

	</body>
</html>

<?php

}else{
	header("Location:index.php?status=denied");
}
?>