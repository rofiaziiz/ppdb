<?php
include"../config/koneksi.php";
include "../config/func.php";
?>

<html>
<head>
    <meta charset="utf-8">
	<title>Jurnal - PPDB Online SMA N 1 Jatisrono</title>
    <link rel="stylesheet" href="../media/css/reset.css" type="text/css" media="all">
	<link rel="stylesheet" href="../media/css/layout.css" type="text/css" media="all">
	<link rel="stylesheet" href="../media/css/style.css" type="text/css" media="all">
	<script type="text/javascript" src="../media/js/jquery-1.5.2.js" ></script>
	<script type="text/javascript" src="../media/js/cufon-yui.js"></script>
	<script type="text/javascript" src="../media/js/cufon-replace.js"></script>
	<script type="text/javascript" src="../media/js/Molengo_400.font.js"></script>
	<script type="text/javascript" src="../media/js/Expletus_Sans_400.font.js"></script>
	<script src="../admin/media/js/jquery.js"></script>
    <script src="../admin/media/js/jquery.dataTables.js"></script>
</script>
<script type="text/javascript" src="../js/jquery-1.3.1.min.js"></script>
</head>
<body id="page3">
	<div class="body1">
		<div class="main">
		<header>
				<div class="wrapper">
					<nav>
					  <ul id="menu">
						<li><a href="../home.php">Home</a></li>
						<li><a href="../home.php?page=welcome">Berita</a></li>
						<li><a href="../home.php?page=sekolah.info">Informasi Pendaftaran</a></li>
						<li><a href="#">Jurnal & Pendaftaran</a></li>
						<li><a href="../home.php?page=sekolah.profil">Profil Sekolah</a></li>
					  </ul>
				</div>
		<div class="wrapper">
			<h1><a href="#" id="logo">Learn Center</a></h1>
		</div>
		<div id="slogan"> PPDB Online<span>SMA N 1 Jatisrono</span> </div>
    </header>
	</div>
</div>
<div class="body5">
  <div class="main">
    <section id="content">
	      <div class="box1">
			<div class="wrapper">
					<?php
					$query=mysql_fetch_array(mysql_query("select * from konfigurasi where id='4'"));
					$nilai=$query['nilai'];
					$ab = $nilai;

				if ($ab == 'Tampilkan')
				{
				?>
				<img src="kop.jpg" width="90%">

					<table width="90%"align="center" border="2px black" >
					<thead>
						<tr bgcolor=orange>
							<th>Peringkat</th>
							<th>NISN</th>
							<th width=260>Nama</th>
							<th width=200>Asal Sekolah</th>
							<th>Total Nilai</th>
							<th>Ket.</th>
						</tr>
				</thead>
				<tbody>
				<?php
					$tahun = date('Y');
					$get_limit = _get_limit_mhs();
					$sql = mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4' ");
						
						$no=0;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>Diterima</td>';
								echo '</tr>';
							}
						?>
				</tbody>
				<tbody>
				<?php
					$tahun = date('Y');
					$get_limit = _get_limit_mhs();
					$unggulan=mysql_num_rows(mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4'"));
					
					$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata

							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$unggulan.",".$get_limit." ");

							$no=$unggulan;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>Diterima</td>';
								echo '</tr>';
							}
						?>
					</tbody>
					<tbody>
					<?php
						$get_limit = _get_limit_mhs();
						$limittolak = $get_limit + $unggulan;
						$tahun = date('Y');
							$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata

							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$limittolak.",100000 ");
		
									$no=$get_limit + $unggulan;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
													echo '<td>Ditolak</td>';
											echo '</tr>';
										}
									?>
						</tbody>
					</table>
				<br>
				Ket. <br>
				- Bagi Siswa yang dinyatakan diterima, Silahkan datang ke SMA Negeri 1 Jatisrono untuk melakukan daftar ulang dan ujian pembagian kelas. 
				<?
				}	
				else 
				{
				echo'<h2>Jurnal Pendaftaran</h2>
				<p>Pada jurnal pendaftaran ini Anda dapat memantau peringkat terbaru PPDB.
					</p>';
				?>

				<div id="run">
				 <font color="black" size="2" >
				 <?
				 $th = date('Y');
				 $kuota=(mysql_query("SELECT * FROM biodata limit 3,1"));
				 $total=mysql_num_rows(mysql_query("SELECT * FROM biodata where   date_format(tgl_daftar,'%Y') = '$th'"));
				 $total_v=mysql_num_rows(mysql_query("SELECT * FROM biodata where verifikasi ='Sudah' AND date_format(tgl_daftar,'%Y') = '$th'"));
				 $d_kota=mysql_num_rows(mysql_query("SELECT * FROM biodata where   date_format(tgl_daftar,'%Y') = '$th' AND kabupaten ='wonogiri' OR kabupaten ='Wonogiri' OR kabupaten ='WONOGIRI' "));
				 ?>
				 <strong>
				<marquee direction="left">
				 <img src="../images/qa.png" width=20> Kuota Penerimaan Siswa Baru: 
					 <?php       
					 $sql = mysql_query("SELECT * FROM konfigurasi 
					limit 0,1 ");
					while ($tampil = mysql_fetch_array($sql)) {
					echo $tampil['nilai'];}
					?> Siswa <img src="../images/qa.png" width=20> 
					 Total Pendaftar: <?= $total ?> Siswa <img src="../images/qa.png" width=20> 
					 Calon Siswa Terverifikasi: <?= $total_v ?> Siswa <img src="../images/qa.png" width=20> 
					 Calon Siswa Dalam Kota: <?= $d_kota ?> Siswa <img src="../images/qa.png" width=20> 
					 </font>
					 </marquee>
					 </strong>
					</div>
					<img id="info" src="../images/run.gif" width=20>
					<table width="90%"align="center" border="2px black" >
					<thead>
						<tr bgcolor=orange>
							<th>Peringkat</th>
							<th>NISN</th>
							<th width=260>Nama</th>
							<th width=200>Asal Sekolah</th>
							<th>Total Nilai</th>
							<th>Ket.</th>
						</tr>
				</thead>
				<tbody>
				<?php
					$tahun = date('Y');
					$get_limit = _get_limit_mhs();
					$sql = mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4' ");
						
						$no=0;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td bgcolor=green></td>';
								echo '</tr>';
							}
						?>
				</tbody>
				<tbody>
				<?php
					$tahun = date('Y');
					$get_limit = _get_limit_mhs();
					$unggulan=mysql_num_rows(mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4'"));
					
					$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata
							
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$unggulan.",".$get_limit." ");
						
						$no=$unggulan;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td bgcolor=gold></td>';
								echo '</tr>';
							}
						?>
					</tbody>
					<tbody>
					<?php
						$get_limit = _get_limit_mhs();
						$limittolak = $get_limit + $unggulan;
						$tahun = date('Y');
							$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata


							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$limittolak.",100000 ");
		
									$no=$get_limit + $unggulan;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
													echo '<td bgcolor=red></td>';
											echo '</tr>';
										}
									?>
						</tbody>
					</table>
									<br>
									Ket. <br>
									<img src="../images/gre.png" width=27>: Kategori posisi unggulan (Langsung Diterima)<br>
									<img src="../images/yel.png" width=27>: Kategori posisi aman<br>
									<img src="../images/red.png" width=27>: Kategori posisi tidak aman<br>
									- Jurnal akan terus berubah sebelum pendaftaran ditutup

						<?
						}
						?>
</body>
</html>
