<?php
include"../config/koneksi.php";
require('html2fpdf.php');
include "../config/func.php";
?>
<html>
<head>
	<title>Pengumuman PPDB SMA Negeri 1 Jatisrono</title>
</head>
<body>
	<img src="kop.jpg" width="90%">

	<table width="90%"align="center" border="2px black" >
		<thead>
						<tr bgcolor=orange>
							<th>Peringkat</th>
							<th>NISN</th>
							<th width=260>Nama</th>
							<th width=200>Asal Sekolah</th>
							<th>Total Nilai</th>
							<th>Ket.</th>
						</tr>
				</thead>
				<tbody>
				<?php
					$tahun = date('Y');
					$get_limit = _get_limit_mhs();
					$sql = mysql_query("SELECT biodata.*, prestasi.nilai AS prestasi
						FROM biodata
						
						LEFT JOIN prestasi
						ON prestasi.id_prestasi = biodata.id_prestasi
						
						WHERE  biodata.verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' GROUP BY biodata.id_utama
				 
						ORDER BY biodata.id_prestasi = '1IJ1' DESC, biodata.id_prestasi = '2IJ2' DESC, 
						biodata.id_prestasi = '3IJ3' DESC,biodata.id_prestasi = '4NJ1' DESC, SUM(prestasi+biodata.jumlah) DESC, biodata.ipa DESC
						limit 0,".$get_limit." ");
						
						$no=0;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>Diterima</td>';
								echo '</tr>';
							}
						?>
					</tbody>
					<tbody>
					<?php
						$get_limit = _get_limit_mhs();
						$tahun = date('Y');
						$sql = mysql_query("SELECT biodata.*, prestasi.nilai AS prestasi
									FROM biodata
									
									LEFT JOIN prestasi
									ON prestasi.id_prestasi = biodata.id_prestasi
									
									WHERE date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND  biodata.verifikasi = 'Sudah'  GROUP BY biodata.id_utama
									ORDER BY biodata.id_prestasi = '1IJ1' DESC, biodata.id_prestasi = '2IJ2' DESC, 
									biodata.id_prestasi = '3IJ3' DESC,biodata.id_prestasi = '4NJ1' DESC, SUM(prestasi+biodata.jumlah) DESC, biodata.ipa DESC
									limit ".$get_limit.",100000 ");
		
									$no=$get_limit;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
													echo '<td>Ditolak</td>';
											echo '</tr>';
										}
									?>
						</tbody>
	
	</table>
	<br>
	Ket. <br>
	Siswa yang masuk dalam kategori Unggulan adalah siswa yang mempunyai prestasi di Tingkat Internasional dan Nasional Juara 1.
</body>
</html>
<?php
// Output-Buffer in variable:
$html=ob_get_contents();
ob_end_clean();
$pdf=new HTML2FPDF();
$pdf->AddPage();
$pdf->WriteHTML($html);
if (preg_match("/MSIE/i", $_SERVER["HTTP_USER_AGENT"])){
    header("Content-type: application/PDF");
} else {
    header("Content-type: application/PDF");
    header("Content-Type: application/pdf");
}
$pdf->Output("sample2.pdf","I");
?>