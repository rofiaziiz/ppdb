 <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
		<th>No.</th>
		<th>No. Daftar</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>Asal Sekolah</th>
		<th>Jumlah Nilai</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
	<?php
$get_isi = mysql_fetch_array(mysql_query("SELECT * FROM seting where id = '1' "));
		$blnth = date('Y');

		

			$sql = mysql_query("SELECT * FROM biodata
			
			WHERE date_format(tgl_daftar,'%Y') = '$blnth'
			order by jumlah DESC
			");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
			$no++;
			if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
			echo '<tr bgcolor='.$warna.'>';
				echo '<td>' .$no.'</td>';
				echo '<td>'.$tampil['id_utama'].'</td>';
				echo '<td>'.$tampil['nisn'].'</td>';
				echo '<td>'.$tampil['nama'].'</td>';
				echo '<td>'.$tampil['sekolah'].'</td>';
				echo '<td>'.$tampil['jumlah'].'</td>';

				echo '</tr>';
			}
	?>
    </tbody>
    </table>
	<?
echo $get_isi['nama'];
?>