<div>
<?php
if(isset($_SESSION['id_utama'])){
?>


    <?php
	$query=mysql_fetch_array(mysql_query("SELECT  * FROM biodata WHERE id_utama='$id_utama'"));
	$nama=$query['nama'];
	$utama=$query['id_utama'];
	$sekolah=$query['sekolah'];

	?>	
	

	
	<?php
	if(isset($_POST['submit'])){
	
$id_user=$_POST['id_user'];
		$benar=$_POST['benar'];
		$salah=$_POST['salah'];
		$kosong=$_POST['kosong'];
		$point=$_POST['point'];
		$tanggal=date("Y-m-d");
		
		$query=mysql_query("insert into tabel_nilai values('',' $id_user','$benar','$salah','$kosong','$point','$tanggal')");
		
		if($query){
			?>
				<script type="text/javascript">
		alert("Jawaban berhasil disimpan");
	</script><?
echo "<meta http-equiv='refresh' content='0; url=home.php'>"; ?><?php
		}else{
			?>
			<h3><img src="images/belum.png" width=30 height=30> Maaf... </h3>
			<p>Anda sudah melakukan Ujian Seleksi Pembagian Kelas. Anda hanya diperkenankan untuk mengikuti 1 kali ujian.</p><?
			
		}
		
	}
	?>
	
<?php
}else{
	?><p>Anda belum login. silahkan <a href="index.php">Login</a></p><?php
}
?>
</div>