
<?php
session_start();
include "../config/koneksi.php";
include "../config/tanggal.php";

date_default_timezone_set("Asia/Jakarta");

if($_GET) {
	$id	= $_GET['id'];
	$mySql	= "SELECT * FROM biodata

WHERE id_utama='$id'";
	$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
	$myData	= mysql_fetch_array($myQry);
	}
?>
<?php

	if(isset($_GET['id'])){
		$id_user=$_GET['id'];
	}
	
	if(empty($_GET['id'])){
		$id_user=$_SESSION['id'];
	}
$query=mysql_fetch_array(mysql_query("select * from biodata where id_utama='$id'"));



$photo=$query['photo'];
?>
<html>
<head>
<title>:: Cetak Data Siswa</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="cetak.css" rel="stylesheet" type="text/css">
</head>
<body onLoad="window.print()">

<section id="judul">
<img id="logo" src="qa.png" width="100" height="100">
<h2>PANITIA PENERIMAAN SISWA BARU<br>
SMA NEGERI 1 JATISRONO</h2>
<p>Alamat: Jl. Wonogiri - Ponorogo km 40</p>
</section>
<section id="isi">

<h1>DATA SISWA </h1>
  <img id="foto-peserta" src="../photo/<?php echo $photo;?>" width="110" height="130" style="border:none"/>
  <table width="600" border="0" cellpadding="3" cellspacing="1">
	<tr>
		<td><strong />No. Daftar</td>
		<td><strong />:</td>
		<td><?php
					$sql = mysql_query("SELECT * FROM seting limit 5,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?><?php echo $myData['id_utama']; ?></td>
	</tr>
	

	<tr>
		<td><strong />Nama Lengkap</td>
		<td><strong />:</td>
		<td><?php echo $myData['nama']; ?></td>
	</tr>
	<tr>
		<td><strong />Jenis Kelamin</td>
		<td><strong />:</td>
		<td><?php echo $myData['jenis_kel']; ?></td>
	</tr>
	<tr>
		<td><strong />Tempat, Tgl Lahir</td>
		<td><strong />:</td>
		<td><?php echo $myData['tempat_lahir']. ' ,' .$myData['tgl_lahir']; ?></td>
	</tr>
	<tr>
		<td><strong />Agama</td>
		<td><strong />:</td>
		<td><?php echo $myData['agama']; ?></td>
	</tr>

	<tr>
		<td><strong />Alamat</td>
		<td><strong />:</td>
		<td><?php echo $myData['desa'];?>, <?php echo $myData['kecamatan'];?>, <?php echo $myData['kabupaten'];?>, <?php echo $myData['provinsi'];?></td>
	</tr>
	<tr>
		<td><strong />No. Telp</td>
		<td><strong />:</td>
		<td><?php echo $myData['telepon']; ?></td>
	</tr>
	<tr>
		<td><strong />Sekolah Asal</td>
		<td><strong />:</td>
		<td><?php echo $myData['sekolah']; ?></td>
	</tr>
	<tr>
		<td><h3>DAFTAR NILAI</h3></td>
	</tr>
	<tr>
		<td><strong />B. Indonesia</td>
		<td><strong />:</td>
		<td><?php echo $myData['ind']; ?></td>
	</tr>
	<tr>
		<td><strong />B. Inggris</td>
		<td><strong />:</td>
		<td><?php echo $myData['ingg']; ?></td>
	</tr>
	<tr>
		<td><strong />Matematika</td>
		<td><strong />:</td>
		<td><?php echo $myData['mat']; ?></td>
	</tr>
	<tr>
		<td><strong />IPA</td>
		<td><strong />:</td>
		<td><?php echo $myData['ipa']; ?></td>
	</tr>
	<tr>
		<td><strong />Jumlah NIlai</td>
		<td><strong />:</td>
		<td><?php echo $myData['jumlah']; ?></td>
	</tr>
	<tr>
		<td><h3>DATA ORANG TUA/WALI</h3></td>
	</tr>
	<tr>
		<td><b>Nama Ayah</b></td>
		<td><b>:</b></td>
		<td><?php echo $myData['ayah']; ?></td>
	</tr>
	<tr>
		<td><b>Pekerjaan Ayah</b></td>
		<td><b>:</b></td>
		<td><?php echo $myData['kerja_ayah'];?></td>
	</tr>
		<tr>
		<td><b>Nama Ibu</b></td>
		<td><b>:</b></td>
		<td><?php echo $myData['ibu']; ?></td>
	</tr>

	<tr>
		<td><b>Penghasilan</b></td>
		<td><b>:</b></td>
		<td>Rp. <?php echo $myData['penghasilan']; ?>,00-</td>
	</tr>
</table>
</section>
</body>
</html>
