
<?php
session_start();
include "../../config/koneksi.php";
include "../../config/tanggal.php";
include "fungsi_indotgl.php";
date_default_timezone_set("Asia/Jakarta");

if($_GET) {
	$id	= $_GET['id'];
	$mySql	= "SELECT * FROM biodata


WHERE id_utama='$id'";
	$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
	$myData	= mysql_fetch_array($myQry);
	}
	

?>
<?php

	if(isset($_GET['id'])){
		$id_user=$_GET['id'];
	}
	
	if(empty($_GET['id'])){
		$id_user=$_SESSION['id'];
	}
$query=mysql_fetch_array(mysql_query("select * from biodata where id_utama='$id'"));



$photo=$query['photo'];


?>
<html>
<head>
<title>Cetak Kartu </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="cetak.css" rel="stylesheet" type="text/css">
</head>
<body onLoad="window.print()">

<section id="judul">
<img id="logo" src="qa.png" width="130" height="130">
<h4>PEMERINTAH KABUPATEN WONOGIRI</h4>
<h2>DINAS PENDIDIKAN<br>
SMA NEGERI 1 JATISRONO</h2>
<p>Jl. Wonogiri - Ponorogo km 40</p>
<img src="garis.png" width="800" height="3">
</section>
<section id="judul">

<h3>KARTU PENDAFTARAN<br>
CALON PESERTA DIDIK BARU<br>
TAHUN PELAJARAN <?php
					$sql = mysql_query("SELECT * FROM seting limit 6,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?></h3>
</section>

<section id="isi">
<br>
  <img id="foto-cetak" src="../../photo/<?php echo $photo;?>" width="110" height="130" style="border="2"""/>
	<div id="n-daftar" ><p>No. Pendaftaran</p><h2><?php
					$sql = mysql_query("SELECT * FROM seting limit 5,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?><?php echo $myData['id_utama']; ?></h2></div>

  <table id="form" width="600" border="0" cellpadding="3" cellspacing="1">
	<tr>
		<td width="200"><strong />Nama Calon Peserta Didik</td>
		<td><strong />:</td>
		<td><?php echo $myData['nama']; ?></td>
	</tr>
	<tr>
		<td><strong />Alamat</td>
		<td><strong />:</td>
		<td><?php echo $myData['desa']; ?>, <?php echo $myData['kecamatan']; ?>, <?php echo $myData['kabupaten']; ?>, <?php echo $myData['provinsi']; ?></td>
	</tr>
	<tr>
		<td><strong />Sekolah Asal</td>
		<td><strong />:</td>
		<td><?php echo $myData['sekolah']; ?></td>
	</tr>
	<tr>
		<td><strong />Jumlah Nilai UN</td>
		<td><strong />:</td>
		<td><?php echo $myData['jumlah']; ?></td>
	</tr>

</table>
<div id="ttd" ><p>Jatisrono, ...........................<br>Petugas Pendaftaran
</p><br><br><h4><?php
					$sql = mysql_query("SELECT * FROM seting limit 7,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?><br>NIP. <?php
					$sql = mysql_query("SELECT * FROM seting limit 8,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
						";
						echo"
						$tampil[nilai]";
					;}
					?></h4></div>
<div id="ket">
Keterangan :
<ul>
<li>Simpan Kartu ini baik-baik!
<li>Segeralah melakukan verifikasi berkas sebelum batas akhir penutupan pendaftaran

</ul>
</div>
</section>
</body>
</html>
