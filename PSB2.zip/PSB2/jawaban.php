<div>
<?php
if(isset($_SESSION['id_utama'])){
?>
    <?php
	$query=mysql_fetch_array(mysql_query("SELECT  * FROM biodata WHERE id_utama='$id_utama'"));
	$nama=$query['nama'];
	$utama=$query['id_utama'];
	$sekolah=$query['sekolah'];

	?>	


   <h2><h3><img src="images/sudah.png" width=30 height=30> Terima Kasih <?php echo ucwords($nama);?></h3>
			<p>Anda telah menyelesaikan Ujian Seleksi Pembagian Kelas <br>
			Silahkan klik <strong>Simpan Nilai</strong> untuk menyimpan jawaban anda!</p>
      

        
	   <?php 
       if(isset($_POST['submit'])){
			$pilihan=$_POST["pilihan"];
			$id_soal=$_POST["id"];
			$jumlah=$_POST['jumlah'];
			
			$score=0;
			$benar=0;
			$salah=0;
			$kosong=0;
			
			for ($i=0;$i<$jumlah;$i++){
				//id nomor soal
				$nomor=$id_soal[$i];
				
				//jika user tidak memilih jawaban
				if (empty($pilihan[$nomor])){
					$kosong++;
				}else{
					//jawaban dari user
					$jawaban=$pilihan[$nomor];
					
					//cocokan jawaban user dengan jawaban di database
					$query=mysql_query("select * from tabel_soal where id_soal='$nomor' and jawaban='$jawaban'");
					
					$cek=mysql_num_rows($query);
					
					if($cek){
						//jika jawaban cocok (benar)
						$benar++;
					}else{
						//jika salah
						$salah++;
					}
					
				} 
				$score = $benar*5;
			}
		}
		?>
        <form action="?page=simpan" method="post">
		<table width="100%" border="0">
		<tr>
			<td width="12%"></font></td><td width="88%" hidden>= <?php echo $benar;?> soal x 5 point</font></td>
		</tr>
		<tr>
			<td></font></td><td hidden> = <?php echo $salah;?> soal </font></td>
		</tr>
		<tr>
			<td></font></td><td hidden>= <?php echo $kosong;?> soal </font></td>
		</tr>
		<tr>
			<td></font></td><td hidden>= <b><?php echo $score;?></b> Point</font></td>
		</tr>
		</table> 
        
        <input type="hidden" name="id_user" value="<?php echo $id_utama;?>" />
        <input type="hidden" name="benar" value="<?php echo $benar;?>" />
        <input type="hidden" name="salah" value="<?php echo $salah;?>" />
        <input type="hidden" name="kosong" value="<?php echo $kosong;?>" />
        <input type="hidden" name="point" value="<?php echo $score;?>" />
        <p></p>
        <input type="submit" name="submit" value="Simpan Nilai" onclick="return confirm('Apakah Anda yakin akan menyimpan nilai ujian?')"/>
        
        </form> 
		
<?php
}else{
	?><p>Anda belum login. silahkan <a href="index.php">Login</a></p><?php
}
?>
</div>
