<?php
$id	= $_GET['id'];
$query = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE id = '$id'"));
echo $query['nilai_b'];

?>