<form id="newsletter" role="form"  method="post" class="search" action="?page=login">
                  <div class="wrapper">
					<div  class="wrapper"> 
						<strong>NISN:</strong>
						<div class="bg">
						  <input type="text" name="nisn"  size="20" class="form-control" placeholder="Masukkan NISN anda">
						</div>
					</div>
					<div  class="wrapper"> <strong>Password:</strong>
						<div class="bg">
						<input type="password" name="password"  size="40" class="form-control" placeholder="Masukkan password anda">
						</div>
                  </div>
                  </div>
                  <button  type="submit" value="Login" name="Simpan" class="button marg_top2">Lanjutkan</button>
                </form>