<?php
include "config/library.php";
$sql = "select * from konfigurasi where nama='limit_ujian'";
$res = mysql_query($sql);
	while ($tampil = mysql_fetch_array($res)) {

$masaaktif = $tampil['nilai'];
$sekarang =date('Y-m-d');

if($sekarang<$masaaktif){
?>
    <?php
	$query=mysql_fetch_array(mysql_query("SELECT  * FROM biodata WHERE id_utama='$id_utama'"));
	$nama=$query['nama'];
	$utama=$query['id_utama'];
	$sekolah=$query['sekolah'];

	?>	

	<style>
	#judul {
	background-color:yellow;
	font-size:24px;
	margin-right:-40px;
	margin-left:40px;
	

	padding-top:11px;

	
color:black;

	}
	#peserta {
	margin-right:-40px;
	margin-left:40px;
	background-color:yellow;
	border-radius:11px;
	padding:6px;
	
	}
	
	</style>
	
	<script>
var waktunya;
waktunya = 60;
var waktu;
var jalan = 0;
var habis = 0;
function init(){
    checkCookie()
    mulai();
}
function keluar(){
    if(habis==0){
        setCookie('waktux',waktu,365);
    }else{
        setCookie('waktux',0,-1);
    }
}
function mulai(){
    jam = Math.floor(waktu/3600);
    sisa = waktu%3600;
    menit = Math.floor(sisa/60);
    sisa2 = sisa%60
    detik = sisa2%60;
    if(detik<10){
        detikx = "0"+detik;
    }else{
        detikx = detik;
    }
    if(menit<10){
        menitx = "0"+menit;
    }else{
        menitx = menit;
    }
    if(jam<10){
        jamx = "0"+jam;
    }else{
        jamx = jam;
    }
    document.getElementById("divwaktu").innerHTML = jamx+"  : "+menitx+"  : "+detikx +" ";
    waktu --;
    if(waktu>0){
        t = setTimeout("mulai()",1000);
        jalan = 1;
    }else{
        if(jalan==1){
            clearTimeout(t);
        }
        habis = 1;
        document.getElementById("formulir").submit();
    }
}
function selesai(){    
    if(jalan==1){
            clearTimeout(t);
        }
        habis = 1;
    document.getElementById("formulir").submit();
}
function getCookie(c_name){
    if (document.cookie.length>0){
        c_start=document.cookie.indexOf(c_name + "=");
        if (c_start!=-1){
            c_start=c_start + c_name.length+1;
            c_end=document.cookie.indexOf(";",c_start);
            if (c_end==-1) c_end=document.cookie.length;
            return unescape(document.cookie.substring(c_start,c_end));
        }
    }
    return "";
}

function setCookie(c_name,value,expiredays){
    var exdate=new Date();
    exdate.setDate(exdate.getDate()+expiredays);
    document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString());
}

function checkCookie(){
    waktuy=getCookie('waktux');
    if (waktuy!=null && waktuy!=""){
        waktu = waktuy;
    }else{
        waktu = waktunya;
        setCookie('waktux',waktunya,7);
    }
}

</script>
		<h2>Ujian Seleksi Pembagian Kelas</h2>
		<h2><div id=divwaktu></div></h2>
		
		<table>
			<tr>
		<td width="50"><strong />NISN</td>
		<td><strong />:</td>
		<td> <?php echo $nisn; ?></td>
		<td width="130"></td>
		<td width="90"><strong />Asal Sekolah</td>
		<td><strong />:</td>
		<td> <?php echo $sekolah; ?></td>
		
			</tr>
			<tr>
		<td ><strong />Nama</td>
		<td><strong />:</td>
		<td> <?php echo $nama; ?></td>
		
		<td width="130"></td>
		<td width="50"><strong />Nama</td>
		<td><strong />:</td>
		<td> 120 Menit</td>
			</tr>
			

		
		
		
		</table>
		
		</div>
        <p>
        <?php
		$hasil=mysql_query("select * from tabel_soal where publish='yes'");
		$jumlah=mysql_num_rows($hasil);
		$urut=0;
		while($row =mysql_fetch_array($hasil))
		{
			$id=$row["id_soal"];
			$pertanyaan=$row["pertanyaan"];
			$pilihan_a=$row["pilihan_a"];
			$pilihan_b=$row["pilihan_b"];
			$pilihan_c=$row["pilihan_c"];
			$pilihan_d=$row["pilihan_d"]; 
			
			?>
			<form name="form1" method="post" action="?page=jawaban">
			<input type="hidden" name="id[]" value=<?php echo $id; ?>>
			<input type="hidden" name="jumlah" value=<?php echo $jumlah; ?>>
		<div id="peserkta">
		<p><strong><?php echo $urut=$urut+1; ?>. <?php echo "$pertanyaan"; ?></strong>
		<br><input name="pilihan[<?php echo $id; ?>]" type="radio" value="A">  <?php echo "$pilihan_a";?>
		<br><input name="pilihan[<?php echo $id; ?>]" type="radio" value="B">  <?php echo "$pilihan_b";?>
		<br><input name="pilihan[<?php echo $id; ?>]" type="radio" value="C">  <?php echo "$pilihan_c";?>
		<br><input name="pilihan[<?php echo $id; ?>]" type="radio" value="D">  <?php echo "$pilihan_d";?>
		<br>
		
		
		
		

		<?php
		}
		?>
        	<tr>
				<td>&nbsp;</td>
			  	<td><br><input type="submit" name="submit" value="Jawab" onclick="return confirm('Apakah Anda yakin dengan jawaban Anda?')"></td>
            </tr>
		</form>
        </p>
<?php
}
else{
echo'<p>
	<p><strong><img src=images/belum.png width=20px height=20px> Maaf ujian Seleksi Kelas tidak tersedia.</strong></p>
	<p>Untuk info lebih lanjut, silahkan menghubungi panitia.</p>
	</p>';
}
}
?>


