<?php session_start();
	include "config/function_app.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<title><?php echo app('app_name2'); ?></title>
    <link rel="stylesheet" href="media/css/reset.css" type="text/css" media="all">
	<link rel="stylesheet" href="media/css/layout.css" type="text/css" media="all">
	<link rel="stylesheet" href="media/css/style.css" type="text/css" media="all">
	<script type="text/javascript" src="media/js/jquery-1.5.2.js" ></script>
	<script type="text/javascript" src="media/js/cufon-yui.js"></script>
	<script type="text/javascript" src="media/js/cufon-replace.js"></script>
	<script type="text/javascript" src="media/js/Molengo_400.font.js"></script>
	<script type="text/javascript" src="media/js/Expletus_Sans_400.font.js"></script>
	<script>
		$(function() {
			$("#tgl").datepicker({ dateFormat :'yy-mm-dd', minDate : 0, maxDate: "1W + 0D"}).val();
		});
		</script>
     <link rel="shortcut icon" href="images/<?php echo app('skl_logo'); ?>" type="image/x-icon">
</head>
<body id="page3">
	<div class="body1">
		<div class="main">
		<header>
				<div class="wrapper">
					<nav>
					  <ul id="menu">
						<?php
						$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama = 'halaman' AND nilai_d = '1' OR nilai_d = '3' ORDER BY nilai_c ASC");
							while ($tampil = mysql_fetch_array($sql)) {
							echo '<li><a href="?page=hal&id='.$tampil['id'].'">'.$tampil['nilai'].'</a></li>';
						
						}
						?>
					  </ul>
				</div>
<br>
<br>
		<div id="slogan"> <?php echo app('app_name'); ?><span><?php echo app('skl_nama'); ?></span> </div>
		<ul class="banners">
			<li><a href="index.php?page=daftar"><img src="media/images/Untitled.png" alt=""></a></li>
		</ul>
    </header>
	</div>
</div>
<div class="body2">
  <div class="main">
    <section id="content">
      <div class="box1">
        <div class="wrapper">
		<article class="col1">
            <div class="pad_left1">
			  <p class="pad_bot1 pad_top2">

							<?php 
							
							
							
							
							
				if(isset($_GET['page'])){
					$page=htmlentities($_GET['page']);
				}else{
					$page="welcome1";
				}
				
				$file="$page.php";
				$cek=strlen($page);
				
				if($cek>30 || !file_exists($file) || empty($page)){
					include ("welcome1.php");
				}else{
					include ($file);
				}
				?>
		</p>
		</div>
		</article>
		 <article class="col_4 pad_left2">
			<h3>LOGIN PPDB</h3>
                <form id="newsletter" role="form"  method="post" class="search" action="?page=login">
                  <div class="wrapper">
					<div  class="wrapper"> 
						<strong>NISN:</strong>
						<div class="bg">
						  <input type="text" name="nisn"  size="20" class="form-control" placeholder="Masukkan NISN anda">
						</div>
					</div>
					<div  class="wrapper"> <strong>PIN :</strong>
						<div class="bg">
						<input type="password" name="password"  size="40" class="form-control" placeholder="Masukkan password anda">
						</div>
                  </div>
                  </div>
                  <button  type="submit" value="Login" name="Simpan" class="button marg_top2">Lanjutkan</button>
                </form>
          </article>
          <article class="col2 pad_left2">

            <div class="pad_left1">
              <h2>Sambutan</h2>
              <p class="quot"> <span><strong><a href="#"><?php echo app('app_kepsek'); ?></a></strong></span> <span class="color1">Kepala Sekolah</span> <span class="color2 pad_bot1"><?php echo app('skl_nama'); ?></span> 
			  <?php
					$sql = mysql_query("SELECT * FROM seting order by id asc limit 1,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
					$art = substr($tampil['nilai'],0,230);
						echo "	";
						echo"
						<p>$art ...</p>
						";
					;}
					?>
					</p>
            </div>
            <a href="index.php?page=sambutan" class="button marg_top1"><span><span>&nbsp;&nbsp; Lanjutkan &nbsp;&nbsp;</span></span></a>
			</article>
        </div>
      </div>
    </section>

    <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_7">
                <h3>Alamat:</h3>
                <p class="col_address"> 
                  Alamat:<br>
                  Email: </strong> </p>
                  <?php echo app('skl_alamat'); ?><br>
                  <?php echo app('skl_email'); ?></p>
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Telepon Interaktif: </span><span class="call2"><?php echo app('skl_telp'); ?></span> </article>
              <article class="col_5 pad_left2">Copyright &copy; <a href="#"><?php echo app('skl_nama'); ?></a> All Rights Reserved<br>
                Owner : <a target="_blank" href="#"></a></article>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
</body>
</html>