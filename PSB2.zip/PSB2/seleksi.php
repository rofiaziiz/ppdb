
<!DOCTYPE html>
<html>
	<head>
		<title>PPDB Online  - <?php echo ucwords($nama);?></title>
		    <meta charset="utf-8">


		   
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <link rel="stylesheet" href="css/user.css" type="text/css" />
        <link rel="shortcut icon" href="images/logo2c.png" type="image/x-icon">
		<script>
		$(function() {
			$("#tgl").datepicker({ dateFormat :'yy-mm-dd', minDate : 0, maxDate: "1W + 0D"}).val();
		});
		</script>
    
    <link rel="stylesheet" href="media/css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="media/css/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="media/css/style.css" type="text/css" media="all">
<script type="text/javascript" src="media/js/jquery-1.5.2.js" ></script>
<script type="text/javascript" src="media/js/cufon-yui.js"></script>
<script type="text/javascript" src="media/js/cufon-replace.js"></script>
<script type="text/javascript" src="media/js/Molengo_400.font.js"></script>
<script type="text/javascript" src="media/js/Expletus_Sans_400.font.js"></script>

	</head>
	<body id="page3">
<div class="body1">
  <div class="main">
    <!-- header -->
    <header>
      <div class="wrapper">
        <nav>
          <ul id="menu">
		  <li><a href="home.php">Home</a></li>
                      <li id="current"><a href="#">Halaman Ujian Seleksi PPDB</a></li>
                    </ul>

      </div>
      <div class="wrapper">
        <h1><a href="home.php" id="logo">Learn Center</a></h1>
      </div>
      <div id="slogan">PPDB Online<span>SMA N 1 Jatisrono</span> </div>
      <ul class="banners">

      </ul>
    </header>
	
		 
  </div>
</div>
<div class="body">
  <div class="main">
    <!-- content -->
    <section id="content">
      <div class="box1">
        <div class="wrapper">
		<article class="col1">
            <div class="pad_left1">

			  <p class="pad_bot1 pad_top2">
				<?php 
				if(isset($_GET['page'])){
					$page=htmlentities($_GET['page']);
				}else{
					$page="home-user";
				}
				
				$file="$page.php";
				$cek=strlen($page);
				
				if($cek>30 || !file_exists($file) || empty($page)){
					include ("home-user.php");
				}else{
					include ($file);
				}
				?>
				</p>
		</div>
		</article>
		<article class="col2 pad_left2">
		             <div class="pad_left1">
              <h3>Petunjuk Umum</h3>
              <p class="quot"> <span><strong><a href="#">Wijiyati S.Pd</a></strong></span> <span class="color1">Kepala Sekolah</span> <span class="color2 pad_bot1">SMA N 1 Jatisrono</span> 
			 </p>
            </div>
		 
		 
		 
		 
		 
		 
		 
		</article>

                      
               

   </div>
      </div>
    </section>
    <!-- content -->
    <!-- footer -->
       <footer>
      <div class="wrapper">
        <div class="pad1">
          <div class="pad_left1">
            <div class="wrapper">
              <article class="col_7">
                <h3>Alamat:</h3>
                <p class="col_address"> 
                  Alamat:<br>
                  Email: </strong> </p>
             
                  Jl. Raya Wonogiri - Ponorogo KM 20<br>
                  info@smanja.sch.id </p>
              </article>

             
            </div>
            <div class="wrapper">
              <article class="call"> <span class="call1">Telepon Interaktif: </span><span class="call2">(0273) 411143</span> </article>
              <article class="col_5 pad_left2">Copyright &copy; <a href="#">SMA N 1 Jatisrono</a> All Rights Reserved<br>
                Design by <a target="_blank" href="http://www.templatemonster.com/">Adi Media</a></article>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- / footer -->
  </div>
</div>
<script type="text/javascript">Cufon.now();</script>
                    
    				
    		

	</body>
</html>

