					<?php
					$sql = mysql_query("SELECT * FROM seting limit 2,1");
					
					while ($tampil = mysql_fetch_array($sql)) {
						echo "
			
						";
						echo"

						<p>$tampil[nilai]</p>
						 
				
						";
					;}
					?>