<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">
    <link id="bs-css" href="admin/css/bootstrap-cerulean.min.css" rel="stylesheet">
    <link href="admin/css/charisma-app.css" rel="stylesheet">
    <link href='admin/css/jquery.noty.css' rel='stylesheet'>
    <link href='admin/css/noty_theme_default.css' rel='stylesheet'>
    <link href='admin/css/elfinder.min.css' rel='stylesheet'>
    <link href='admin/css/elfinder.theme.css' rel='stylesheet'>
    <link href='admin/css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='admin/css/uploadify.css' rel='stylesheet'>
    <link href='admin/css/animate.min.css' rel='stylesheet'>
    <script src="admin/bower_components/jquery/jquery.min.js"></script>
    <link rel="shortcut icon" href="img/favicon.ico">
</head>
<body>
   <div id="content" class="col-lg-10 col-sm-10">
	<ul class="breadcrumb">	
		<h4>Verifikasi Berkas</h4>
    </ul>
	<?php
		$jm5 = mysql_query("SELECT * FROM seting order by id asc limit 5,1");
		while($k=mysql_fetch_array($jm5)){
		$nilai2=strtoupper($k[nilai]);
		}
	?>
  <div class="box-content">
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
        <th>No.</th>
		<th>No. Daftar</th>
		<th>Nama</th>
		<th>Status</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
    <?php
		$thn = date('Y');
		$sql = mysql_query("
		SELECT * FROM biodata 
		WHERE date_format(tgl_daftar,'%Y') = '$thn' order by nama asc");
		$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
			$no++;
			if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.  $tampil['id_utama'].'</td>';
						echo '<td>'.$tampil['nama'].'</td>';
						echo '<td>'.$tampil['verifikasi'].'</td>';
						echo '<td><a href="?page=verifikasi_edit&amp;id='.$tampil['id_utama'].' " class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a></td>';
				echo '</tr>';
			}
		?>
    </tbody>
    </table>
    </div>
    </div>
    </div>
    </div>
            </div>
        </div>
    </div>
	
</body>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='bower_components/moment/min/moment.min.js'></script>
<script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="js/charisma.js"></script>