-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2017 at 06:05 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `psb2`
--

-- --------------------------------------------------------

--
-- Table structure for table `biodata`
--

CREATE TABLE IF NOT EXISTS `biodata` (
`id_utama` int(11) NOT NULL,
  `nisn` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `jenis_kel` enum('Laki-Laki','Perempuan') NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `agama` enum('Islam','Kristen','Katolik','Budha','Hindu','Konghucu') NOT NULL,
  `tgl_daftar` date NOT NULL,
  `photo` varchar(100) NOT NULL,
  `tampil_password` varchar(100) NOT NULL,
  `verifikasi` enum('Belum','Sudah') NOT NULL,
  `prestasi` varchar(100) NOT NULL,
  `desa` varchar(100) NOT NULL,
  `kecamatan` varchar(100) NOT NULL,
  `kabupaten` varchar(100) NOT NULL,
  `provinsi` varchar(100) NOT NULL,
  `sekolah` varchar(500) NOT NULL,
  `mat` decimal(4,2) NOT NULL,
  `ingg` decimal(4,2) NOT NULL,
  `ind` decimal(4,2) NOT NULL,
  `ipa` decimal(4,2) NOT NULL,
  `jumlah` decimal(5,2) NOT NULL,
  `ayah` varchar(500) NOT NULL,
  `kerja_ayah` enum('PNS','Wiraswasta','Buruh','Pedagang','Lain-lain') NOT NULL,
  `ibu` varchar(500) NOT NULL,
  `penghasilan` int(13) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `kerja_ibu` varchar(100) NOT NULL,
  `pendidikan_ayah` varchar(100) NOT NULL,
  `pendidikan_ibu` varchar(100) NOT NULL,
  `temp_tinggal` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `biodata`
--

INSERT INTO `biodata` (`id_utama`, `nisn`, `nama`, `password`, `jenis_kel`, `tempat_lahir`, `tgl_lahir`, `agama`, `tgl_daftar`, `photo`, `tampil_password`, `verifikasi`, `prestasi`, `desa`, `kecamatan`, `kabupaten`, `provinsi`, `sekolah`, `mat`, `ingg`, `ind`, `ipa`, `jumlah`, `ayah`, `kerja_ayah`, `ibu`, `penghasilan`, `telepon`, `kerja_ibu`, `pendidikan_ayah`, `pendidikan_ibu`, `temp_tinggal`) VALUES
(101, 'cahya', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '0000-00-00', '', '0000-00-00', '', '', 'Belum', '', '', '', '', '', '', '0.00', '0.00', '0.00', '0.00', '0.00', '', '', '', 0, '', '', '', '', ''),
(119, '1213', 'Miftah', '6411', 'Laki-Laki', 'Wonogiri', '1994-12-02', 'Katolik', '2017-03-19', '.birthday-311173_960_720.png', '', 'Sudah', '', 'Jatisari', 'Jatisrono', 'wonogiri', '', 'SMP 1 Slogohimo', '80.00', '80.50', '64.42', '70.20', '360.00', 'Doni', 'Wiraswasta', 'Sukinah', 1200000, '0829344242', 'PNS', 'PNS', 'Wiraswasta', 'Bersama Orang Tua'),
(120, '132342', 'Joni', '8912', 'Perempuan', 'Kentucky', '1994-12-02', 'Kristen', '2017-03-19', '.1003316_278705902268470_1025704453_n.jpg', '', 'Sudah', '', 'Jatisari', 'Jatisrono', 'wonogiri', '', 'SMP 1 Slogohimo', '80.00', '80.50', '64.42', '70.20', '370.00', 'Doni', 'PNS', '', 0, '0829344242', '0', '0', '0', 'Kost'),
(121, '99982', 'Sunaryo', '9813', 'Perempuan', 'Wonogiri', '1994-12-02', 'Hindu', '2017-03-19', '.balloons-41362_960_720.png', '', 'Sudah', '', 'Jatisari', 'Jatisrono', 'wonogiri', '', 'SMP 1 Slogohimo', '80.00', '80.50', '64.42', '70.20', '330.00', 'Sriyatno', '', '', 0, '08293442421', '0', '0', '0', 'Lainnya'),
(122, '45454trt', 'Sri Yono', '9465', 'Laki-Laki', 'Wonogiri', '1994-12-02', 'Katolik', '2017-03-22', '.1003316_278705902268470_1025704453_n.jpg', '', 'Belum', '', 'Jatisari', 'Jatisrono', 'wonogiri', '', 'SMP 1 Slogohimo', '80.00', '80.50', '64.42', '70.20', '320.00', '', '', '', 0, '0829344242', '0', '0', '0', 'Bersama Orang Tua'),
(125, '34343', 'Sari Roti', '6568', 'Perempuan', 'sdsd', '1994-12-02', 'Kristen', '2017-03-23', 'balloons-41362_960_720.png', '', 'Belum', '', 'Jatisari', 'Jatisrono', 'Boyolali', '', 'SMP 1 Slogohimo', '80.00', '80.50', '77.00', '56.00', '310.00', 'Sriyatno', 'PNS', 'Sukinah', 1000000, '08293442421', 'PNS', 'Wiraswasta', 'PNS', 'Bersama Orang Tua'),
(126, 'dfdf', 'sdsd', '4879', '', '', '0000-00-00', '', '2017-03-26', '1003316_278705902268470_1025704453_n.jpg', '', 'Belum', '', '', '', '', '', 'SMP 1 Slogohimo', '80.00', '80.50', '64.42', '70.20', '310.00', 'Sriyatno', '', 'Sukinah', 0, '', 'Petani', 'SMP', 'SMA', 'Bersama'),
(127, '34343', 'Wiyanto Vewe', '4910', 'Laki-Laki', 'Wonogiri', '0000-00-00', 'Katolik', '2017-03-26', '111.png', '', 'Belum', '', 'Jatisari', 'Jatisrono', 'Boyolali', '', 'SMP 1 Slogohimo', '80.00', '80.50', '64.42', '70.20', '360.00', 'Sriyatno', 'PNS', 'Sukinah', 0, '08293442421', 'PNS', 'D3', 'S1', 'Homestay');

-- --------------------------------------------------------

--
-- Table structure for table `combo_list`
--

CREATE TABLE IF NOT EXISTS `combo_list` (
`id_combo` int(5) NOT NULL,
  `keyname` varchar(100) NOT NULL,
  `keyval` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `combo_list`
--

INSERT INTO `combo_list` (`id_combo`, `keyname`, `keyval`) VALUES
(1, 'combo_tinggal', 'Bersama Orang Tua'),
(2, 'combo_tinggal', 'Kost'),
(3, 'combo_tinggal', 'Bersama Saudara'),
(4, 'combo_tinggal', 'Homestay'),
(5, 'combo_kerja', 'Petani'),
(6, 'combo_kerja', 'PNS'),
(7, 'combo_didik', 'S1'),
(8, 'combo_didik', 'S2'),
(9, 'combo_penghasilan', 'Kurang dari Rp. 1.000.000'),
(10, 'combo_penghasilan', 'Rp. 1.000.000 - Rp. 2.000.000'),
(11, 'combo_penghasilan', 'Rp. 2.000.000 - Rp. 3.000.000'),
(12, 'combo_penghasilan', 'Rp. 3.000.000 - Rp. 5.000.000'),
(13, 'combo_penghasilan', 'Lebih dari Rp. 5.000.000'),
(14, 'combo_didik', 'SD'),
(15, 'combo_didik', 'SMP'),
(16, 'combo_didik', 'SMA'),
(17, 'combo_didik', 'D2'),
(18, 'combo_didik', 'D3'),
(19, 'combo_didik', 'S3');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `id_kelas` varchar(30) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL,
  `daya_tampung` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`, `daya_tampung`) VALUES
('A1', 'VII MIPA 1', 30),
('A2', 'VII MIPA 2', 30),
('S1', 'VII IPS 1', 30),
('S2', 'VII IPS 2', 30);

-- --------------------------------------------------------

--
-- Table structure for table `kelas_siswa`
--

CREATE TABLE IF NOT EXISTS `kelas_siswa` (
  `id_siswa` int(11) NOT NULL,
  `id_kelas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas_siswa`
--

INSERT INTO `kelas_siswa` (`id_siswa`, `id_kelas`) VALUES
(2, 'S1'),
(28, 'A2'),
(33, 'A1'),
(59, 'S1'),
(81, 'S1'),
(82, 'A2'),
(97, 'S1');

-- --------------------------------------------------------

--
-- Table structure for table `konfigurasi`
--

CREATE TABLE IF NOT EXISTS `konfigurasi` (
`id` int(11) NOT NULL,
  `kelompok` varchar(100) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `shortname` varchar(100) NOT NULL,
  `nilai` text NOT NULL,
  `nilai_b` text NOT NULL,
  `nilai_c` varchar(50) NOT NULL,
  `nilai_d` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `konfigurasi`
--

INSERT INTO `konfigurasi` (`id`, `kelompok`, `nama`, `shortname`, `nilai`, `nilai_b`, `nilai_c`, `nilai_d`) VALUES
(1, '', 'limit_mahasiswa', '', '1', '', '', ''),
(2, '', 'limit_tanggal', '', '2018/08/22', '', '', ''),
(3, '', 'limit_ujian', '', '2017/01/15', '', '', ''),
(4, '', 'limit_pengumuman', '', 'Sembunyikan', '', '', ''),
(5, '', 'buka_daftar', '', '1', '', '', ''),
(6, 'form_daftar', 'form_photo', 'Photo', '1', '1', '', ''),
(7, 'form_daftar', 'form_tinggal', 'Tempat Tinggal', '1', '1', '', ''),
(8, 'form_daftar', 'form_detnilai', 'Detail Nilai', '0', '0', '', ''),
(9, 'form_daftar', 'form_ayah', 'Nama Ayah', '1', '1', '', ''),
(10, 'form_daftar', 'form_kayah', 'Pekerjaan Ayah', '0', '0', '', ''),
(11, 'form_daftar', 'form_dayah', 'Pendidikan Ayah', '1', '1', '', ''),
(12, 'form_daftar', 'form_ibu', 'Nama Ibu', '0', '1', '', ''),
(13, 'form_daftar', 'form_kibu', 'Pekerjaan Ibu', '1', '1', '', ''),
(14, 'form_daftar', 'form_dibu', 'Pendidikan Ibu', '1', '1', '', ''),
(15, 'form_daftar', 'form_penghasilan', 'Penghasilan Orang tua', '1', '1', '', ''),
(16, 'sekolah', 'skl_nama', 'Nama ', 'SMA Negeri 1 Jatisrono', '', '', ''),
(17, 'sekolah', 'skl_alamat', 'Alamat', 'Jl. Wonogiri - Ponorogo', '', '', ''),
(18, 'sekolah', 'skl_kab', 'Kabupaten', 'Wonogiri', '', '', ''),
(19, 'sekolah', 'skl_telp', 'Telp', '(0273) 41189433', '', '', ''),
(20, 'sekolah', 'skl_logo', 'Logo', 'logo2c.pngd', '', '', ''),
(21, 'sekolah', 'skl_email', 'Email', 'info@smanja.sch.id', '', '', ''),
(22, 'sekolah', 'app_name', 'Nama Sistem', 'PPDB Online', '', '', ''),
(23, 'sekolah', 'app_name2', 'Nama Sistem 2', 'PPDB SMA N 1 Jatisrono', '', '', ''),
(24, '', 'halaman', '', 'Informasi Pendaftaran', 'ini halaman Informasi Pendaftaran', '3', '3'),
(25, '', 'halaman', '', 'Profil', 'ini halaman Profil', '5', '3'),
(26, '', 'halaman', '', 'Daftar', '<meta http-equiv=''refresh'' content=''0; url=?page=daftar''>', '2', '1'),
(27, '', 'halaman', '', 'Beranda', '<meta http-equiv=''refresh'' content=''0; url=index.php''>', '1', '1'),
(28, '', 'halaman', '', 'Jurnal', '<meta http-equiv=''refresh'' content=''0; url=?page=pendaftar''>', '4', '3'),
(29, '', 'halaman', '', 'Beranda', 'ini halaman Depan User', '1', '2'),
(30, 'sekolah', 'app_kepsek', 'Kepala Sekolah', 'Cahya Adi Saputra', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `nisn`
--

CREATE TABLE IF NOT EXISTS `nisn` (
  `id_nisn` int(11) NOT NULL,
  `nisn` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nisn`
--

INSERT INTO `nisn` (`id_nisn`, `nisn`) VALUES
(0, '122122233344'),
(4, '9878765674'),
(5, '9878765673'),
(6, '9878765676'),
(7, '9878765674'),
(8, '9878765674'),
(9, 'av@gmail.com'),
(10, 'av@gmail.com'),
(11, '9878765675'),
(12, '9870765675'),
(13, '9878765675'),
(14, '98787656877'),
(15, '4878765675'),
(16, ''),
(17, ''),
(18, ''),
(19, ''),
(20, ''),
(21, '0000'),
(22, '0000'),
(23, '0000'),
(24, '0000'),
(25, '0000'),
(26, '122223334412'),
(27, '122223334412'),
(28, '0000'),
(29, '878721231'),
(30, '23138654'),
(31, '123321233'),
(32, '2675921'),
(33, '54322221'),
(34, ''),
(35, ''),
(36, '5532233344'),
(37, '12222123334412'),
(38, '63812344'),
(39, '43129021'),
(40, '122223334412'),
(41, '5652311'),
(42, '3363124'),
(43, '65321231'),
(44, ''),
(51, '73671122'),
(52, '6474672'),
(53, '73638181'),
(54, '7383622'),
(55, '7288111'),
(56, '8393872'),
(57, ''),
(58, ''),
(59, '383921'),
(60, '322122');

-- --------------------------------------------------------

--
-- Table structure for table `prestasi`
--

CREATE TABLE IF NOT EXISTS `prestasi` (
  `id_prestasi` varchar(10) NOT NULL,
  `tingkat` varchar(200) NOT NULL,
  `nilai` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prestasi`
--

INSERT INTO `prestasi` (`id_prestasi`, `tingkat`, `nilai`) VALUES
('0', 'Tidak Ada Prestasi', '0'),
('10KJ1', 'Kabupaten/Kota Juara 1', '10.50'),
('11KJ2', 'Kabupaten/Kota Juara 2', '10.25'),
('12KJ3', 'Kabupaten/Kota Juara 3', '10.00'),
('1IJ1', 'Internasional Juara 1', 'u1'),
('2IJ2', 'Internasional Juara 2', 'u2'),
('3IJ3', 'Internasional Juara 3', 'u3'),
('4NJ1', 'Nasional Juara 1', 'u4'),
('5NJ2', 'Nasional Juara 2', '30.50'),
('6NJ3', 'Nasional Juara 3', '30.25'),
('7PJ1', 'Provinsi Juara 1', '30.00'),
('8PJ2', 'Provinsi Juara 2', '20.75'),
('9PJ2', 'Provinsi Juara 3', '20.50');

-- --------------------------------------------------------

--
-- Table structure for table `seting`
--

CREATE TABLE IF NOT EXISTS `seting` (
`id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seting`
--

INSERT INTO `seting` (`id`, `nama`, `nilai`) VALUES
(1, 'Halaman Pembuka', '<p><strong>Sistem Informasi Penerimaan Peserta Didik Baru SMAN 1 Jatisrono, Wonogiri</strong></p>\r\n\r\n<hr />\r\n<p>Kami Menyambut baik terbitnya Website PPD SMAN 1 Jatisrono , dengan harapan dipublikasinya website ini, sekolah berharap &nbsp;Peningkatan layanan pendidikan kepada siswa, orangtua, dan masyarakat pada umumnya semakin meningkat. Sebaliknya orangtua dapat mengakses informasi tentang kegiatan akademik dan non akademik putra - puterinya di sekolah ini. Dengan fasilitas ini Siswa dapat mengakses berbagai informasi pembelajaran dan informasi akademik.</p>\r\n\r\n<p><img alt="" src="http://localhost/webnew2/images/alur.jpg" style="height:322px; width:572px" /></p>\r\n'),
(2, 'Sambutan Kepala Sekolah', '<p>Assalamulaikum wr. wb.</p>\r\n\r\n<p>Peran teknologi dalam pendidikan memang sangat penting. Teknologi informasi menjadi salah satu sarana untuk memudahkan semua proses dalam pendidikan.d</p>\r\n\r\n<p>Website PPDB ini merupakan salah satu kepedulian SMA Negeri 1 Jatisrono di bidang teknologi. semoga dengan diluncurkannya website ini dapat membantu dan mumudahkan semua pihak yang telibat pada sistem ini.</p>\r\n'),
(3, 'Informasi Pemdaftaran', '<p>Proses Penerimaan Siswa baru ini berlansung selama dua minggu. Pendaftaran dapat dilakuakn secara <em>online </em>dan <em>offline.</em> Berikut adalah jadwal lengkap PPDB SMA Negeri 1 Jatisrono</p>\r\n\r\n<p><strong>- Pelayanan Melalui Online</strong></p>\r\n\r\n<ul>\r\n	<li>26-30 Juni 2015 : Pendaftaran PPDB melalui website resmi PPDB SMA Negeri 1 Jatisrono</li>\r\n	<li>2-4 Agustus 2015 : Verifikasi Berkas</li>\r\n	<li>5 Agustus 2015 : Konversi Piagam Prestasi (Opsional)</li>\r\n	<li>8 Agustus 2015 : Pengumuman</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>- Pelayanan Melalui Offline</strong></p>\r\n\r\n<ul>\r\n	<li>26-30 Juni 2015 : Pendaftaran PPDB melalui dengan datang langsung ke SMA Negeri 1 Jatisrono\r\n	<ul>\r\n		<li>Membawa syarat pendaftaran untuk verifikasi berkas</li>\r\n	</ul>\r\n	</li>\r\n	<li>5 Agustus 2015 : Konversi Piagam Prestasi (Opsional)</li>\r\n	<li>8 Agustus 2015 : Pengumuman</li>\r\n</ul>\r\n'),
(4, 'Profil Sekolah', '<p>SMA Negeri 1 Jatisrono adalah sekolah menengah atas yang terdapat di kecamatan Jatisrono, kabupaten Wonogiri, Jawa Tengah. SMA Negeri 1 Jatisrono merupakan satu-satunya SMA di kecamatan Jatisrono. SMA Negeri 1 Jatisrono beralamat di Jalan Raya Wonogiri-Ponorogo pada kilometer 26.</p>\r\n\r\n<p>SMA Negeri 1 Jatisrono mempunyai peringkat rata-rata Ujian Nasional terbaik kedua di kabupaten Wonogiri. Setidaknya pada tahun 2015, SMA Negeri 1 Jatisrono menempati peringkat teratas untuk konsentrasi/jurusan Ilmu-Ilmu Sosial. Sedangkan untuk perigkat rata-rata Ujian Nasional, pada peringkat pertama ditempati oleh SMA Negeri 1 Wonogiri dan SMA Negeri 2 Wonogiri pada peringkat ke-3. Banyaknya prestasi yang telah dicapai, menjadikan SMA Negeri 1 Jatisrono sebagai salah satu SMA unggulan yang terdapat di kabupaten Wonogiri. Walaupun terdapat di kawasan Wonogiri bagian timur, tetapi banyak siswa yang berasal dari lain kecamatan. Sampai saat ini SMA Negeri 1 Jatisrono terus menjaga mutu dan kualitas pendidikan yang terbaik.</p>\r\n'),
(5, 'Fasilitas Sekolah', '<h2>Fasilitas Sekolah</h2>\r\n\r\n<p>Penerimaa Siswa Baru (PSB) SMA Negeri 1 Jatisrono tahun 2015 dibuka melalui 2 Gelombang. Berikut Jadwal Pelayanan PSB SMANJA 2015: Gelombang 1 Dilaksanakan mulai tanggal 12 Juni 2015 - 29 Juni 2015</p>\r\n\r\n<p>Calon peserta didik pada Gelombang pertama akan melalui Tes Tertulis Pendaftaran dapat dilakukan melalui online atau datang langsung ke SMA N 1 Jatisrono Gelombang 2 Dilaksanakan mulai tanggal 29 Juli 2015 - 3 September 2015 Calon peserta didik pada Gelombang kedua akan menggunkan Nilai UN sebagai acuan kelulusan Pendaftaran dapat dilakukan melalui online atau datang langsung ke SMA N 1 Jatisrono Jadwal tersebut dapat berubah sewaktu-waktu, perubahan akan di umumkan pada website resmi PSB SMANJA 2015. Terima Kasih</p>\r\n'),
(6, 'Kode Pendaftaran', '2015.331.'),
(7, 'Tahun Pelajaran', '2015/2016'),
(8, 'Petugas Pendaftaran', '<p>Cahya</p>\r\n'),
(9, 'NIP Petugas Pendaftaran', '<p>q</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_nilai`
--

CREATE TABLE IF NOT EXISTS `tabel_nilai` (
`id_test` int(4) NOT NULL,
  `id_ujian` int(4) NOT NULL,
  `benar` int(4) NOT NULL,
  `salah` int(4) NOT NULL,
  `kosong` int(4) NOT NULL,
  `point` int(4) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_nilai`
--

INSERT INTO `tabel_nilai` (`id_test`, `id_ujian`, `benar`, `salah`, `kosong`, `point`, `tanggal`) VALUES
(17, 28, 3, 4, 0, 15, '2015-08-02'),
(18, 56, 0, 7, 0, 0, '2015-08-15'),
(35, 33, 2, 7, 0, 10, '2015-08-17'),
(36, 59, 1, 8, 0, 5, '2015-08-19'),
(40, 2, 0, 9, 0, 0, '2015-08-26'),
(42, 91, 2, 7, 0, 10, '2015-09-07'),
(43, 82, 2, 8, 0, 10, '2015-09-08'),
(44, 81, 0, 10, 0, 0, '2015-09-08'),
(45, 97, 1, 8, 0, 5, '2015-09-09'),
(46, 127, 0, 9, 0, 0, '2017-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_soal`
--

CREATE TABLE IF NOT EXISTS `tabel_soal` (
`id_soal` int(4) NOT NULL,
  `pertanyaan` text NOT NULL,
  `pilihan_a` text NOT NULL,
  `pilihan_b` text NOT NULL,
  `pilihan_c` text NOT NULL,
  `pilihan_d` text NOT NULL,
  `jawaban` varchar(100) NOT NULL,
  `publish` enum('yes','no') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_soal`
--

INSERT INTO `tabel_soal` (`id_soal`, `pertanyaan`, `pilihan_a`, `pilihan_b`, `pilihan_c`, `pilihan_d`, `jawaban`, `publish`) VALUES
(3, 'Pertanyaan Pertama', 'Pilihan A', 'Pilihan B', 'Pilihan C', 'Pilihan D', 'B', 'yes'),
(4, 'Pertanyaan Kedua', 'Pilihan A', 'Pilihan B', 'Pilihan C', 'Pilihan D', 'A', 'yes'),
(5, 'Makanan Kesukaan Kamu Apa?', 'Mie Ayam', 'Sate', 'Bakso', 'Nasi Goreng', 'D', 'yes'),
(6, 'Olah Raga Kesukaan Kamu Apa?', 'Badminton', 'Bola', 'Voli', 'Jalan Kaki', 'A', 'no'),
(8, 'Siapa Presiden Amerika Serika Saat Ini?', 'Barack Obama', 'Jokowi', 'Hillary Clinton', 'George Bush', 'A', 'yes'),
(9, 'Bermain Diklub Manakah Okto Maniani?', 'Sriwijaya FC', 'Persipura Jayapura', 'Perseru Serui', 'Persiwa Wamena', 'D', 'yes'),
(10, 'DFD Level 1 Menjelaskan Tentang Proses-proses Yang Ada Dalam Sistem Informasi Pengelolaan Studi Lanj', 'PHP', 'JQuery', 'CSS', 'HTML', 'A', 'yes'),
(11, 'Proses Tersebut Terbagi Menjadi Lima Bagian Yaitu Proses Login, Proses Setting, Manajemen User, Input Data Pemohon Dan Input?', 'Barcelona', 'Madrid', 'Munchen', 'Porto', 'D', 'yes'),
(16, 'Pertanyaan 2', 'Jawaban A', 'Jawaban B', 'Jawaban C', 'Jawaban D', 'A', 'yes'),
(17, 'Tumbuhan Berfotosintesis Memerlukan, Kecuali...', 'Matahari', 'Klorofil', 'Zat Hijau Daun', 'Air', 'D', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id_admin` varchar(9) NOT NULL,
  `nama` varchar(89) NOT NULL,
  `password` varchar(88) NOT NULL,
  `telp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id_admin`, `nama`, `password`, `telp`) VALUES
('admin', 'admin rais', 'c0257943d80dbccbba5f1e25d962b991', '087839758726'),
('cahya', 'Cahya Adi Saputra', '7513810474271763d6f8f0c999466094', '08765642321'),
('root', 'Root Sahanaya', '63a9f0ea7bb98050796b649e85481845', '08111234239999'),
('susi', 'Susi Susanti', '536931d80decb18c33db9612bdd004d4', '085229836790');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_berita`
--

CREATE TABLE IF NOT EXISTS `tbl_berita` (
`id_berita` int(9) NOT NULL,
  `judul` varchar(90) NOT NULL,
  `isi` text NOT NULL,
  `terbit` date NOT NULL,
  `oleh` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_berita`
--

INSERT INTO `tbl_berita` (`id_berita`, `judul`, `isi`, `terbit`, `oleh`) VALUES
(9, 'Launching Website PPDB Berlangsung Meriah', '<p><strong>Jatipurno</strong>&nbsp;- SMA Negeri 1 Jatisrono adalah sekolah menengah atas yang terdapat di kecamatan Jatisrono, kabupaten Wonogiri, Jawa Tengah. SMA Negeri 1 Jatisrono merupakan satu-satunya SMA di kecamatan Jatisrono. SMA Negeri 1 Jatisrono beralamat di Jalan Raya Wonogiri-Ponorogo pada kilometer 26.</p>\r\n\r\n<p>SMA Negeri 1 Jatisrono mempunyai peringkat rata-rata Ujian Nasional terbaik kedua di kabupaten Wonogiri. Setidaknya pada tahun 2015, SMA Negeri 1 Jatisrono menempati peringkat teratas untuk konsentrasi/jurusan Ilmu-Ilmu Sosial. Sedangkan untuk perigkat rata-rata Ujian Nasional, pada peringkat pertama ditempati oleh SMA Negeri 1 Wonogiri dan SMA Negeri 2 Wonogiri pada peringkat ke-3. Banyaknya prestasi yang telah dicapai, menjadikan SMA Negeri 1 Jatisrono sebagai salah satu SMA unggulan yang terdapat di kabupaten Wonogiri. Walaupun terdapat di kawasan Wonogiri bagian timur, tetapi banyak siswa yang berasal dari lain kecamatan. Sampai saat ini SMA Negeri 1 Jatisrono terus menjaga mutu dan kualitas pendidikan yang terbaik.</p>\r\n', '0000-00-00', ''),
(10, 'SMA N 1 Jatisrono Resmi Membuka PPDB 2015', '<p><strong>Wonogiri </strong>- SMA Negeri 1 Jatisrono secara resmi membuka PPDB 2015. PPDB yang merupakan kepanjangan dari Penrimaan Peserta Didik Baru ini akan dilaksanakan pada tanggal 26 Juli 2015 - 6 Agustus 2015. SMA Negeri 1 Jatisrono juga sekalian melaunching website PPDB mereka. Website ini merupakan website sumbangan dari alumni SMA N 1 Jatisrono. Website garapan Mahasiswa di STMIK A. Yani Yogyakarta menggunakan bahasa pemrograman yaitu PHP dan MySql.</p>\r\n\r\n<p>SMA Negeri 1 Jatisrono secara resmi membuka PPDB 2015. PPDB yang merupakan kepanjangan dari Penrimaan Peserta Didik Baru ini akan dilaksanakan pada tanggal 26 Juli 2015 - 6 Agustus 2015. SMA Negeri 1 Jatisrono juga sekalian melaunching website PPDB mereka. Website ini merupakan website sumbangan dari alumni SMA N 1 Jatisrono. Website garapan Mahasiswa di STMIK A. Yani Yogyakarta menggunakan bahasa pemrograman yaitu PHP dan MySql.</p>\r\n', '2015-09-04', 'Ad1'),
(11, 'fdf', '<p>dfdf</p>\r\n', '2017-05-01', 'asdssdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biodata`
--
ALTER TABLE `biodata`
 ADD PRIMARY KEY (`id_utama`);

--
-- Indexes for table `combo_list`
--
ALTER TABLE `combo_list`
 ADD PRIMARY KEY (`id_combo`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
 ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `kelas_siswa`
--
ALTER TABLE `kelas_siswa`
 ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nisn`
--
ALTER TABLE `nisn`
 ADD PRIMARY KEY (`id_nisn`);

--
-- Indexes for table `prestasi`
--
ALTER TABLE `prestasi`
 ADD PRIMARY KEY (`id_prestasi`);

--
-- Indexes for table `seting`
--
ALTER TABLE `seting`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabel_nilai`
--
ALTER TABLE `tabel_nilai`
 ADD PRIMARY KEY (`id_test`), ADD UNIQUE KEY `id_ujian` (`id_ujian`);

--
-- Indexes for table `tabel_soal`
--
ALTER TABLE `tabel_soal`
 ADD PRIMARY KEY (`id_soal`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
 ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tbl_berita`
--
ALTER TABLE `tbl_berita`
 ADD PRIMARY KEY (`id_berita`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `biodata`
--
ALTER TABLE `biodata`
MODIFY `id_utama` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=131;
--
-- AUTO_INCREMENT for table `combo_list`
--
ALTER TABLE `combo_list`
MODIFY `id_combo` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `seting`
--
ALTER TABLE `seting`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tabel_nilai`
--
ALTER TABLE `tabel_nilai`
MODIFY `id_test` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `tabel_soal`
--
ALTER TABLE `tabel_soal`
MODIFY `id_soal` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tbl_berita`
--
ALTER TABLE `tbl_berita`
MODIFY `id_berita` int(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
