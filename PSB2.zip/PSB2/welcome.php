<?php
include "config/fungsi_indotgl.php";
					$sql = mysql_query("SELECT * FROM tbl_berita order by id_berita desc");
					
					while ($tampil = mysql_fetch_array($sql)) {
					$tanggal = tgl_indo($tampil['terbit']);
					$judul = ($tampil['judul']);
					$oleh = ($tampil['oleh']);
					$art = substr($tampil['isi'],0,290);
						echo " ";
						echo"
						<a href=?page=berita.baca&amp;id=$tampil[id_berita]><h3>$judul</h3></a>
						<p>Dipublikasikan pada tanggal $tanggal, oleh $oleh</p>
						<p>$art ...        <a href=?page=berita.baca&amp;id=$tampil[id_berita]>Baca Selengkapnya</a>
						";
					;}
					?>