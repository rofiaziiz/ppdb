<?php
	error_reporting(0);
	include "config/function_acak.php";
	# TOMBOL SIMPAN DIKLIK		
if(isset($_POST['Simpan']))
	{
		$nama			=$_POST['nama'];
		$jenis_kel		=$_POST['jenis_kel'];
		$tempat_lahir	=$_POST['tempat_lahir'];
		$tgl_lahir		=$_POST['tgl_lahir'];
		$agama			=$_POST['agama'];
		$desa			=$_POST['desa'];
		$kecamatan		=$_POST['kecamatan'];
		$kabupaten		=$_POST['kabupaten'];
		$sekolah		=$_POST['sekolah'];
		$telepon		=$_POST['telepon'];
		$mat			=$_POST['mat'];
		$ind			=$_POST['ind'];
		$ingg			=$_POST['ingg'];
		$ipa			=$_POST['ipa'];
		$jumlah			=$_POST['jumlah'];
		$ayah			=$_POST['ayah'];
		$kerja_ayah		=$_POST['kerja_ayah'];
		$pendidikan_ayah=$_POST['pendidikan_ayah'];
		$ibu			=$_POST['ibu'];
		$kerja_ibu		=$_POST['kerja_ibu'];
		$pendidikan_ibu	=$_POST['pendidikan_ibu'];
		$penghasilan	=$_POST['penghasilan'];
		$temp_tinggal	=$_POST['temp_tinggal'];
		$nisn			=$_POST['nisn'];
		$tgl_daftar		=date("Y-m-d");
		
															# Validasi form, jika kosong sampaikan pesan error
															 if (! empty($_FILES['namaFile']['tmp_name'])) { 
																// Membaca nama file foto/gambar
																$file_foto = $_FILES['namaFile']['name'];
																$file_foto = stripslashes($file_foto);
																$file_foto = str_replace("'","",$file_foto);
															
																copy($_FILES['namaFile']['tmp_name'],"photo/".$file_foto);
															}
															else {
																// Jika tidak ada foto/gambar
																$file_foto = "";
															}
															
															$passacak = acak(6); 		
																	$jml_dt = mysql_num_rows(mysql_query("SELECT * FROM biodata_tk"));
																	if ($jml_dt < 10){
																		$pin = substr($passacak,0,3).$jml_dt;
																	}  else if ($jml_dt < 100){
																		$pin = substr($passacak,0,2).$jml_dt;
																	} else if ($jml_dt < 1000){
																		$pin = substr($passacak,0,1).$jml_dt;
																	} else if ($jml_dt < 10000){
																		$pin = $jml_dt;
																	}
				if(isset($_POST['jenjang']))
				{	
					$jenjang 		=$_POST['jenjang'];
					switch ($jenjang)
						{
							case 'TK':
								$mySql	=   "INSERT INTO biodata_tk (nama, jenis_kel, tgl_lahir, tempat_lahir, agama, tgl_daftar, photo, telepon, desa,kecamatan,kabupaten,  
										mat,ind,ingg, ipa, jumlah,sekolah, ayah,kerja_ayah, nisn, password, pendidikan_ayah, ibu, kerja_ibu, pendidikan_ibu, temp_tinggal, penghasilan )
										VALUES ('$nama','$jenis_kel','$tgl_lahir','$tempat_lahir','$agama','$tgl_daftar','$file_foto','$telepon','$desa','$kecamatan','$kabupaten',
										'$mat','$ind','$ingg','$ipa','$jumlah','$sekolah','$ayah','$kerja_ayah','$nisn','$pin','$pendidikan_ayah','$ibu','$kerja_ibu','$pendidikan_ibu',
										'$temp_tinggal','$penghasilan')";		
								$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
								/* $passacak = acak(6); 		
																	$jml_dt = mysql_num_rows(mysql_query("SELECT * FROM biodata_tk"));
																	if ($jml_dt < 10){
																		$pin = substr($passacak,0,3).$jml_dt;
																	}  else if ($jml_dt < 100){
																		$pin = substr($passacak,0,2).$jml_dt;
																	} else if ($jml_dt < 1000){
																		$pin = substr($passacak,0,1).$jml_dt;
																	} else if ($jml_dt < 10000){
																		$pin = $jml_dt;
																	} */
																	break;
							case 'SD':
								$mySql	= "INSERT INTO biodata_sd (nama, jenis_kel, tgl_lahir, tempat_lahir, agama, tgl_daftar, photo, telepon, desa,kecamatan,kabupaten,  
									   mat,ind,ingg, ipa, jumlah,sekolah, ayah,kerja_ayah, nisn, password, pendidikan_ayah, ibu, kerja_ibu, pendidikan_ibu, temp_tinggal, penghasilan )
										VALUES ('$nama','$jenis_kel','$tgl_lahir','$tempat_lahir','$agama','$tgl_daftar','$file_foto','$telepon','$desa','$kecamatan','$kabupaten',
										'$mat','$ind','$ingg','$ipa','$jumlah','$sekolah','$ayah','$kerja_ayah','$nisn','$pin','$pendidikan_ayah','$ibu','$kerja_ibu','$pendidikan_ibu',
										'$temp_tinggal','$penghasilan')";		
								$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
								/* $passacak = acak(6); 		
																	$jml_dt = mysql_num_rows(mysql_query("SELECT * FROM biodata_sd"));
																	if ($jml_dt < 10){
																		$pin = substr($passacak,0,3).$jml_dt;
																	}  else if ($jml_dt < 100){
																		$pin = substr($passacak,0,2).$jml_dt;
																	} else if ($jml_dt < 1000){
																		$pin = substr($passacak,0,1).$jml_dt;
																	} else if ($jml_dt < 10000){
																		$pin = $jml_dt;
																	} */
																	break;
							case 'SMP':
								$mySql	= "INSERT INTO biodata (nama, jenis_kel, tgl_lahir, tempat_lahir, agama, tgl_daftar, photo, telepon, desa,kecamatan,kabupaten,  
									   mat,ind,ingg, ipa, jumlah,sekolah, ayah,kerja_ayah, nisn, password, pendidikan_ayah, ibu, kerja_ibu, pendidikan_ibu, temp_tinggal, penghasilan )
										VALUES ('$nama','$jenis_kel','$tgl_lahir','$tempat_lahir','$agama','$tgl_daftar','$file_foto','$telepon','$desa','$kecamatan','$kabupaten',
										'$mat','$ind','$ingg','$ipa','$jumlah','$sekolah','$ayah','$kerja_ayah','$nisn','$pin','$pendidikan_ayah','$ibu','$kerja_ibu','$pendidikan_ibu',
										'$temp_tinggal','$penghasilan')";		
								$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
								/* $passacak = acak(6); 		
																	$jml_dt = mysql_num_rows(mysql_query("SELECT * FROM biodata"));
																	if ($jml_dt < 10){
																		$pin = substr($passacak,0,3).$jml_dt;
																	}  else if ($jml_dt < 100){
																		$pin = substr($passacak,0,2).$jml_dt;
																	} else if ($jml_dt < 1000){
																		$pin = substr($passacak,0,1).$jml_dt;
																	} else if ($jml_dt < 10000){
																		$pin = $jml_dt;
																	} */
							break;
						
						}
				}

		// Simpan data dari form ke Database
		if($myQry) 	
		{
			//echo "<meta http-equiv='refresh' content='0; url=admin.php?page=daftar.siswa2'>";
			echo '<b>Pendaftaran Berhasil</b><br>';
			echo '<b>PIN Anda :<mark>'.$pin.'</mark><br><br>';
			echo '<b>Simpan baik-baik PIN diatas. PIN tersebut digunakan untuk login ke akun anda<br>';

			echo '
			<form role="form"  method="post" action="?page=login">
				<input type="hidden" name="nisn"  value="'.$nisn.'">
				<input type="hidden" name="password"  class="form-control"  value="'.$pin.'">
				<button  type="submit" value="Login" name="Simpan" class="button marg_top2">Lanjutkan Masuk Akun</button>
			</form>
			';
		}		
		exit;
	}	

$get_daftar = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'buka_daftar' "));
$bk = $get_daftar['nilai'];
$form_photo = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_photo' "));
$form_tinggal = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_tinggal' "));
$form_detnilai = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_detnilai' "));
$form_ayah = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_ayah' "));
$form_kayah = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_kayah' "));
$form_dayah = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_dayah' "));
$form_ibu = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_ibu' "));
$form_kibu = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_kibu' "));
$form_dibu = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_dibu' "));
$form_penghasilan = mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE nama = 'form_penghasilan' "));

if ($bk == 1){?>
<h2>Formulir Pendaftaran</h2>
<p>Isilah Formulir ini dengan lengkap dan benar!</p>
 <form id="newsletter" enctype="multipart/form-data"  method="post" name="postform" >
   <table width="105%">

				<tr>
					<td colspan="2"><b>Keterangan  Calon Peserta Didik<b></td>
				</tr>
				<tr>
					<td>Daftar Jenjang :</td>
					<td><select class="bg3" id="jenjang" name="jenjang" >
						<option value="0">...
						<option value="TK">TK </option>
						<option value="SD">SD </option>
						<option value="SMP">SMP </option>
					</select>      
					</td>
				</tr>
				<tr>
					<td>NISN</td>
					<td><input class="bg2" type="text" name="nisn"  /></td>
				</tr>
				<tr>
					<td width="140">Nama</td>
					<td><input class="bg2" type="text" name="nama"  /></td>
				</tr>
					<input hidden type="text" name="password"  size="50"/>
                <tr>
				<td>Jenis Kelamin</td>
				<td><select class="bg3" name="jenis_kel" >
						<option value="0">...
						<option value="Laki-Laki" >Laki-laki
						<option value="Perempuan" >Perempuan
					</select>      
				</td>
				</tr>
				<tr>
					<td>Tempat Lahir</td>
					<td><input type="text" class="bg3"name="tempat_lahir"  /></td>
				</tr>
							<tr>
					<td>Tanggal Lahir</td>
					<td><input type="date" name="tgl_lahir"  class="bg3"  size="50" />
					</td>
				</tr>
				<tr>
				<td>Agama</td>
				<td><select class="bg3" name="agama" >
						<option value="0">...
						<option value="Islam" >Islam
						<option value="Kristen">Kristen
						<option value="Katolik">Katolik
						<option value="Hindu" >Hindu
						<option value="Budha" >Budha
						<option value="Konghucu" >Konghucu
					</select>      
				</td>
			</tr>
			<tr>
					<td>Alamat</td>
					<td><input type="text" class="bg3" name="desa"  placeholder="Desa/Kelurahan" size="15"  />
					<input type="text" class="bg3" name="kecamatan"  placeholder="Kecamatan" size="20"  />
					<input type="text" class="bg3"   name="kabupaten"  placeholder="Kabupaten"   size="20"/>
					</td>
				</tr>
				<?php 
				if ($form_photo['nilai'] == 1){
				?>
				<tr>
					<td>Photo</td>
					<td><input type="file" class="bg3" name="namaFile"   size="50" <?php if ($form_photo['nilai_b'] == 1){ echo 'required'; }?> /></td>
				</tr>
				<?php }?>
					<tr>
					<td>No. Telp</td>
					<td><input type="text" class="bg3" name="telepon" type="numeric" size="50" /></td>
				</tr>
				<?php 
				if ($form_tinggal['nilai'] == 1){
				?>
				<tr>
				<td>Tempat Tinggal</td>
				<td><select class="bg3" name="temp_tinggal" <?php if ($form_tinggal['nilai_b'] == 1){ echo 'required'; }?> >
						<option value="">Silahkan Pilih</option>

						<?php 
						$sqlx = mysql_query("SELECT * FROM combo_list WHERE keyname = 'combo_tinggal' ORDER BY keyval ASC ");
						while ($tampil = mysql_fetch_array($sqlx)) {
						echo '<option value='.$tampil['keyval'].'>'.$tampil['keyval'].'</option>';
						}
						?>
					</select>      
				</td>
			</tr>
				<?php } ?>
				<tr>
					<td>Sekolah Asal</td>
					<td><input type="text" class="bg2"name="sekolah"  size="50"/></td>
				</tr>
				<tr>
					<td>Nilai UN</td>
					<td>
					<?php 
				if ($form_detnilai['nilai'] == 1){
				?>
					<input type="text" class="bg7"name="mat"  size="5" placeholder="Matematika" <?php if ($form_detnilai['nilai_b'] == 1){ echo 'required'; }?> />
					<input type="text" class="bg7"name="ingg"  size="5" placeholder="B. Inggris" <?php if ($form_detnilai['nilai_b'] == 1){ echo 'required'; }?> />
					<input type="text" class="bg7" name="ind"  size="5" placeholder="B. Indonesia" <?php if ($form_detnilai['nilai_b'] == 1){ echo 'required'; }?> />
					<input type="text" class="bg7" name="ipa"  size="5" placeholder="IPA" <?php if ($form_detnilai['nilai_b'] == 1){ echo 'required'; }?> /><?php } ?>
					<input type="text" class="bg7" name="jumlah"  size="8" placeholder="Jumlah" required />
					</td>
				</tr>
				<tr>
					<td colspan="2"><b>Keterangan  Orang Tua Kandung<b></td>
				</tr>
				<?php 
				if ($form_ayah['nilai'] == 1){
				?>
				<tr>
					<td>Nama Ayah</td>
					<td><input type="text" class="bg2"  name="ayah"  size="50" <?php if ($form_ayah['nilai_b'] == 1){ echo 'required'; }?> /></td>
				</tr><?php } ?>
				<?php 
				if ($form_kayah['nilai'] == 1){
				?>
				<tr>
				<td>Pekerjaan Ayah</td>
				<td><select  class="bg3"  name="kerja_ayah" <?php if ($form_kayah['nilai_b'] == 1){ echo 'required'; }?> >
						<option value="">Silahkan Pilih</option>
						<?php 
						$sqlx = mysql_query("SELECT * FROM combo_list WHERE keyname = 'combo_kerja' ORDER BY keyval ASC ");
						while ($tampil = mysql_fetch_array($sqlx)) {
						echo '<option value='.$tampil['keyval'].'>'.$tampil['keyval'].'</option>';
						}
						?>
					</select>      
				</td>
			</tr><?php } ?>
			<?php 
				if ($form_dayah['nilai'] == 1){
				?>
			<tr>
				<td>Pendidikan Ayah </td>
				<td><select  class="bg3"  name="pendidikan_ayah" <?php if ($form_dayah['nilai_b'] == 1){ echo 'required'; }?> >
						<option value="">Silahkan Pilih</option>
						<?php 
						$sqlx = mysql_query("SELECT * FROM combo_list WHERE keyname = 'combo_didik' ORDER BY keyval ASC ");
						while ($tampil = mysql_fetch_array($sqlx)) {
						echo '<option value='.$tampil['keyval'].'>'.$tampil['keyval'].'</option>';
						}
						?>
					</select>      
				</td>
			</tr><?php } ?>
			<?php 
				if ($form_ibu['nilai'] == 1){
				?>
			<tr>
					<td>Nama Ibu</td>
					<td><input type="text" class="bg2"  name="ibu"  size="50" <?php if ($form_ibu['nilai_b'] == 1){ echo 'required'; }?> /></td>
				</tr><?php } ?>
				<?php 
				if ($form_kibu['nilai'] == 1){
				?>
				<tr>
				<td>Pekerjaan Ibu</td>
				<td><select  class="bg3"  name="kerja_ibu" <?php if ($form_kibu['nilai_b'] == 1){ echo 'required'; }?> >
						<option value="">Silahkan Pilih</option>
						<?php 
						$sqlx = mysql_query("SELECT * FROM combo_list WHERE keyname = 'combo_kerja' ORDER BY keyval ASC ");
						while ($tampil = mysql_fetch_array($sqlx)) {
						echo '<option value='.$tampil['keyval'].'>'.$tampil['keyval'].'</option>';
						}
						?>
					</select>      
				</td>
			</tr><?php } ?>
			<?php 
				if ($form_dibu['nilai'] == 1){
				?>
			<tr>
				<td>Pendidikan Ibu </td>
				<td><select  class="bg3"  name="pendidikan_ibu" <?php if ($form_dibu['nilai_b'] == 1){ echo 'required'; }?> >
						<option value="">Silahkan Pilih</option>
						<?php 
						$sqlx = mysql_query("SELECT * FROM combo_list WHERE keyname = 'combo_didik' ORDER BY keyval ASC ");
						while ($tampil = mysql_fetch_array($sqlx)) {
						echo '<option value='.$tampil['keyval'].'>'.$tampil['keyval'].'</option>';
						}
						?>
					</select>      
				</td>
			</tr><?php } ?>
			<?php 
				if ($form_penghasilan['nilai'] == 1){
				?>
			<tr>
				<td>Penghasilan Ortu</td>
				<td>
				
				<select  class="bg3"  name="penghasilan" <?php if ($form_penghasilan['nilai_b'] == 1){ echo 'required'; }?> >
						<option value="">Silahkan Pilih</option>
						<?php 
						$sqlx = mysql_query("SELECT * FROM combo_list WHERE keyname = 'combo_penghasilan' ORDER BY keyval ASC ");
						while ($tampil = mysql_fetch_array($sqlx)) {
						echo '<option value='.$tampil['keyval'].'>'.$tampil['keyval'].'</option>';
						}
						?>
					</select>  
				</td>
			</tr><?php } ?>



			<tr>
				<td><button type="submit" value="Simpan" name="Simpan" class="button">Daftar Sekarang</button></td>
				<td></td>
			</tr>
			</tr>
			
                </form>
				</table>
<?php
} else {
	echo 'Pendaftaran Ditutup';
}
?>
				
	


