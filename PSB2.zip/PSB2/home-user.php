<?php
echo "<meta http-equiv='refresh' content='0; url=home.php?page=hal&id=29'>";
?>