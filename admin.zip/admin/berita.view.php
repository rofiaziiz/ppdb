<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<body>
	<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Berita</h4>
    </ul>

	<a href="admin.php?page=berita.add" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-plus"></i>Tambah</a>
    <div class="box-content">
	<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
	    <thead>
			<tr>
				<th>No.</th>
				<th>Judul</th>
				<th>Aksi 	</th>
			</tr>
			</thead>
			<tbody>
		<?php
			$sql = mysql_query("SELECT * FROM tbl_berita");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				
				echo '<tr>';
					echo '<td>'.$no.'</td>';	//menampilkan nomor urut
					echo '<td>'.$tampil['judul'].'</td>';
					echo '<td><a href="?page=berita.edit&amp;id_berita='.$tampil['id_berita'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a>
							<a href="?page=berita.hapus&amp;id='.$tampil['id_berita'].'" onclick="return confirm(\'Yakin?\')" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-trash"></i></a></td>';
						 	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
					
			}
		?>
		</tbody>
		</table>

	</body>
</html>
</div>
