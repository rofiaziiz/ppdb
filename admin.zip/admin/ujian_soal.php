    <div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">
            <h4>Bank Soal</h4>
    </ul>
        <p>
        <?php
		$query=mysql_query("select * from tabel_soal order by id_soal DESC , publish DESC");
		?><table width="100%"><?php
		$no=0;
		while($row=mysql_fetch_array($query)){
		?>
			<tr>
           		<td><?php echo $no=$no+1;?>.</font></td><td><strong><?php echo $row['pertanyaan'];?></strong></font></td>
            </tr>
            <tr>
           		<td></td><td>A) <?php echo $row['pilihan_a'];?></font></td>
            </tr>
            <tr>
           		<td></td><td>B) <?php echo $row['pilihan_b'];?></font></td>
            </tr>
            <tr>
           		<td></td><td>C) <?php echo $row['pilihan_c'];?></font></td>
            </tr>
            <tr>
           		<td></td><td>D) <?php echo $row['pilihan_d'];?></font></td>
            </tr>
            <tr>
           		<td></td><td>JAWABAN : <b><?php echo $row['jawaban'];?></b> &raquo; PUBLISH : <b><?php echo ucwords($row['publish']);?></b> &raquo;
                <a href="?page=ujian_edit&id=<?php echo $row['id_soal']?>" title="Edit">Edit</a> | <a href="?page=ujian_hapus&id=<?php echo $row['id_soal']?>" title="Delete" onclick="return confirm('Apakah anda yakin akan menghapus pertanyaan ini ?')">Hapus</a>
                </td>
            </tr>

		<?php
		}
		?>
        </table>
        </p>
</div>