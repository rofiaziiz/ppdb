<div>
<?php


	$id=$_GET['id'];
	
	$query=mysql_query("delete from tabel_soal where id_soal='$id'");
	
	if($query){
		?><script language="javascript">document.location.href="?page=ujian_soal"</script><?php
	}else{
		echo mysql_error();
	}

