<?php
$id_admin=$_POST['id_admin'];
$password=md5($_POST['password']);

$query=mysql_query("select * from tbl_admin where id_admin='$id_admin' and password='$password'");
$cek=mysql_num_rows($query);
$row=mysql_fetch_array($query);
$id_admin=$row['id_admin'];

if($cek){
	$_SESSION['id_admin']=$id_admin;
	header('Location:admin.php');
}else{
	?>
    <div id="main"> <a name="TemplateInfo"></a>
	<blockquote>
	  <p></p>
	  <p><font color="#FF0000">Username atau Password anda salah!!</font>. silahkan ulangi Login</p>
	  <p></p>
	</blockquote>
    </div>
	<?php
}
?>