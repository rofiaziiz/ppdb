
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">
            <h4>Data Calon Siswa</h4>
    </ul>

 
    <div class="box-content">
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
		<th>No.</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>PIN</th>
		<th>Asal Sekolah</th>
		<th>Jumlah Nilai</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
	<?php
		include "../config/func.php";
		$blnth = date('Y');

		

			$sql = mysql_query("SELECT * FROM biodata_sd
			
			WHERE date_format(tgl_daftar,'%Y') = '$blnth'
			order by id_utama DESC
			");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
			$no++;
			if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
			echo '<tr bgcolor='.$warna.'>';
				echo '<td>            ' .$no.'</td>';
				echo '<td>'.$tampil['nisn'].'</td>';
				echo '<td>'.$tampil['nama'].'</td>';
				echo '<td>'.$tampil['password'].'</td>';
				echo '<td>'.$tampil['sekolah'].'</td>';
				echo '<td>'.$tampil['jumlah'].'</td>';
				echo '<td>
						<a href="?page=detail&amp;id='.$tampil['id_utama'].'" class="btn btn-xs btn-default" ><i class="glyphicon glyphicon-zoom-in"></i></a>
						<a href="../cetak/pendaftar_cetak_sd.php?id='.$tampil['id_utama'].'" target="_blank" class="btn btn-xs btn-info"><i class="glyphicon glyphicon-print"></i></a>
						<a href="?page=pendaftar_edit_sd&amp;id='.$tampil['id_utama'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a>
						<a href="?page=pendaftar_hapus_sd&amp;id='.$tampil['id_utama'].'" onclick="return confirm(\'Yakin untuk menghapus data ini?\')" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-trash"></i></a></td>';
				echo '</tr>';
			}
	?>
    </tbody>
    </table>
    </div>
    </div>
</body>