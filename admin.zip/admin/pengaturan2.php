		<link href="jquery-ui/jquery-ui.css" rel="stylesheet">
		<script src="jquery-ui/external/jquery/jquery.js"></script>
		<script src="jquery-ui/jquery-ui.js"></script>	
		
	<script>
			$(document).ready(function(){
				$("#tabs").tabs();
			});
	</script>
	<?php
		include "fungsi_indotgl.php"
	?>
	<div id="content" class="col-lg-12 col-sm-12">
		<ul class="breadcrumb">
            <h4>Pengaturan</h4>
		</ul>
		
	<div id="tabs">	
		<ul>
			<li><a href="#tabs-1">Kuota & Batas Pendaftaran</a></li>
			<li><a href="#tabs-2">Pengumuman</a></li>
			<li><a href="#tabs-5">Kartu Peserta</a></li>
		</ul>
	
		<div id="tabs-1">		
			<table class="table-list" width="50%">			
				<?php
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_mahasiswa'");
					$no=0;
					while ($tampil_smp = mysql_fetch_array($sql)) 
					{			
						$no++;
							// gradasi warna
							if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
							echo '<tr bgcolor='.$warna.'>';
							echo '<td>Kuota Penerimaan SMP </td>';
							echo '<td>:</td>';
							echo '<td>'.$tampil_smp['nilai'].' Siswa</td>';
							echo '<td><a href="?page=setting.edit&amp;id='.$tampil_smp['id'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a>
							</td>';
							//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
						echo '</tr>';
					}
				?>		
				<?php	
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_tanggal'");
					$no=0;
					while ($tampil = mysql_fetch_array($sql)) 
					{
						$no++;
						// gradasi warna
						if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}				
						$nn = tgl_indo($tampil['nilai']);
					}
				?>		
				<td>Batas Pendaftaran</td>
				<td>:</td>
				<td><? echo $nn ?></td>		
					<?php echo '<td><a href="?page=setting.edit2&amp;id=2" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a> '
					?>
			</table>
			
			<table class="table-list" width="50%">			
				<?php
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_sd'");
					$no=0;
					while ($tampil_sd = mysql_fetch_array($sql)) 
					{			
						$no++;
							// gradasi warna
							if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
							echo '<tr bgcolor='.$warna.'>';
							echo '<td>Kuota Penerimaan SD </td>';
							echo '<td>:</td>';
							echo '<td>'.$tampil_sd['nilai'].' Siswa</td>';
							echo '<td><a href="?page=setting.edit_sd&amp;id='.$tampil_sd['id'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a>
							</td>';
							//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
						echo '</tr>';
					}
				?>		
				<?php	
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_tanggal_sd'");
					$no=0;
					while ($tampil = mysql_fetch_array($sql)) 
					{
						$no++;
						// gradasi warna
						if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}				
						$nn = tgl_indo($tampil['nilai']);
					}
				?>		
				<td>Batas Pendaftaran</td>
				<td>:</td>
				<td><? echo $nn ?></td>		
					<?php echo '<td><a href="?page=setting.edit_sd&amp;id=34" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a> '
					?>
			</table>
			
			<table class="table-list" width="50%">			
				<?php
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_tk'");
					$no=0;
					while ($tampil_tk = mysql_fetch_array($sql)) 
					{			
						$no++;
							// gradasi warna
							if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
							echo '<tr bgcolor='.$warna.'>';
							echo '<td>Kuota Penerimaan TK </td>';
							echo '<td>:</td>';
							echo '<td>'.$tampil_tk['nilai'].' Siswa</td>';
							echo '<td><a href="?page=setting.edit_tk&amp;id='.$tampil_tk['id'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a>
							</td>';
							//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
						echo '</tr>';
					}
				?>		
				<?php	
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_tanggal_tk'");
					$no=0;
					while ($tampil = mysql_fetch_array($sql)) 
					{
						$no++;
						// gradasi warna
						if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}				
						$nn = tgl_indo($tampil['nilai']);
					}
				?>		
				<td>Batas Pendaftaran</td>
				<td>:</td>
				<td><? echo $nn ?></td>		
					<?php echo '<td><a href="?page=setting.edit_tk&amp;id=33" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a> '
					?>
			</table>
		</div>
		
		<div id="tabs-2">		
			<table class="table-list" width="50%">			
				<?php
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_pengumuman'");
					$no=0;
					while ($tampil = mysql_fetch_array($sql)) 
					{
						$no++;
						// gradasi warna
						if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}			
								echo '<tr bgcolor='.$warna.'>';
								echo '<td>Status Pengumuman </td>';
								echo '<td>:</td>';
								echo '<td>'.$tampil['nilai'].' </td>';
								echo '<td><a href="?page=setting.edit3&amp;id='.$tampil['id'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a></td>';						
								//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
								echo '</tr>';
					}
				?>
				<?php
			
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama='limit_tanggal'");
					$no=0;
					while ($tampil = mysql_fetch_array($sql)) {
						$no++;
						// gradasi warna
						if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
						
						$nn = tgl_indo($tampil['nilai']);
					}
				?>
			</table>
		</div>
	
	
			<div id="tabs-5">	
<table class="table-list" width="60%">
		
			<?php
			$sql = mysql_query("SELECT * FROM seting limit 5,5");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.$tampil['nama'].'</td>';
					echo '<td>:</td>';
						echo '<td>'.$tampil['nilai'].'</td>';
						echo '<td><a href="?page=statis.edit&amp;id='.$tampil['id'].'" class="btn btn-xs btn-success"> Edit</a> </td>';
						
							  	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
			}
		?></table></div>
		
	
		
</div>


	
	</body>
</html>