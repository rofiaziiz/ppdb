<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<body>
	<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Konfigurasi Halaman Statis</h4>
    </ul>

	<a href="admin.php?page=konfig_tambah" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-plus"></i>Tambah</a>
    <div class="box-content">
	<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
	    <thead>
			<tr>
				<th>No.</th>
				<th>Menu</th>
				<th>Urutan</th>
				<th>Tampil Pada</th>
				<th>Opsi</th>
			</tr>
			</thead>
			<tbody>
		<?php
			$sql = mysql_query("SELECT * FROM konfigurasi WHERE nama = 'halaman' ");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				
				echo '<tr>';
					echo '<td>'.$no.'</td>';	//menampilkan nomor urut
					echo '<td>'.$tampil['nilai'].'</td>';
					echo '<td>'.$tampil['nilai_c'].'</td>';
					echo '<td>';
						if ($tampil['nilai_d'] == 1){
							echo 'Sebelum Login';
						} else if ($tampil['nilai_d'] == 2){
							echo 'Sesudah Login';
						} else {
							echo 'Keduanya';
						}
					echo '</td>';
					echo '<td><a href="?page=konfig_edit&amp;id='.$tampil['id'].'" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a>
							<a href="?page=konfig_hapus&amp;id='.$tampil['id'].'" onclick="return confirm(\'Yakin Loe?\')" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-trash"></i></a></td>';
						 	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
					
			}
		?>
		</tbody>
		</table>
