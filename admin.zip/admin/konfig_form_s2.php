<?php

	if (isset($_POST['submit2'])) {


		$id = $_POST['id'];
		$jwb 	= $_POST['jwb'];



		if (count($id) > 0) {
			

			for ($i=0; $i < count($id); $i++) { 


		mysql_query("UPDATE konfigurasi SET nilai='$jwb[$i]'  WHERE id='$id[$i]'  ")or die(mysql_error());					
		}
//echo '<script>window.history.back()</script>';

	echo "<meta http-equiv='refresh' content='0; url=?page=konfig_form'>";
		}
		else
		{
			echo"Tidak ada nilai yang di inputkan!";
		}
	}

?>