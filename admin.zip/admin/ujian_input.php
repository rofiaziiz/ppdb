<?php

	if (isset($_POST['submit'])){
		
		$pertanyaan=$_POST['pertanyaan'];
		$pilihan_a=$_POST['pilihan_a'];
		$pilihan_b=$_POST['pilihan_b'];
		$pilihan_c=$_POST['pilihan_c'];
		$pilihan_d=$_POST['pilihan_d'];
		$jawaban=$_POST['jawaban'];
		$publish=$_POST['publish'];
		
		$query=mysql_query("insert into tabel_soal values('','$pertanyaan','$pilihan_a','$pilihan_b','$pilihan_c','$pilihan_d','$jawaban','$publish')");
		
		if($query){
			?><script language="javascript">document.location.href="?page=ujian_input";</script><?php
		}else{
			echo mysql_error();
		}
		
	}else{
		unset($_POST['submit']);
	}
	?>

    <div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">
            <h4>Input Soal</h4>
    </ul>
		<form action="?page=ujian_input" method="post">
			<table class="datatable" align="left">
				<tr>
					<td width="29%" height="37" valign="top"><font size="2" face="verdana"><p>Pertanyaan</p></font></td>
				<td><textarea cols="90" rows="5" name="pertanyaan" ></textarea></td>
				</tr>
				<tr>
					<td width="29%" height="37" valign="middle"><font size="2" face="verdana"><p>Pilihan A</p></font></td>
					<td><input type="text" name="pilihan_a" size="100"/></td>
				</tr>
				<tr>
					<td width="29%" height="37" valign="middle"><font size="2" face="verdana"><p>Pilihan B</p></font></td>
					<td><input type="text" name="pilihan_b" size="100"/></td>
				</tr>
				 <tr>
					<td width="29%" height="37" valign="middle"><font size="2" face="verdana"><p>Pilihan C</p></font></td>
					<td><input type="text" name="pilihan_c" size="100"/></td>
				</tr>
				 <tr>
					<td width="29%" height="37" valign="middle"><font size="2" face="verdana"><p>Pilihan D</p></font></td>
					<td><input type="text" name="pilihan_d" size="100"/></td>
				</tr>
				<tr>
				<td width="29%" height="17" valign="middle"><font size="2" face="verdana"><p><b>JABAWAN</b></p></font></td>
				<td>
					<select name="jawaban">
						<option value="a">A</option>
						<option value="b">B</option>
						<option value="c">C</option>
						<option value="d">D</option>
					</select>
				</td>
				</tr>
				<tr>
					<td width="29%" height="37" valign="middle"><font size="2" face="verdana"><p><b>PUBLISH</b></p></font></td>
					<td>
					<select name="publish">
						<option value="yes">Yes</option>
						<option value="no">No</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td width="71%"><input name="submit" type="submit" value="Simpan" />&nbsp;</td>
				</tr>
			</table>
    </form>
</div>