<?php

	if (isset($_POST['submit'])) {

		//$nilaix = $_POST['nilaix'];
/* 		$id_k = $_POST['id'];
		$jd = $_POST['jd']; */

		
		foreach ($_POST['show'] as $answerNum => $answer) 
	{
			echo $answer;
			echo '<br>';
			$separate = explode ("-",$answer);
			$id 	= $separate[0];
			$hdr = $separate[1];

			$query			= mysql_query("UPDATE konfigurasi SET nilai = '$hdr' WHERE id='$id'");
	}
	
		foreach ($_POST['req'] as $answerNumx => $answerx) 
	{
			echo $answerx;
			echo '<br>';
			$separatex = explode ("-",$answerx);
			$idx	= $separatex[0];
			$hdrx = $separatex[1];

			$query2			= mysql_query("UPDATE konfigurasi SET nilai_b = '$hdrx' WHERE id='$idx'");
	}
			echo "<meta http-equiv='refresh' content='0; url=?page=konfig_form'>";
}
?>
	