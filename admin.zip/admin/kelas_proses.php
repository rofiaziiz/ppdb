<div id="main"> <a name="TemplateInfo"></a>
<?php
if(isset($_POST['kirim'])){
	$id_kelas=$_POST['id_kelas'];
	$nama_kelas=$_POST['nama_kelas'];
	$daya_tampung=$_POST['daya_tampung'];

	$query=mysql_query("insert into kelas(id_kelas,nama_kelas,daya_tampung) 
						values('$id_kelas','$nama_kelas','$daya_tampung')");
						
	if($query){
		?>
			<?
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=kelas_view'>"; ?>
		<?php
	}else{
		echo mysql_query();
	}

}else{
	unset($_POST['kirim']);
}
?>
</div>