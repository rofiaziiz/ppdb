<div id="main"> <a name="TemplateInfo"></a>
<?php
$query=mysql_fetch_array(mysql_query("select * from tbl_admin where id_admin='$id_admin'"));
	$nama=$query['nama'];

echo "<h2>Selamat Datang</h2>
          <p>Hai <b>$nama</b>, selamat datang di halaman Administrator.
          Silahkan klik menu pilihan yang berada di sebelah kiri untuk mengelola website. </p>

		<p>&nbsp;</p>";
  echo "</p>";
?>

</div>

<table>
		<th colspan=5><center>Control Panel</center></th>
		<tr>
		  <td width=120 align=center><a href="admin.php?page=adm.view"><img src=images/user-settings-icon.png width="97" height="105"  border=none></a></td>
		  <td width=120 align=center><a href="admin.php?page=berita.view"><img src=images/mail-open-icon.png  width="97" height="105" border=none></a></td>
		  <td width=120 align=center><a href="admin.php?page=daftar.siswa2"><img src=images/document-checkbox-icon.png  width="97" height="105" border=none></a></td>
		  <td width=120 align=center><a  href="admin.php?page=daftar.terima"><img src=images/profile-check-icon.png  width="97" height="105" border=none></a></td>
		  <td width=120 align=center><a  href="admin.php?page=daftar.tolak"><img src=images/profile-delete-icon.png  width="97" height="105" border=none></a></td>
    </tr>
			<tr>
		  <th width=120><b>Manajemen User</b></th>
		  <th width=120><b>Berita PSB</b></center></th>
		  <th width=120><b>Pendaftar</b></th>
		  <th width=120><b>DIterima</b></th>
		  <th width=120><b>Ditolak</b></th>
		</tr>
	</th>
	<th colspan=5><center></center></th>
		<tr>
		  <td width=120 align=center><a href="admin.php?page=verifikasi"><img src=images/user-settings-icon.png width="97" height="105"  border=none></a></td>
		  <td width=120 align=center><a href="admin.php?page=prestasi"><img src=images/application-settings-icon.png  width="97" height="105" border=none></a></td>
		  <td width=120 align=center><a href="admin.php?page=pengaturan"><img src=images/database-check-icon.png  width="97" height="105" border=none></a></td>
		  <td width=120 align=center><a href="admin.php?page=pengaturan2"><img src=images/tool-edit-icon.png  width="97" height="105" border=none></a></td>

    </tr>
			<tr>
		  <th width=120><b>Verifikasi</b></th>
		  <th width=120><b>Nilai Prestasi</b></center></th>
		  <th width=120><b>Halaman Statis</b></th>
		  <th width=120><b>Pengaturan</b></th>

		</tr>
	</th>
	</table>