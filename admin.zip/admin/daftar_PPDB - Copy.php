
<link rel="stylesheet" href="datepicker/themes/base/jquery.ui.all.css">
	<script src="datepicker/js/jquery-1.7.2.js"></script>
	<script src="datepicker/ui/jquery.ui.core.js"></script>
	<script src="datepicker/ui/jquery.ui.widget.js"></script>
	<script src="datepicker/ui/jquery.ui.datepicker.js"></script>
<script>
	$(function() {
		$( "#datepicker" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});
	</script>

	<?php
include "../config/koneksi.php";
include "../config/library.php";

include "../config/function_acak.php";
include "../config/Generate_Password.php";

error_reporting(0);
$passacak = acak(6); 
# TOMBOL SIMPAN DIKLIK
if(isset($_POST['Simpan'])){
	# Baca Variabel Form

	$nama		=$_POST['nama'];

	$jenis_kel		=$_POST['jenis_kel'];
	$tempat_lahir		=$_POST['tempat_lahir'];
	$tgl_lahir		=$_POST['tgl_lahir'];
	$agama	=($_POST['agama']);
	$desa		=$_POST['desa'];
	$kecamatan		=$_POST['kecamatan'];
	$kabupaten		=$_POST['kabupaten'];
	$provinsi		=$_POST['provinsi'];
	$sekolah	=$_POST['sekolah'];
	$telepon		=$_POST['telepon'];
	$mat		=$_POST['mat'];
	$ind		=$_POST['ind'];
	$ingg		=$_POST['ingg'];
	$ipa		=$_POST['ipa'];
	$jumlah		=$_POST['jumlah'];
	$ayah		=$_POST['ayah'];
	$kerja_ayah		=$_POST['kerja_ayah'];
	$ibu		=$_POST['ibu'];
	$tampil_password		=$_POST['tampil_password'];
	
	$penghasilan		=$_POST['penghasilan'];
	$nisn		=$_POST['nisn'];
	$password	=md5($_POST['password']);
	$tampil_password		=$_POST['tampil_password'];
	$tgl_daftar		=$_POST['tgl_daftar'];
	# Validasi form, jika kosong sampaikan pesan error


	# VALIDASI Email DI DATABASE, jika sudah ada akan ditolak
	$sqlCek="SELECT * FROM biodata WHERE nisn='$nisn'";
	$qryCek=mysql_query($sqlCek) or die ("Eror Query".mysql_error()); 
	if(mysql_num_rows($qryCek)>=1){
		$pesanError[] = "Maaf, NISN <b> $nisn </b> sudah ada, ganti dengan yang lain";
	}

	if(trim($nama)=="") {
		$pesanError[] = "<b>Nama</b> tidak boleh kosong, harus diisi !";		
	}
		if(trim($nisn)=="") {
		$pesanError[] = "<b>NISN</b> tidak boleh kosong, harus diisi !";		
	}

	if(trim($tempat_lahir)=="") {
		$pesanError[] = "<b>Tempat Lahir</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($tgl_lahir)=="") {
		$pesanError[] = "<b>Tanggal Lahir</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($agama)=="") {
		$pesanError[] = "<b>Agama</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($kabupaten)=="") {
		$pesanError[] = "<b>Kabupaten</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($provinsi)=="") {
		$pesanError[] = "<b>Provinsi</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($sekolah)=="") {
		$pesanError[] = "<b>Sekolah</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($mat)=="") {
		$pesanError[] = "<b>Nilai Matematika</b> tidak boleh kosong, Silahkan diisi !";		
	}
	if(trim($ipa)=="") {
		$pesanError[] = "<b>Nilai IPA</b> tidak boleh kosong, Silahkan diisi !";		
	}
		if(trim($ingg)=="") {
		$pesanError[] = "<b>Nilai Bahasa Inggris</b> tidak boleh kosong, Silahkan diisi !";		
	}
		if(trim($ind)=="") {
		$pesanError[] = "<b>Nilai Bahasa Indonensia</b> tidak boleh kosong, Silahkan diisi !";		
	}
		if(trim($jumlah)=="") {
		$pesanError[] = "<b>Jumlah Nilai Ujian Nasional</b> tidak boleh kosong, Silahkan diisi !";		
	}
		if(trim($ayah)=="") {
		$pesanError[] = "<b>Nama Ayah</b> tidak boleh kosong, Silahkan diisi !";		
	}

	# JIKA ADA PESAN ERROR DARI VALIDASI
	if (count($pesanError)>=1 ){
		echo "<div class='mssgBox'>";
		echo "<img src='../images/belum.png' width='36px'> Maaf, Anda Belum Mengisi / Melengkapi Formulir<br><hr>";
			$noPesan=0;
			foreach ($pesanError as $indeks=>$pesan_tampil) { 
			$noPesan++;
				echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
			} 
		echo "</div> <br>"; 
	}
	else {
		# SIMPAN DATA KE DATABASE. Jika tidak menemukan pesan error, simpan data ke database
		// Membuat Kode Siswa
				# SKRIP UNTUK MENYIMPAN FOTO/GAMBAR
		if (! empty($_FILES['namaFile']['tmp_name'])) {
			// Membaca nama file foto/gambar
			$file_foto = $_FILES['namaFile']['name'];
			$file_foto = stripslashes($file_foto);
			$file_foto = str_replace("'","",$file_foto);
			
			// Simpan gambar
			$file_foto = $kodeBaru.".".$file_foto;
			copy($_FILES['namaFile']['tmp_name'],"photo/".$file_foto);
		}
		else {
			// Jika tidak ada foto/gambar
			$file_foto = "";
		}
		


		// Simpan data dari form ke Database
		$mySql	= "INSERT INTO biodata ( 
									id_utama, nama,password,jenis_kel, tgl_lahir, tempat_lahir, agama, tgl_daftar, photo, tampil_password, telepon, desa,kecamatan,kabupaten, provinsi, 
									mat,ind,ingg, ipa, jumlah,sekolah, ayah,kerja_ayah,ibu, penghasilan, nisn )
							VALUES ( 
									'$id_utama','$nama','$password','$jenis_kel','$tgl_lahir','$tempat_lahir','$agama','$tgl_daftar','$file_foto','$tampil_password','$telepon','$desa','$kecamatan','$kabupaten','$provinsi',
									'$mat','$ind','$ingg','$ipa','$jumlah','$sekolah','$ayah','$kerja_ayah','$ibu','$penghasilan','$nisn'
									)";		

		$myQry	= mysql_query($mySql) or die ("Gagal Cuy query".mysql_error());

		if($myQry) 
		
		
		{
			?>
		<script type="text/javascript">
			alert("Data berhasil ditambahkan");
		</script>
			<?
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=daftar.siswa2'>";
					
					
				?>	
					

					
					
				
			<?php
		}
		exit;
	}	
} // Penutup POST

# MEMBUAT NILAI DATA PADA FORM

$nama		= isset($_POST['nama']) ? $_POST['nama'] : '';
$nisn	= isset($_POST['nisn']) ? $_POST['nisn'] : '';

$jenis_kel	= isset($_POST['jenis_kel']) ? $_POST['jenis_kel'] : '';
$tempat_lahir	= isset($_POST['tempat_lahir']) ? $_POST['tempat_lahir'] : '';
$tgl_lahir	= isset($_POST['tgl_lahir']) ? $_POST['tgl_lahir'] : '';
$agama	= isset($_POST['agama']) ? $_POST['agama'] : '';
$desa	= isset($_POST['desa']) ? $_POST['desa'] : '';
$kecamatan	= isset($_POST['kecamatan']) ? $_POST['kecamatan'] : '';
$kabupaten	= isset($_POST['kabupaten']) ? $_POST['kabupaten'] : '';
$provinsi	= isset($_POST['provinsi']) ? $_POST['provinsi'] : '';
$photo	= isset($_POST['photo']) ? $_POST['photo'] : '';
$sekolah	= isset($_POST['sekolah']) ? $_POST['sekolah'] : '';
$telepon	= isset($_POST['telepon']) ? $_POST['telepon'] : '';
$mat	= isset($_POST['mat']) ? $_POST['mat'] : '';
$ind	= isset($_POST['ind']) ? $_POST['ind'] : '';
$ingg	= isset($_POST['ingg']) ? $_POST['ingg'] : '';
$ipa	= isset($_POST['ipa']) ? $_POST['ipa'] : '';
$jumlah	= isset($_POST['jumlah']) ? $_POST['jumlah'] : '';
$ibu	= isset($_POST['ibu']) ? $_POST['ibu'] : '';
$ayah	= isset($_POST['ayah']) ? $_POST['ayah'] : '';
$kerja_ayah	= isset($_POST['kerja_ayah']) ? $_POST['kerja_ayah'] : '';
$penghasilan	= isset($_POST['penghasilan']) ? $_POST['penghasilan'] : '';



?>
<h2>Formulir Pendaftaran</h2>
<p>Isilah Formulir ini dengan lengkap dan benar!</p>
 <form id="newsletter" enctype="multipart/form-data"  method="post" name="postform" onsubmit="_validasi();">
   <table width="105%">

				<tr>
					<td>NISN</td>
					<td><input  type="text"  name="nisn"  value="<?php echo $nisn; ?>" /></td>
				</tr>
				<tr>
					<td width="140">Nama</td>
					<td><input class="bg2" type="text" name="nama"   value="<?php echo $nisn; ?>"/></td>
				</tr>
					<input hidden type="text" name="password"  value="<?php   echo $passacak; ?>" size="50"/>
                <tr>
				<td>Jenis Kelamin</td>
				<td><select class="bg3" name="jenis_kel" >
						<option value="0">...
						<option value="Laki-Laki" <?php if($jenis_kel=='Laki-Laki'){ echo "selected='selected'";} ?>>Laki-laki
						<option value="Perempuan" <?php if($jenis_kel=='Perempuan'){ echo "selected='selected'";} ?>>Perempuan
					</select>      
				</td>
			</tr>
				<tr>
					<td>Tempat Lahir</td>
					<td><input type="text" class="bg3"name="tempat_lahir" value="<?php   echo $tempat_lahir; ?>" /></td>
				</tr>
							<tr>
					<td>Tanggal Lahir</td>
					<td><input type="text" name="tgl_lahir"  class="bg3" value="<?php   echo $tgl_lahir; ?>" size="50" id="datepicker"/>
					</td>
				</tr>
				<tr>
				<td>Agama</td>
				<td><select class="bg3" name="agama" >
						<option value="0">...
						<option value="Islam" <?php if($agama=='Islam'){ echo "selected='selected'";} ?>>Islam
						<option value="Kristen" <?php if($agama=='Kristen'){ echo "selected='selected'";} ?>>Kristen
						<option value="Katolik" <?php if($agama=='Katolik'){ echo "selected='selected'";} ?>>Katolik
						<option value="Hindu" <?php if($agama=='Hindu'){ echo "selected='selected'";} ?>>Hindu
						<option value="Budha" <?php if($agama=='Budha'){ echo "selected='selected'";} ?>>Budha
						<option value="Konghucu" <?php if($agama=='Konghucu'){ echo "selected='selected'";} ?>>Konghucu
					</select>      
				</td>
			</tr>
			<tr>
					<td>Alamat</td>
					<td><input type="text" class="bg3" name="desa"  placeholder="Desa/Kelurahan" size="15" value="<?php   echo $desa; ?>" />
					<input type="text" class="bg3" name="kecamatan"  placeholder="Kecamatan" size="20" value="<?php   echo $kecamatan; ?>" />
					<input type="text" class="bg3" onkeyup="this.value = this.value.toLowerCase()"  name="kabupaten"  placeholder="Kabupaten" value="<?php   echo $kabupaten; ?>"  size="20"/>
					<input type="text" class="bg3" name="provinsi"  placeholder="Provinsi" size="20" value="<?php   echo $provinsi; ?>" />
					</td>
				</tr>
				<tr>
					<td>Photo</td>
					<td><input type="file" class="bg3" name="namaFile"   size="50" /></td>
				</tr>
					<tr>
					<td>No. Telp</td>
					<td><input type="text" class="bg3" name="telepon" type="numeric" size="50" value="<?php   echo $telepon; ?>" /></td>
				</tr>
				<tr>
					<td>Sekolah Asal</td>
					<td><input type="text" class="bg2"name="sekolah"  size="50" value="<?php   echo $sekolah; ?>" /></td>
				</tr>
				<tr>
					<td>Nilai UN</td>
					<td><input type="text" class="bg7"name="mat"  size="5" placeholder="Matematika" value="<?php   echo $mat; ?>" />
					<input type="text" class="bg7"name="ingg"  size="5" placeholder="B. Inggris" value="<?php   echo $ingg; ?>" />
					<input type="text" class="bg7" name="ind"  size="5" placeholder="B. Indonesia" value="<?php   echo $ind; ?>" />
					<input type="text" class="bg7" name="ipa"  size="5" placeholder="IPA" value="<?php   echo $ipa; ?>" />
					<input type="text" class="bg7" name="jumlah"  size="8" placeholder="Jumlah" value="<?php   echo $jumlah; ?>" />
					</td>
				</tr>
				<tr>
					<td>Nama Ayah</td>
					<td><input type="text" class="bg2"  name="ayah"  size="50" value="<?php   echo $ayah; ?>" /></td>
				</tr>
				<tr>
				<td>Pekerjaan Ayah</td>
				<td><select  class="bg3"  name="kerja_ayah"  value="<?php   echo $kerja_ayah; ?>" >
						<option value="0">...
						<option value="PNS" <?php if($kerja_ayah=='PNS'){ echo "selected='selected'";} ?>>PNS
						<option value="Wiraswasta" <?php if($kerja_ayah=='Wiraswasta'){ echo "selected='selected'";} ?>>Wiraswasta
						<option value="Buruh" <?php if($kerja_ayah=='Buruh'){ echo "selected='selected'";} ?>>Buruh
						<option value="Pedagang" <?php if($kerja_ayah=='Pedagang'){ echo "selected='selected'";} ?>>Pedagang
						<option value="Lain-lain" <?php if($kerja_ayah=='Lain-lain'){ echo "selected='selected'";} ?>>Lain-lain
					</select>      
				</td>
			</tr>
				<tr>
					<td>Nama Ibu</td>
					<td><input  class="bg2" type="text" name="ibu"  size="50" value="<?php   echo $ibu; ?>" /></td>
				</tr>
				<tr>
					<td>Penghasilan</td>
					<td><input  class="bg2"  type="text" name="penghasilan"  value="<?php   echo $penghasilan; ?>" size="50"/></td>
				</tr>
				<input hidden type="text" name="tgl_daftar"  value="<?php echo date("Y-m-d");  ?> " size="50"/>
				<input hidden type="text" name="tampil_password"  value="<?php   echo $passacak; ?>" size="50"/>
			<tr>
				<td><button type="submit" value="Simpan" name="Simpan" class="button">Simpan</button></td>
				<td></td>

			</tr>
			</tr>
			
                </form>
				</table>
				
				
	


    <!--/span-->







</body>
</html>

<!--  untuk membatu menampilkan tanggal -->
	<iframe width=174 height=189 name="gToday:normal:./calender/agenda.js" id="gToday:normal:./calender/agenda.js" src="./calender/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;">
	</iframe>