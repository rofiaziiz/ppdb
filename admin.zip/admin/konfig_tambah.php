
	<!-- TinyMCE -->
<script type="text/javascript" src="includes/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
tinyMCE.init({
        // General options
        mode : "textareas",
        theme : "advanced",
        plugins : "autolink,lists,spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

        // Theme options
        theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
        theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
        theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
        theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,spellchecker,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,blockquote,pagebreak,|,insertfile,insertimage",
        theme_advanced_toolbar_location : "top",
        theme_advanced_toolbar_align : "left",
        theme_advanced_statusbar_location : "bottom",
        theme_advanced_resizing : true,

        // Skin options
        skin : "o2k7",
        skin_variant : "black",

        // Example content CSS (should be your site CSS)
        content_css : "css/example.css",

        // Drop lists for link/image/media/template dialogs
        template_external_list_url : "js/template_list.js",
        external_link_list_url : "js/link_list.js",
        external_image_list_url : "js/image_list.js",
        media_external_list_url : "js/media_list.js",

        // Replace values for the template plugin
        template_replace_values : {
                username : "Some User",
                staffid : "991234"
        }
});
</script>
	</head>
	<?php
	if(isset($_POST['kirim'])){

	$nilai		=$_POST['nilai'];
	$nilai_b	=$_POST['nilai_b'];
	$nilai_c	=$_POST['nilai_c'];
	$nilai_d	=$_POST['nilai_d'];
	
	$query=mysql_query("INSERT INTO konfigurasi(nama,nilai,nilai_b,nilai_c,nilai_d) 
						values('halaman','$nilai','$nilai_b','$nilai_c','$nilai_d')");
						


echo "<meta http-equiv='refresh' content='0; url=admin.php?page=konfig_halaman'>";
	}

	?>
	
	<body>
	<div class="container">
			<div class="hero-unit">
		<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Tambah Halaman</h4>
    </ul>

		<form action="" method="post" name="post" enctype="multipart/form-data" target="_self">
			<table class="table-list" width="80%" >
				<tr>
					<td>Menu</td>
					<td><input type="text" name="nilai"  class="form-control" id="inputSuccess1" size="50"/></td>
				</tr>
				
				<tr>
					<tr>
								<td>Isi</td>
								<td><textarea class="ckeditor" id="elm1" name="nilai_b" class="form-control" id="inputSuccess1" rows="15" cols="60" ></textarea></td>
							</tr>
				</tr>
				<tr>
					<td>Urutan</td>
					<td><input type="text" name="nilai_c"  class="form-control" id="inputSuccess1" size="50"/></td>
				</tr>
				<tr>
					<td>Tampilkan Pada</td>
					<td>
					<select name="nilai_d" class="form-control">
						<option value="1" >Sebelum Login</option>
						<option value="2" >Sesudah Login</option>
						<option value="3" >Keduanya</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input type="submit" value="Kirim" class="btn btn-xs btn-success"name="kirim" /></td>
				</tr>
			</table>
		</form>
			
		</div>
		</div>
	</body>
</html>
</div>