
<?php
if(isset($_POST['simpan'])){

	$id_admin=$_POST['id_admin'];
	$nama=$_POST['nama'];
	$telp=$_POST['telp'];
	$password=md5($_POST['password']);
	
	$query=mysql_query("insert into tbl_admin(id_admin,nama,password,telp) 
						values('$id_admin','$nama','$password','$telp')");
						
	if($query){
		?>
				<?
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=adm.view'>";
				?>
		<?php
	}else{
		echo mysql_query();
	}

}else{
	unset($_POST['simpan']);
}
?>
