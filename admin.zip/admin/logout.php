<?php session_start();
	session_destroy();
			?>	
	<script type="text/javascript">
		alert("Anda Berhasil keluar");
	</script>
	<script>
		window.location='admin.php?page=k_keluar';
	</script>
	<?
	//header("Location:index.php");
?>