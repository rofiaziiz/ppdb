	<?php	
	$id = $_GET['id'];
$ch = $_GET['ch'];
	


		$mySql	= mysql_query("UPDATE biodata_tk SET 
		verifikasi='$ch'  WHERE id_utama='$id'");


	echo "<meta http-equiv='refresh' content='0; url=admin.php?page=verifikasi_tk'>";
?>