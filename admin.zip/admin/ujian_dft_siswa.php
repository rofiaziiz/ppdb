<?php
	include "../config/koneksi.php";
?>
<!DOCTYPE html>
    <html>
    <head>
    <title>Pilih Siswa</title>
	<script src="js/jqeuery-2.0.2.js"></script>
	<script src="js/jqueery-ui-1.10.1.custom.js"></script>
    <script>    
		$(document).ready(function(){
			$("#selectall").click(function () { //untuk checkbox
				if($(this).is(":checked")==false){ //jika checkbox tidak dicentang
					$(".eachCase").prop("checked",false);
				}else{
					$(".eachCase").prop("checked",true); //jika checkbox dicentang
				}
			});
		 
			$(".eachCase").click(function(){ //untuk men-check list semua checkbox
				if($(".eachCase").length == $(".eachCase:checked").length) {
					$("#selectall").attr("checked", "checked");
				} else {
					$("#selectall").removeAttr("checked");
				}
			}); 
			
			$("form input[ideko='hapus']").click(function() {  // jika tombol hapus diklik
				var count_checked = $("[name='eachCase[]']:checked").length; // menghitung checkbox yang dicentang 
				if(count_checked == 0) {
					alert("Silahkan pilih data yang ingin dihapus");
					return false;
				}else{
					confirm("Apakah anda yakin akan menghapus data-data yang anda pilih");
				} 
			});
		});
	</script>
    </head>
    
    <body>
	<div class="container">
			<div class="hero-unit">
		<div id="content" class="col-lg-10 col-sm-12">
<ul class="breadcrumb">
        <li>
            <a href="#">Pembagian Kelas</a> /  <a href="#">Pilih Siswa</a>
        </li>
    </ul>

        <form id="add" method="post">
		
		
                <div class="box-content">
				<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
                <thead>
			<tr>
					<th><input type="checkbox" id="selectall"/></th>
					<th>Nomor Pendaftaran</th>
					<th>Nama</th>
					<th>Ujian Nasional</th>
					<th>Ujian Kelas</th>
					<th>Kelas</th>
				</tr>
				</thead>
				</tbody>
                <?php
				$i=1;
					$sql = mysql_query("
					SELECT biodata.*, tabel_nilai.*, kelas_siswa.*, kelas.*
					
					FROM tabel_nilai
					
					INNER JOIN biodata
					ON tabel_nilai.id_ujian = biodata.id_utama

					LEFT JOIN kelas_siswa
					ON tabel_nilai.id_ujian = kelas_siswa.id_siswa

					LEFT JOIN kelas
					ON kelas_siswa.id_kelas= kelas.id_kelas
					
					ORDER BY kelas.id_kelas DESC

					");
					while ($tampil = mysql_fetch_array($sql)) {
					$id_ujian = $tampil['id_ujian'];
					$point = $tampil['point'];
					$nama = $tampil['nama'];
					$jumlah = $tampil['jumlah'];
					$nama_kelas = $tampil['nama_kelas'];
				?>
					<tr>
						<td><input type='checkbox' class='eachCase' name='id_ujian[<?php echo $i; ?>]' value="<?php echo $id_ujian; ?>"/></td>	
                        <td><?php echo $id_ujian; ?></td>
						<td><?php echo $nama; ?></td>
						<td><?php echo $jumlah; ?></td>
						<td><?php echo $point; ?></td>
						<td><?php echo $nama_kelas; ?></td>
					</tr>
					</tbody>
				<?php
				$i++;
					}
				?>
            </table>
			<input type="submit" name="submit" value="Tambah">
        </form>
		<?php
		if(isset($_POST['submit'])){
			$id_ujian = implode(',',$_POST['id_ujian']);
		?>
			<script>
			window.location='admin.php?page=ujian_pembagian&id_ujian=<?php echo $id_ujian; ?>';
			</script>
		<?php
		}
		?>
		</div>
	</body>
</html>
