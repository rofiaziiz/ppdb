<?php 
      include "../config/func.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
		<ul class="breadcrumb">
            <h4>Laporan Siswa Diterima SD</h4>
		</ul>

 <div class="box-content">
<a href="pdf/dterima.php"  target="_blank">Ekspor Ke PDF</a>
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
		<th>No.</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>Asal Sekolah</th>
		<th>Jumlah Nilai</th>
		<th>Opsi</th>
    </tr>
    </thead>
	<tbody>
	<?php
					$tahun = date('Y');
					$get_limit_sd = _get_limit_sd();
					$unggulan=mysql_num_rows(mysql_query("SELECT * FROM biodata_sd
							where verifikasi = 'Sudah' AND date_format(biodata_sd.tgl_daftar,'%Y') = '$tahun' AND
							biodata_sd.prestasi = 'u1' OR biodata_sd.prestasi = 'u2' OR biodata_sd.prestasi = 'u3' OR biodata_sd.prestasi = 'u4'"));
					
					$sql = mysql_query("SELECT biodata_sd.*, SUM(biodata_sd.prestasi+biodata_sd.jumlah) AS total
							FROM biodata_sd


							where verifikasi = 'Sudah' AND date_format(biodata_sd.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$unggulan.",".$get_limit_sd." ");
						
						$no=$unggulan;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>
						<a href="?page=detail&amp;id='.$tampil['id_utama'].'" class="btn btn-xs btn-default" ><i class="glyphicon glyphicon-zoom-in"></i></a>
						</td>';
								echo '</tr>';
							}
						?>
					</tbody>
					<tbody>
				<?php
					$tahun = date('Y');
					$get_limit = _get_limit_mhs();
					$sql = mysql_query("SELECT * FROM biodata
							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' AND
							biodata.prestasi = 'u1' OR biodata.prestasi = 'u2' OR biodata.prestasi = 'u3' OR biodata.prestasi = 'u4' ");
						
						$no=0;
							while ($tampil = mysql_fetch_array($sql)) {
								$no++;
								echo '<tr>';
										echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
										echo '<td>'.  $tampil['nisn'].'</td>';
										echo '<td>'.$tampil['nama'].'</td>';
										echo '<td>'.$tampil['sekolah'].'</td>';
										echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
										echo '<td>
						<a href="?page=detail&amp;id='.$tampil['id_utama'].'" class="btn btn-xs btn-default" ><i class="glyphicon glyphicon-zoom-in"></i></a>
						</td>';
								echo '</tr>';
							}
						?>
				</tbody>
    </table>
    </div>
    </div>
    </div>
    </div><!--/row-->
	
	

			
                    
            </div>
        </div>
    </div>
	
</body>