
<?php
if(isset($_GET['id'])){
$id = $_GET['id'];

		$del = mysql_query("DELETE FROM biodata WHERE id_utama='$id'");

	echo '<script>window.history.back()</script>';
}
?>
