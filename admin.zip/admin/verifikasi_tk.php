<head>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">	
		<h4>Verifikasi Berkas</h4>
    </ul>

  <div class="box-content">
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
        <th>No.</th>
		<th>No. Daftar</th>
		<th>Nama</th>
		<th>Status</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
    <?php
		$thn = date('Y');
		$sql = mysql_query("
		SELECT * FROM biodata_tk 
		WHERE date_format(tgl_daftar,'%Y') = '$thn' order by id_utama DESC");
		$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
			$no++;
			if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.  $tampil['id_utama'].'</td>';
						echo '<td>'.$tampil['nama'].'</td>';
						echo '<td>'.$tampil['verifikasi'].'</td>';
						if ($tampil['verifikasi'] == 'Belum'){
						echo '<td><a href="?page=verifikasi_edit_tk&amp;id='.$tampil['id_utama'].'&amp;ch=Sudah" class="btn btn-xs btn-success">Verifikasi</a></td>';
						} else {
						echo '<td><a href="?page=verifikasi_edit_tk&amp;id='.$tampil['id_utama'].'&amp;ch=Belum" class="btn btn-xs btn-danger">Batalkan Verifikasi</a></td>';
							
						}
				echo '</tr>';
			}
		?>
    </tbody>
    </table>
    </div>
    </div>
    </div>
    </div>
            </div>
        </div>
    </div>
	
</body>