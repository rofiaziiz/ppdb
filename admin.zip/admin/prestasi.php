<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Nilai Prestasi SMP</h4>
    </ul>
    <div class="box-content">

    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
        <th>No.</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>Jumlah Raport(60%)</th>
		<th>Nilai Test(40%)</th>
		<th>Nilai Akhir(R+T)</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
    <?php
			$blnth = date('Y');
			$sql = mysql_query("SELECT biodata.*, prestasi.*
			FROM biodata
			
			LEFT JOIN prestasi
			ON prestasi.nilai = biodata.prestasi
			
			WHERE Verifikasi = 'Sudah' AND date_format(tgl_daftar,'%Y') = '$blnth'

");
			$no=0;
			
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.  $tampil['nisn'].'</td>';
						echo '<td>'.$tampil['nama'].'</td>';
						echo '<td>'.($tampil['jumlah']/4*60/100).'</td>';
						echo '<td>'.$tampil['prestasi'].'</td>';
						echo '<td>'.($tampil['jumlah']/4*60/100+$tampil['prestasi']).'</td>';
						
						echo '<td><a href="?page=prestasi_edit&amp;id='.$tampil['id_utama'].' " class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i></a></td>';
				echo '</tr>';
			}
		?>
    </tbody>
    </table>
    </div>
    </div>
    </div>
    </div>
            </div>
        </div>
    </div>
	
</body>