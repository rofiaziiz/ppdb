<div id="main"> <a name="TemplateInfo"></a>
<!DOCTYPE html>
<html>
	<head>
	<title>Edit Konfig</title>
	</head>

	<body>
	<?php
$id	=   $_GET['id']; 
	//cek dahulu, jika tombol simpan di klik
	if(isset($_POST['btnSimpan'])){
		
		$nilai			=	$_POST['nilai'];
		$nilai_b		=	$_POST['nilai_b'];
		$nilai_c		=	$_POST['nilai_c'];
		$nilai_d		=	$_POST['nilai_d'];
		

			
		// SQL Simpan data ke tabel database
			$mySql	= mysql_query("UPDATE konfigurasi SET 
							nilai='$nilai',nilai_b='$nilai_b',nilai_c='$nilai_c',nilai_d='$nilai_d' WHERE id='$id'");
		
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=konfig_halaman'>";

			exit;
		}	
	
			
$q_isi	=	mysql_fetch_array(mysql_query("SELECT * FROM konfigurasi WHERE id = '$id'"));
		
	?>
<div id="content" class="col-lg-12 col-sm-12">

		<form action="" method="post" name="post" enctype="multipart/form-data" target="_self">
			<table class="table-list" width="100%" border="0" cellpadding="3" cellspacing="1">


						<input name="id_berita" type="hidden" value="<?php echo $dataId; ?>"></td>

				<tr>
					<td>Menu</td>
					<td>&nbsp;</td>
					<td><input name="nilai" type="text" class="form-control" id="inputSuccess1" value="<?php echo $q_isi['nilai']; ?>" size="50" maxlength="100"></td>
				</tr>
				<tr>
					<td>Isi</td>
					<td></td>
					<td><textarea  class="ckeditor" class="form-control" id="inputSuccess1" name='nilai_b' style='width: 600px; height: 350px;'><?php echo $q_isi['nilai_b']; ?></textarea></td>
				</tr>
				<tr>
					<td>Urutan</td>
					<td>&nbsp;</td>
					<td><input name="nilai_c" type="text" class="form-control" id="inputSuccess1" value="<?php echo $q_isi['nilai_c']; ?>" size="50" maxlength="100"></td>
				</tr>
				<tr>
					<td>Tampilkan Pada</td>
					<td>&nbsp;</td>
					<td>
					<select name="nilai_d" class="form-control">
						<option value="1" <?php if ($q_isi['nilai_d'] == 1) { echo 'selected';}?>>Sebelum Login</option>
						<option value="2" <?php if ($q_isi['nilai_d'] == 2) { echo 'selected';}?>>Sesudah Login</option>
						<option value="3" <?php if ($q_isi['nilai_d'] == 3) { echo 'selected';}?>>Keduanya</option>
					</select>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><input name="btnSimpan" type="submit" class="btn btn-xs btn-success"value=" Simpan "></td>
				</tr>	
			</table>
		</form>