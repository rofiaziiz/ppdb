<?php
	include "../config/koneksi.php";

?>

<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
		<body>
	<div class="container">
			<div class="hero-unit">
		<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Input Kelas Siswa</h4>
    </ul>

		<form method="post" action="?page=ujian_pembagian_simpan">
            <table class="table-list" width="70%">
                



				<tr>
                    <td>Kode Siswa</td>
            
                    <td><input type="text" name="nomor_siswa" size="50"  class="form-control" id="inputSuccess1" value="<?php if(isset($_GET['id_ujian'])) echo $_GET['id_ujian']; ?>">

                    <a href="admin.php?page=ujian_dft_siswa"><strong>Pilih Siswa</a> 
                        
                </tr>
				                <tr>
                    <td>Kelas</td>
                    <td>
<select name="id_kelas" id="id_kelas">
<option> Pilih Kelas </option>
<?php
//mengambil nama-nama propinsi yang ada di database
$kelas = mysql_query("SELECT * FROM kelas");
while($k=mysql_fetch_array($kelas)){
echo "<option value=\"$k[id_kelas]\">$k[nama_kelas]</option>\n";
}
?>
</select>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Simpan" name="kirim" /></td>
                </tr>
            </table>
        </form>   
             
	</body>
</html>
</div>
