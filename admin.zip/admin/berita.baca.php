
<html>

	<title>Edit Berita</title>


	<body>
	<?php
	include "../config/koneksi.php";

	//cek dahulu, jika tombol simpan di klik
	if(isset($_POST['btnSimpan'])){
		
		$id_berita		=	$_POST['id_berita'];
		$judul			=	ucwords($_POST['judul']);
		$isi			=	$_POST['isi'];
		
		# Validasi form, jika kosong sampaikan pesan error
		$pesanError = array();
		if(trim($judul)=="") {
			$pesanError[] = "Data <b>Judul</b> tidak boleh kosong, harus diisi !";		
		}
		# VALIDASI ID_UDER DI DATABASE, jika sudah ada akan ditolak
		$id_berita	= $_POST['id_berita'];
		$sqlCek="SELECT * FROM tbl_berita WHERE judul='$judul' AND NOT(id_berita='$id_berita')";
		$qryCek=mysql_query($sqlCek) or die ("Eror Query".mysql_error()); 
		if(mysql_num_rows($qryCek)>=1){
			$pesanError[] = "Maaf, Judul <b> $judul </b> sudah ada, ganti dengan yang lain";
		}
		
		# JIKA ADA PESAN ERROR DARI VALIDASI
		if (count($pesanError)>=1 ){
			echo "<div class='mssgBox'>";
			echo "<img src='images/attention.png'> <br><hr>";
				$noPesan=0;
				foreach ($pesanError as $indeks=>$pesan_tampil) { 
				$noPesan++;
					echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
				} 
			echo "</div> <br>"; 
		}else {
			# SIMPAN DATA KE DATABASE. Jika tidak menemukan pesan error, simpan data ke database	
					
			// Membaca Kode dari form hidden
			$id_berita	= $_POST['id_berita'];
			
		// SQL Simpan data ke tabel database
			$mySql	= mysql_query("UPDATE tbl_berita SET 
							judul='$judul',isi='$isi' WHERE id_berita='$id_berita'");
			if($mySql){
				?>
				<?
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=berita.view'>";
				?>
				<?php
			}
			exit;
		}	
	} // Penutup POST
			
	// Skrip membaca variable dari URL (Kode dikirim dari menu Edit)
	$id_berita	= isset($_GET['id_berita']) ?  $_GET['id_berita'] : $_POST['id_berita']; 

	# TAMPILKAN DATA LOGIN UNTUK DIEDIT
	$mySql 	= "SELECT * FROM tbl_berita WHERE id_berita='$id_berita'";
	$myQry 	= mysql_query($mySql)  or die ("Query ambil data salah : ".mysql_error());
	$myData = mysql_fetch_array($myQry); 

		# MEMBUAT NILAI DATA PADA FORM
		// Masukkan data ke dalam variabel, supaya bisa dipanggil di Form
		$dataId			= $myData['id_berita'];
		$dataJudul		= isset($_POST['judul']) ? $_POST['judul'] : $myData['judul'];
		$isi			= isset($_POST['isi']) ? $_POST['isi'] : $myData['isi'];
		
	?>

		<form action="" method="post" name="post" enctype="multipart/form-data" target="_self">
			<table class="table-list" width="100%" border="0" cellpadding="3" cellspacing="1">


						<input name="id_berita" type="hidden" value="<?php echo $dataId; ?>"></td>

				<tr>
					<td>Judul Berita</td>
					<td>&nbsp;</td>
					<td><input name="judul" type="text" class="form-control" id="inputSuccess1" value="<?php echo $dataJudul; ?>" size="50" maxlength="100"></td>
				</tr>
				<tr>
					<td>Isi Berita</td>
					<td></td>
					<td><textarea  class="ckeditor" class="form-control" id="inputSuccess1" name='isi' style='width: 600px; height: 350px;'><?php echo $isi; ?></textarea></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><input name="btnSimpan" type="submit" class="btn btn-xs btn-success"value=" Simpan "></td>
				</tr>	
			</table>
		</form>
	</body>
</html>
</div>