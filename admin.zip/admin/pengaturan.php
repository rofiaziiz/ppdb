<link href="jquery-ui/jquery-ui.css" rel="stylesheet">
<script src="jquery-ui/external/jquery/jquery.js"></script>
<script src="jquery-ui/jquery-ui.js"></script>	
<script>
	$(document).ready(function(){
	$("#tabs").tabs();
});
</script>
<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Halaman Statis</h4>
    </ul>
<div id="tabs">
	<ul>

		<li><a href="#tabs-6">Halaman Utama</a></li>
		<li><a href="#tabs-2">Sambutan</a></li>

	</ul>
	<div id="tabs-6">
		<?php
			$sql = mysql_query("SELECT * FROM seting limit 0,1");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';

						echo '<td>'.$tampil['nilai'].'</td>';
						echo '<td><a href="?page=statis.edit&amp;id='.$tampil['id'].'" class="btn btn-xs btn-success"> Edit</a> 
</td>';
						
							  	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
			}
		?>
	</div>
	
	
	
	
	<div id="tabs-2">		<?php
			$sql = mysql_query("SELECT * FROM seting limit 1,1");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';

						echo '<td>'.$tampil['nilai'].'</td>';
						echo '<td><a href="?page=statis.edit&amp;id='.$tampil['id'].'" class="btn btn-xs btn-success"> Edit</a></td>';
						
							  	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
			}
		?>
	</div>


		
	
		
</div>


	
	</body>
</html>