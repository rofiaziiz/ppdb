<div id="main"> <a name="TemplateInfo"></a>
<?php
include "../config/koneksi.php";

# TOMBOL SIMPAN DIKLIK
if(isset($_POST['Simpan'])){
	# Baca Variabel Form
	$nama		=$_POST['nama'];
	$nilai			=$_POST['nilai'];
	
	# Validasi form, jika kosong sampaikan pesan error
	$pesanError = array();
	if(trim($nama)=="") {
		$pesanError[] = "Data <b>Nama</b> tidak boleh kosong, harus diisi !";		
	}
	if(trim($nilai)=="") {
		$pesanError[] = "Nilai tidak boleh kosong, harus diisi !";		
	}


	# JIKA ADA PESAN ERROR DARI VALIDASI
	if (count($pesanError)>=1 ){
		echo "<div class='mssgBox'>";
		echo "<img src='../images/attention.png'> <br><hr>";
			$noPesan=0;
			foreach ($pesanError as $indeks=>$pesan_tampil) { 
			$noPesan++;
				echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
			} 
		echo "</div> <br>"; 
	}
	else {
		# SIMPAN DATA KE DATABASE. Jika tidak menemukan pesan error, simpan data ke database
		// Simpan data dari form ke Database
		$mySql	= "INSERT INTO konfigurasi ( 
									nama,nilai )
							VALUES ( 
									'$nama','$nilai')";		
		$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
		if($myQry){
			?>
				<p>
				  <p>Data Berhasil disimpan...</p>
				</p>
			<?php
		}
		exit;
	}	
} // Penutup POST

# MEMBUAT NILAI DATA PADA FORM
$nama		= isset($_POST['nama']) ? $_POST['nama'] : '';
$nilai	= isset($_POST['nilai']) ? $_POST['nilai'] : '';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form>
  <table width="80%">
		<tr>
			<td colspan="2" bgcolor="#FF9900" style="color:#FFFFFF"><b>AKUN</b></td>
		</tr>
			<tr>
				<td><b>Email</b></td>
				<td>:<input type="text" name="email" value="<?php echo $email; ?>" size="40"/></td>
			</tr>
			<tr>
				<td>Nama Lengkap</td>
				<td>:<input type="text" name="nama_depan" value="<?php echo $nama_depan; ?>" size="60"/></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" value="Simpan" name="Simpan" /></td>
			</tr>
			</table>
</form>
</body>
</html>
</div>