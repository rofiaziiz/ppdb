<?php
	
	$id = $_GET['id'];

		$del = mysql_query("DELETE FROM konfigurasi WHERE id='$id'");
		
			echo '<script>window.history.back()</script>';

?>
