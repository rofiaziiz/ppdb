<div id="main"> <a name="TemplateInfo"></a>
	<?php
        if (isset($_POST['kirim']))
		{
                $nomor_siswa = explode(',',$_POST['nomor_siswa']);
				$id_kelas = $_POST['id_kelas'];
				foreach($nomor_siswa as $k=>$v){
					$query = "INSERT INTO kelas_siswa (id_siswa, id_kelas) VALUES ('$v', '$id_kelas')";
					$hasil = mysql_query($query);
				}
        }
   	?>
	<script>
		window.location='admin.php?page=ujian_pembagian';
	</script>
</div>