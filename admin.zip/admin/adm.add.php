<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<body>
		<ul class="breadcrumb">
        <li>
            <a href="admin.php?page=adm.view">Pengaturan Admin</a> / <a href="admin.php?page=adm.add">Tambah Admin</a>
        </li>
    </ul>
	<div>
<a href="#" class="btn btn-info btn-setting">Click for dialog</a>
	</div>
		<div class="col-lg-6">
                        <h2>Tambah Admin</h2>
		<form action="?page=adm.proses" method="post" name="postform">
			<table class="table-list" width="100%">
				<tr>
					<td>Nama Admin</td>
					<td><input type="text" name="nama"  size="50"/></td>
				</tr>
				<tr>
					<td>Id Admin</td>
					<td><input type="text" name="id_admin"  size="50"/></td>
				</tr>
                <tr>
					<td>Password</td>
					<td><input type="password" name="password"  size="50"/></td>
				</tr>
                <tr>
					<td>No. Telp</td>
					<td><input type="text" name="telp"  size="50"/></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input type="submit" value="simpan" name="simpan" /></td>
				</tr>
			</table>
		</form>
		
	</body>
</html>
</div>