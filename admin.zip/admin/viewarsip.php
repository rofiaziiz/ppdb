<div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">
            <h4>Arsip</h4>
    </ul>
<?php
$blnth = $_GET['blnth'];
include "../config/koneksi.php";
?>
    <div class="box-content">
	
	<table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
	<thead>
    <tr>
        <th>No.</th>
		<th>No. Daftar</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>Sekolah</th>
		<th>Tanggal Daftar</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
			<?php
					$query = "SELECT * FROM biodata WHERE date_format(tgl_daftar, ' %Y') = '$blnth'
					order by nama asc";
					$no=0;
					$hasil = mysql_query($query);

					while ($data = mysql_fetch_array($hasil)){
					$no++;
					{ 	
					echo '<tr>';
					echo '<td>'.$no.'</td>';
					echo "<td>".$data['id_utama']."</td>";
					echo "<td>".$data['nisn']."</td>";
					echo "<td>".$data['nama']."</td>";
					echo "<td>".$data['sekolah']."</td>";
					echo "<td> ".$data['tgl_daftar']."</td>";
					echo "<td><a href=?page=detail&amp;id=$data[id_utama] class='btn btn-xs btn-default' ><i class='glyphicon glyphicon-zoom-in'></i> Detail</a></td>";}
					}
			?>