<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php 
      include "../config/batasnilai.php";
?>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">
            <h4>Laporan Hasil Ujian</h4>
    </ul>
    <div class="box-content">
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
        <th>No.</th>
		<th>No. Daftar</th>
		<th>Nama</th>
		<th>Tanggal Ujian</th>
		<th>Jumlah Nilai UN</th>
		<th>Nilai Tes</th>
		<th>Opsi</th>
    </tr>
    </thead>
    <tbody>
		<?php
		$get_nilai = _get_limit_nilai();
			$thn = date('Y');
			$sql = mysql_query("SELECT tabel_nilai.*, biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total 
			from biodata 

			INNER JOIN tabel_nilai
			ON tabel_nilai.id_ujian = biodata.id_utama
			
			WHERE date_format(tgl_daftar,'%Y') = '$thn' AND (biodata.prestasi+biodata.jumlah) > ".$get_nilai." OR prestasi = 'u1'  OR prestasi = 'u2' OR prestasi = 'u3' OR prestasi = 'u4'   
			GROUP BY id_utama	");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.  $tampil['id_ujian'].'</td>';
						echo '<td>'.$tampil['nama'].'</td>';
						echo '<td>'.$tampil['tanggal'].'</td>';
						echo '<td>'.$tampil['jumlah'].'</td>';
						echo '<td>'.$tampil['point'].'</td>';
						echo '<td>
						<a href="?page=ujian_hsl.hapus&amp;id='.$tampil['id_ujian'].'" onclick="return confirm(\'Yakin untuk menghapus data ini?\')" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-trash"></i></a></td>';
				echo '</tr>';
			}
		?>
    </tbody>
    </table>
    </div>
    </div>
</body>