<div id="main"> <a name="TemplateInfo"></a>
<?php
include "../config/koneksi.php";

//cek dahulu, jika tombol simpan di klik
if(isset($_POST['btnSimpan'])){
	
	$id			=	$_POST['id'];
	$nama			=	$_POST['nama'];
	$nilai			=	$_POST['nilai'];

	
	
	
	
	# Validasi form, jika kosong sampaikan pesan error
	$pesanError = array();
	if(trim($nama)=="") {
		$pesanError[] = "Data <b>Nama konfig</b> tidak boleh kosong, harus angka !";		
	}

		
	
	# JIKA ADA PESAN ERROR DARI VALIDASI
	if (count($pesanError)>=1 ){
		echo "<div class='mssgBox'>";
		echo "<img src='images/attention.png'> <br><hr>";
			$noPesan=0;
			foreach ($pesanError as $indeks=>$pesan_tampil) { 
			$noPesan++;
				echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
			} 
		echo "</div> <br>"; 
	}
	else {
		# SIMPAN DATA KE DATABASE. Jika tidak menemukan pesan error, simpan data ke database	
				
		// Membaca Kode dari form hidden
		$id	= $_POST['id'];
		
			if(trim($nilai)=="") {
		$pesanError[] = "Nilai tidak boleh kosong, harus angka !";		
	}
	

	// SQL Simpan data ke tabel database
		$mySql	= mysql_query("UPDATE seting SET 
						nama='$nama',nilai='$nilai'
				  WHERE id='$id'");
		if($mySql){
				echo "<meta http-equiv='refresh' content='0; url=admin.php?page=pengaturan'>";

		}
		exit;
	}	
} // Penutup POST
		
// Skrip membaca variable dari URL (Kode dikirim dari menu Edit)
$id	= isset($_GET['id']) ?  $_GET['id'] : $_POST['id']; 

# TAMPILKAN DATA LOGIN UNTUK DIEDIT
$mySql 	= "SELECT * FROM seting WHERE id='$id'";
$myQry 	= mysql_query($mySql)  or die ("Query ambil data salah : ".mysql_error());
$myData = mysql_fetch_array($myQry); 

	# MEMBUAT NILAI DATA PADA FORM
	// Masukkan data ke dalam variabel, supaya bisa dipanggil di Form
	$dataId			= $myData['id'];
	$nama			= isset($_POST['nama']) ? $_POST['nama'] : $myData['nama'];
	$nl			= isset($_POST['nilai']) ? $_POST['nilai'] : $myData['nilai'];

	
?>
		<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Ubah Halaman Statis</h4>
    </ul>
<form method="post" enctype="multipart/form-data" target="_self">
  <table>

  
      <input name="id" type="hidden" value="<?php echo $dataId; ?>">
    <tr>
      <td>Nama</td>
      <td><input name="nama" type="text" value="<?php echo $nama; ?>" class="form-control" id="inputSuccess1"size="80" maxlength="100"></td>
    </tr>

	 <tr>
      <td>Isi</td>
      <td><textarea class="ckeditor" name="nilai"  class="form-control" id="inputSuccess1"><?php echo $nl;?></textarea>
	  </tr>

    <tr>
      <td>&nbsp;</td>
      <td><input name="btnSimpan" type="submit" value=" Simpan "  class="btn btn-xs btn-success"></td>
    </tr>
  </table>
</form>
</div>