<div id="main"> <a name="TemplateInfo"></a>
	<link rel="stylesheet" href="datepicker/themes/base/jquery.ui.all.css">
	<script src="datepicker/js/jquery-1.7.2.js"></script>
	<script src="datepicker/ui/jquery.ui.core.js"></script>
	<script src="datepicker/ui/jquery.ui.widget.js"></script>
	<script src="datepicker/ui/jquery.ui.datepicker.js"></script>
	<script>
	$(function() {
		$( "#datepicker" ).datepicker({
		dateFormat:"yy/mm/dd",
			changeMonth: true,
			changeYear: true
		});
	});
	</script>
<?php
include "../config/koneksi.php";

if(isset($_POST['btnSimpan'])){
	$nama			=	$_POST['nama'];
	$nilai			=	$_POST['nilai'];

	$pesanError = array();
	if(trim($nama)=="") {
		$pesanError[] = "Data <b>Nama konfig</b> tidak boleh kosong, harus angka !";		
	}
	if(trim($nilai)=="") {
		$pesanError[] = "Nilai tidak boleh kosong, harus angka !";		
	}
	
	if (count($pesanError)>=1 ){
		echo "<div class='mssgBox'>";
		echo "<img src='images/attention.png'> <br><hr>";
			$noPesan=0;
			foreach ($pesanError as $indeks=>$pesan_tampil) { 
			$noPesan++;
				echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
			} 
		echo "</div> <br>"; 
	}
	else {

		$mySql	= mysql_query("UPDATE konfigurasi SET 
						nama='$nama',nilai='$nilai'
				  WHERE id='3'");
		if($mySql){
			?>
			<?
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=ujian_soal'>"; ?>
			<?php
		}
		exit;
	}	
} // Penutup POST
		
// Skrip membaca variable 
$id	= isset($_GET['id']) ?  $_GET['id'] : $_POST['id']; 

# TAMPILKAN DATA LOGIN UNTUK DIEDIT
$mySql 	= "SELECT * FROM konfigurasi WHERE id='3'";
$myQry 	= mysql_query($mySql)  or die ("Query ambil data salah : ".mysql_error());
$myData = mysql_fetch_array($myQry); 

	# MEMBUAT NILAI DATA PADA FORM
	// Masukkan data ke dalam variabel, supaya bisa dipanggil di Form
	$dataId			= $myData['id'];
	$nama			= isset($_POST['nama']) ? $_POST['nama'] : $myData['nama'];
	$nilai		= isset($_POST['nilai']) ? $_POST['nilai'] : $myData['nilai'];
	
?>
	<div id="content" class="col-lg-12 col-sm-12">
		<ul class="breadcrumb">
            <h4>Pelaksanaan Ujian</h4>
		</ul>
			<form method="post" enctype="multipart/form-data" target="_self">
				<table>
					<input hidden name="nama" type="text" value="<?php echo $nama; ?>" size="80" maxlength="100">
					<div class="form-group has-success col-md-3">
					<label class="control-label" for="inputSuccess1">Tanggal Ujian</label>
					<input name="nilai" type="text" value="<?php echo $nilai; ?>" size="80" id="datepicker" class="form-control" id="inputSuccess1" >
					<input name="btnSimpan" type="submit" class="btn btn-xs btn-success" value=" Simpan ">
	</div>
  </table>
</form>
</div>