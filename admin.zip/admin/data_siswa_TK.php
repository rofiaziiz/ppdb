<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>


	</head>
	<body>
	<div class="container">
			<div class="hero-unit">
		<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Tambah Kelas</h4>
    </ul>

		<form action="?page=kelas_proses" method="post" name="postform">
			<table class="table-list" width="30%" >
				<tr>
					<td>Kode Kelas</td>
					<td><input type="text" name="id_kelas"  class="form-control" id="inputSuccess1" size="20"/></td>
				</tr>
				<tr>
					<td>Nama Kelas</td>
					<td><input type="text" name="nama_kelas"  class="form-control" id="inputSuccess1" size="50"/></td>
				</tr>
				<tr>
					<td>Daya Tampung</td>
					<td><input type="text" name="daya_tampung"  class="form-control" id="inputSuccess1" size="50"/></td>
				</tr>

				<tr>
					<td>&nbsp;</td>
					<td><input type="submit" value="Kirim" class="btn btn-xs btn-success"name="kirim" /></td>
				</tr>
			</table>
		</form>
			
		</div>
		</div>
	</body>
</html>
</div>