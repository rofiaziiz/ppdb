
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Kelas Siswa</h4>
    </ul>

 

    <div class="box-content">
<a href="pdf/index.php"  target="_blank">Ekspor Ke PDF</a>
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
        <th>No.</th>
		<th>No. Daftar</th>
		<th>Nama</th>
		<th>Asal Sekolah</th>
		<th>Kelas</th>
		<th>Aksi 		</th>
    </tr>
    </thead>
    <tbody>
    <?php
			$sql = mysql_query("SELECT tabel_nilai.*, biodata.*, kelas_siswa.*, kelas.* 
			
			from tabel_nilai 
			INNER JOIN biodata
ON tabel_nilai.id_ujian = biodata.id_utama



INNER JOIN kelas_siswa
ON tabel_nilai.id_ujian = kelas_siswa.id_siswa

INNER JOIN kelas
ON kelas.id_kelas = kelas_siswa.id_kelas

order by nama_kelas asc
			");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.  $tampil['id_ujian'].'</td>';
						echo '<td>'.$tampil['nama'].'</td>';
						echo '<td>'.$tampil['sekolah'].'</td>';
						echo '<td>'.$tampil['nama_kelas'].'</td>';
						echo '<td>
							<a href="?page=kelas_siswa_hapus&amp;id='.$tampil['id_ujian'].'" onclick="return confirm(\'Yakin?\')" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-trash"></i></a></td>';
						 	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id


				echo '</tr>';
			}
		?>
    </tbody>
    </table>
	
    </div>
    </div>
    </div>
    </div>
            </div>
        </div>
    </div>
	
</body>