<?php
include"../../config/koneksi.php";
require('html2fpdf.php');
ob_start();

?>
<html>
<head>
<title>Laporan Arsip</title>

</head>
<body>
<?php
$blnth = $_GET['blnth'];

?>
<h2 center>Laporan Arsip</h2>
<table width="100%" cellspacing="6" cellpadding="5" align="center" border="1">
    <thead>
    <tr>
        <th>No.</th>
		<th>No. Daftar</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>Sekolah</th>
		<th>Tanggal Daftar</th>
    </tr>
    </thead>
			 <tbody>
			<?php
					$query = "SELECT * FROM biodata WHERE date_format(tgl_daftar, ' %Y') = '$blnth'
					order by nama asc";
					$no=0;
					$hasil = mysql_query($query);

					while ($data = mysql_fetch_array($hasil)){
					$no++;
					{ 	
					echo '<tr>';
					echo '<td>'.$no.'</td>';
					echo "<td>".$data['id_utama']."</td>";
					echo "<td>".$data['nisn']."</td>";
					echo "<td>".$data['nama']."</td>";
					echo "<td>".$data['sekolah']."</td>";
					echo "<td> ".$data['tgl_daftar']."</td>";
					}
					}
			?>
						</tbody>

    </table>


</body>
</html>
<?php
// Output-Buffer in variable:
$html=ob_get_contents();
ob_end_clean();
$pdf=new HTML2FPDF();
$pdf->AddPage();
$pdf->WriteHTML($html);
if (preg_match("/MSIE/i", $_SERVER["HTTP_USER_AGENT"])){
    header("Content-type: application/PDF");
} else {
    header("Content-type: application/PDF");
    header("Content-Type: application/pdf");
}
$pdf->Output("sample2.pdf","I");

?>