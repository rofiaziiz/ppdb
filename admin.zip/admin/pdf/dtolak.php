<?php
include"../../config/koneksi.php";
include "../../config/func.php";
require('html2fpdf.php');
ob_start();

?>
<html>
<head>
<title>Laporan Siswa Ditolak</title>

</head>
<body>
<h2 center>Laporan Siswa Ditolak</h2>
<table width="100%" cellspacing="6" cellpadding="5" align="center" border="1">
    <thead>
    <tr>
<th>No.</th>
						
						<th>NISN</th>
						<th>Nama</th>
						<th>Asal Sekolah</th>
						<th>Jumlah Nilai</th>

    </tr>
    </thead>
			<tbody>
					<?php
						$get_limit = _get_limit_mhs();
						$tahun = date('Y');
							$sql = mysql_query("SELECT biodata.*, SUM(biodata.id_prestasi+biodata.jumlah) AS total
							FROM biodata


							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY id_prestasi = 'u1' DESC,id_prestasi = 'u2' DESC,id_prestasi = 'u3' DESC,id_prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$get_limit.",100000 ");
		
									$no=0;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td width=40px>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['id_prestasi']).'</td>';
												echo '</tr>';
										}
									?>
						</tbody>

    </table>


</body>
</html>
<?php
// Output-Buffer in variable:
$html=ob_get_contents();
ob_end_clean();
$pdf=new HTML2FPDF();
$pdf->AddPage();
$pdf->WriteHTML($html);
if (preg_match("/MSIE/i", $_SERVER["HTTP_USER_AGENT"])){
    header("Content-type: application/PDF");
} else {
    header("Content-type: application/PDF");
    header("Content-Type: application/pdf");
}
$pdf->Output("sample2.pdf","I");

?>