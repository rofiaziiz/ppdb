
<?php
include "fungsi_indotgl.php";
include "../config/koneksi.php";
//cek dahulu, jika tombol simpan di klik

if($_GET) {
	$id	= $_GET['id'];
	$mySql	= "SELECT  * FROM biodata

WHERE id_utama='$id'";
	$myQry	= mysql_query($mySql) or die ("Gagal query".mysql_error());
	$myData	= mysql_fetch_array($myQry);
	}
?>
<?php

	if(isset($_GET['id'])){
		$id_user=$_GET['id'];
	}
	
	if(empty($_GET['id'])){
		$id_user=$_SESSION['id'];
	}
$query=mysql_fetch_array(mysql_query("select * from biodata where id_utama='$id'"));



$photo=$query['photo'];


$tanggal = tgl_indo($myData['tgl_lahir']);
$rupiah =number_format($myData['penghasilan'],0,",",".");
?>




   <div id="content" class="col-lg-12 col-sm-12">
<div class="row">
    <div class="box col-md-6">
    <div class="box-inner">
    <div class="box-header well" data-original-title="">
        <h2><i class="glyphicon glyphicon-user"></i> Profil </h2>


    </div>
    <div class="box-content">
    <div class="alert alert-info"><h3><?php echo $myData['nama']; ?></h3>
	<p>Nomor Pendaftaran : <?php echo $myData['id_utama']; ?></p></div>
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
  <table>


	<tr>
		<td><strong />NISN</td>
		<td><strong />:</td>
		<td><strong /><?php echo $myData['nisn']; ?></td>
	</tr>

    <tr>
      <td>Tempat, Tgl Lahir</td>
	  <td>:</td>
      <td><?php echo $myData['tempat_lahir']; ?>, <? echo $tanggal ?>
	  </td>
    </tr>
    <tr>
      <td>Alamat Lengkap</td>
	  <td>:</td>
      <td><?php echo $myData['desa']; ?>, <?php echo $myData['kecamatan']; ?>, <?php echo $myData['kabupaten']; ?>, <?php echo $myData['provinsi']; ?></td>
    </tr>
    <tr>
      <td>Jenis Kelamin</td>
	  <td>:</td>
      <td><?php echo $myData['jenis_kel']; ?>

      </td>
    </tr>
    <tr>
      <td>Agama</td>
	  <td>:</td>
      <td><?php echo $myData['agama']; ?>
	  </td>
    </tr>
    <tr>
      <td>Password</td>
	  <td>:</td>
      <td><?php echo $myData['tampil_password']; ?></td>
    </tr>
    <tr>
      <td>No. Telepon</td>
	  <td>:</td>
      <td><?php echo $myData['telepon']; ?>
    </tr>

    <tr>
      <td>Nama Ayah</td>
	  <td>:</td>
      <td><?php echo $myData['ayah']; ?></td>
    </tr>
    <tr>
      <td>Pekerjaan Ayah</td>
  <td>:</td>    <td><?php echo $myData['kerja_ayah']; ?></td>
    </tr>
    <tr>
      <td>Nama Ibu</td>
	  <td>:</td>
      <td><?php echo $myData['ibu']; ?></td>
    </tr>
    <tr>
      <td>Penghasilan</td>
	  <td>:</td>
      <td>Rp. <? echo $rupiah ?></td>
    </tr>


  </table>
 </thead>
 </table>
</div>
</div>
</div>
   <div class="box col-md-6">
    <div class="box-inner">
    <div class="box-header well" data-original-title="">
        <h2><i class="glyphicon glyphicon-book"></i> Nilai Ujian Nasional</h2>


    </div>
    <div class="box-content">

    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
  <table>

    
	<tr>
		<td>B. Indonesia</td>
		<td>:</td>
		<td><?php echo $myData['ind']; ?></td>
	</tr>
	<tr>
		<td>B. Inggris</td>
		<td>:</td>
		<td><?php echo $myData['ingg']; ?></td>
	</tr>
	<tr>
		<td>Matematika</td>
		<td>:</td>
		<td><?php echo $myData['mat']; ?></td>
	</tr>
	<tr>
		<td>IPA</td>
		<td>:</td>
		<td><?php echo $myData['ipa']; ?></td>
	</tr>
	<tr>
		<td>Jumlah Nilai</td>
		<td>:</td>
		<td><?php echo $myData['jumlah']; ?></td>
	</tr>

  </table>
 </thead>
 </table>
</div>

</div>
<br>
<img src="../photo/<?php echo $photo;?>" width="150" height="200" style="border:2px solid"/>

</div>

</div>




