<div id="main"> <a name="TemplateInfo"></a>
<?php
if(isset($_POST['kirim'])){
	$judul=$_POST['judul'];
	$isi=$_POST['isi'];
	$oleh=$_POST['oleh'];
	$terbit=$_POST['terbit'];
	$query=mysql_query("insert into tbl_berita(judul,isi,oleh,terbit) 
						values('$judul','$isi','$oleh','$terbit')");
						
	if($query){
		?>
			<?
echo "<meta http-equiv='refresh' content='0; url=admin.php?page=berita.view'>"; ?>
		<?php
	}else{
		echo mysql_query();
	}

}else{
	unset($_POST['kirim']);
}
?>
</div>