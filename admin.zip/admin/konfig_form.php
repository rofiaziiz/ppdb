<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<body>
	<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Konfigurasi Formulir Pendaftaran</h4>
    </ul>

    <div class="box-content">

<form action="?page=konfig_form_s" method="post" name="postform" class="form-horizontal">
		 <table class="table table-hover table-bordered table-stripped" width="100%">
			<thead>
			<tr>
				<th>No</th>
				<th>Kolom</th>
				<th>Tampilkan</th>
				<th>Sembunyikan</th>
				<th>Wajib Diisi</th>
				<th>Opsional</th>
			</tr>
			</thead>
			<tbody>
			<?php
$vh = 'form_daftar';
				$i=1;
				$no=0;
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE kelompok = 'form_daftar' ") or die(mysql_error());
					while ($tampil = mysql_fetch_array($sql)) {
					$id 	= $tampil['id'];
					$nilai_a 		= $tampil['nilai'];
					$nilai_b 		= $tampil['nilai_b'];
					$shortname 		= $tampil['shortname'];
					$no++;

				?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $shortname; ?></td>
		
				<td>
				<label class="switch">
                    <input type="radio" name="show[<? echo $id; ?>]" value="<? echo $id; ?>-1" <? if ($nilai_a == 1) { echo 'checked';} ?> />
                    <span></span>
                </label>
				</td>
				<td>
				<label class="switch">
                    <input type="radio" name="show[<? echo $id; ?>]" value="<? echo $id; ?>-0" <? if ($nilai_a == 0) { echo 'checked';} ?> />
                    <span></span>
                </label>
				</td>
				<td>
				<label class="switch">
                    <input type="radio" name="req[<? echo $id; ?>]" value="<? echo $id; ?>-1" <? if ($nilai_b == 1) { echo 'checked';} ?> />
                    <span></span>
                </label>
				</td>
				<td>
				<label class="switch">
                    <input type="radio" name="req[<? echo $id; ?>]" value="<? echo $id; ?>-0" <? if ($nilai_b == 0) { echo 'checked';} ?> />
                    <span></span>
                </label>
				</td>
                
				
			</tr>
			<?php	
			}
			?>
			
			</tbody>
		</table>
		<input type="submit" class="btn btn-primary m-t-15 waves-effect" value="Simpan" name="submit" />
	</form>
	
	
	<ul class="breadcrumb">
            <h4>Konfigurasi Sekolah</h4>
    </ul>

    <div class="box-content">

<form action="?page=konfig_form_s2" method="post" name="postform" class="form-horizontal">
		 <table class="table table-hover table-bordered table-stripped" width="100%">
			<thead>
			<tr>
				<th>No</th>
				<th>Kolom</th>
				<th>Tampilkan</th>
			</tr>
			</thead>
			<tbody>
			<?php

				$i=1;
				$no=0;
					$sql = mysql_query("SELECT * FROM konfigurasi WHERE kelompok = 'sekolah' ");
					while ($tampil = mysql_fetch_array($sql)) {
					$id 	= $tampil['id'];
					$sekolah 		= $tampil['nilai'];
					$no++;

				?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $tampil['shortname']; ?></td>
		
				<td>
					<input type="text" value="<?php echo $sekolah; ?>" name="jwb[]" id="urut" size="90">
				</td>
				
				<input type="hidden" name="id[]"  value="<?php echo $id; ?>">

			</tr>
			<?php	
			}
			?>
			
			</tbody>
		</table>
		<input type="submit" class="btn btn-primary m-t-15 waves-effect" value="Simpan" name="submit2" />
	</form>