<?php 
      include "../config/func.php";
  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
</head>
<body>
   <div id="content" class="col-lg-12 col-sm-12">
	<ul class="breadcrumb">
		<h4>Laporan Siswa Ditolak</h4>
    </ul>

  <div class="box-content">
<a href="pdf/dtolak.php"  target="_blank">Ekspor Ke PDF</a>
    <table class="table table-striped table-bordered bootstrap-datatable datatable responsive">
    <thead>
    <tr>
		<th>No.</th>
		<th>NISN</th>
		<th>Nama</th>
		<th>Asal Sekolah</th>
		<th>Jumlah Nilai</th>
		<th>Opsi</th>
    </tr>
    </thead>
					<tbody>
					<?php
						$get_limit = _get_limit_mhs();
						$tahun = date('Y');
							$sql = mysql_query("SELECT biodata.*, SUM(biodata.prestasi+biodata.jumlah) AS total
							FROM biodata


							where verifikasi = 'Sudah' AND date_format(biodata.tgl_daftar,'%Y') = '$tahun' 
							GROUP BY id_utama
							ORDER BY prestasi = 'u1' DESC,prestasi = 'u2' DESC,prestasi = 'u3' DESC,prestasi = 'u4' DESC, total DESC, ind DESC
							limit ".$get_limit.",100000 ");
		
									$no=0;
										while ($tampil = mysql_fetch_array($sql)) {
											$no++;
											echo '<tr>';
													echo '<td>'.$no.'.</td>';	//menampilkan nomor urut
													echo '<td>'.  $tampil['nisn'].'</td>';
													echo '<td>'.$tampil['nama'].'</td>';
													echo '<td>'.$tampil['sekolah'].'</td>';
													echo '<td>'.($tampil['jumlah']+$tampil['prestasi']).'</td>';
																							echo '<td>
						<a href="?page=detail&amp;id='.$tampil['id_utama'].'" class="btn btn-xs btn-default" ><i class="glyphicon glyphicon-zoom-in"></i></a>
						</td>';
											echo '</tr>';
										}
									?>
						</tbody>
    </table>
    </div>
    </div>
    </div>
    </div><!--/row-->
	
	

			
                    
            </div>
        </div>
    </div>
	
</body>