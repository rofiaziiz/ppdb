<head>
	<title>Laporan Arsip</title>
</head>
<body>
<div id="content" class="col-lg-12 col-sm-12">
<ul class="breadcrumb">
            <h4>Laporan Arsip</h4>
    </ul>
<?php
	$query = "SELECT DISTINCT date_format(tgl_daftar, ' %Y') as tahun FROM biodata";
	$hasil = mysql_query($query);
	echo "<ul>";
	while ($data = mysql_fetch_array($hasil))
	{
	echo "<li><a href='?page=viewarsip&amp;blnth=".$data['tahun']."'> PPDB Tahun ".$data['tahun']."</a>  </li>";
	} 
	echo "</ul>";
?>