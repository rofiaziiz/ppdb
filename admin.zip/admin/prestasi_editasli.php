<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<?php	
	if(isset($_POST['btnSimpan'])){

	$id 	= isset($_GET['id']) ?  $_GET['id'] : $_POST['id']; 
	$prestasi	=	$_POST['prestasi'];

	$mySql	= mysql_query("UPDATE biodata SET prestasi='$prestasi'
				  WHERE id_utama='$id'");

		if($mySql){
			?>
	<script type="text/javascript">
		alert("Data berhasil diubah...");
	</script>
	<?php
	echo "<meta http-equiv='refresh' content='0; url=admin.php?page=prestasi'>";
	?>
			
	<?php
	}
	exit;
	}	
	


if(isset($_GET['id'])){
$id = $_GET['id'];
	$cek = mysql_query("SELECT id_utama FROM biodata WHERE id_utama='$id'") or die(mysql_error());
# TAMPILKAN DATA LOGIN UNTUK DIEDIT
$mySql 	= "SELECT * FROM biodata WHERE id_utama='$id'";

$myQry 	= mysql_query($mySql)  or die ("Query ambil data salah : ".mysql_error());
$myData = mysql_fetch_array($myQry); 

	$nama			= isset($_POST['nama']) ? $_POST['nama'] : $myData['nama'];
	$prestasi		= isset($_POST['prestasi']) ? $_POST['prestasi'] : $myData['prestasi'];
	}
	?>
	<body>
<ul class="breadcrumb">
            <h4>Input Nilai Test x 40%</h4>
    </ul>
		<form method="post" name="postform" enctype="multipart/form-data" target="_self">
			<table class="table-list" width="100%">

				<tr>
					<td width="39">Nama</td>
					<td><?php echo $nama; ?></td>
				</tr>
               <tr>
                    <td>Nilai Test x 40%</td>
                    <td>
<select name="prestasi" >
<option></option>
<?php

$nilai = mysql_query("SELECT * FROM prestasi");
while($k=mysql_fetch_array($nilai)){
echo "<option value=\"$k[nilai]\">$k[tingkat]</option>\n";
}
?>
</select>
                </tr>
				<tr>
					<td>&nbsp;</td>
					<td><input name="btnSimpan"  type="submit" value=" Simpan "/></td>
				</tr>
			</table>
		</form>
	</body>
</html>
</div>
