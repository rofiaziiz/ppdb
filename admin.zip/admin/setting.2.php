<?php
require('html2fpdf.php');
ob_start();

?>

<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<body>
    <h1>Pengaturan</h1>
		<table class="table-list" width="100%">
			<tr bgcolor="#FF9900" style="color:#FFFFFF">
				<th>No.</th>
				<th>Nama</th>
				<th>nilai</th>
                <th>Opsi</th>
			</tr>
		<?php
			$sql = mysql_query("SELECT * FROM konfigurasi");
			$no=0;
			while ($tampil = mysql_fetch_array($sql)) {
				$no++;
				// gradasi warna
				if($no%2==1) { $warna=""; } else {$warna="#F5F5F5";}
				
				echo '<tr bgcolor='.$warna.'>';
						echo '<td>'.$no.'</td>';	//menampilkan nomor urut
						echo '<td>'.$tampil['nama'].'</td>';
						echo '<td>'.$tampil['nilai'].'</td>';
						echo '<td><a href="?page=setting.edit&amp;id='.$tampil['id'].'" class="btn btn-xs btn-success"> Edit</a> |
									<a href="?page=setting.hapus&amp;id='.$tampil['id'].'" onclick="return confirm(\'Yakin?\')">Hapus</a></td>';
						
							  	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
			}
		?>
		</table>
      
	</body>
</html>
</div>

<?php
// Output-Buffer in variable:
$html=ob_get_contents();
ob_end_clean();
$pdf=new HTML2FPDF();
$pdf->AddPage();
$pdf->WriteHTML($html);
if (preg_match("/MSIE/i", $_SERVER["HTTP_USER_AGENT"])){
    header("Content-type: application/PDF");
} else {
    header("Content-type: application/PDF");
    header("Content-Type: application/pdf");
}
$pdf->Output("sample2.pdf","I");

?>