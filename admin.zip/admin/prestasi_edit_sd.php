<div id="main"> <a name="TemplateInfo"></a>
<html>
	<head>
	</head>
	<?php	
	if(isset($_POST['btnSimpan'])){

	$id 	= isset($_GET['id']) ?  $_GET['id'] : $_POST['id']; 
	$prestasi	=	$_POST['prestasi'];
	$query = "UPDATE biodata_sd SET prestasi='$prestasi'
				  WHERE id_utama='$id'";

	$mySql	= mysql_query($query) or die ("Gagal query".mysql_error());
		if($mySql){
			?>
	<script type="text/javascript">
		alert("Data berhasil diubah...");
	</script>
	<?php
	echo "<meta http-equiv='refresh' content='0; url=admin.php?page=prestasi_sd'>";
	?>
			
	<?php
	}
	exit;
	}	
	


if(isset($_GET['id'])){
$id = $_GET['id'];
	$cek = mysql_query("SELECT id_utama FROM biodata WHERE id_utama='$id'") or die(mysql_error());
# TAMPILKAN DATA LOGIN UNTUK DIEDIT
$mySql 	= "SELECT * FROM biodata WHERE id_utama='$id'";

$myQry 	= mysql_query($mySql)  or die ("Query ambil data salah : ".mysql_error());
$myData = mysql_fetch_array($myQry); 

	$nama			= isset($_POST['nama']) ? $_POST['nama'] : $myData['nama'];
	$prestasi		= isset($_POST['prestasi']) ? $_POST['prestasi'] : $myData['prestasi'];
	}
	?>
	<body>
<ul class="breadcrumb">
            <h4>Input Piagam Prestasi</h4>
    </ul>
		<form method="post" name="postform" enctype="multipart/form-data" target="_self">
			<table class="table-list" width="100%">

				<tr>
					<td width="39">Nama</td>
					<td><?php echo $nama; ?></td>
				</tr>
               <tr>
                    <td>Hasil Nilai test</td>
                    <td>
						<td><input class="bg2" type="number_format" name="prestasi" /></td>
                </tr>
				<tr>
					<td>&nbsp;</td>
					<td><input name="btnSimpan"  type="submit" value=" Simpan "/></td>
				</tr>
			</table>
		</form>
	</body>
</html>
</div>
