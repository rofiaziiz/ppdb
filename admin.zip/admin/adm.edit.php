<div id="main"> <a name="TemplateInfo"></a>
<!DOCTYPE html>
<html>
	<head>
	<title>Edit Akun Admin</title>
	</head>

	<body>
	<?php
	include('../config/koneksi.php');

	//cek dahulu, jika tombol simpan di klik
	if(isset($_POST['btnSimpan'])){
		
		$id_admin		=	$_POST['id_admin'];
		$nama			=	$_POST['nama'];
		$telp			=	$_POST['telp'];
		
		# Validasi form, jika kosong sampaikan pesan error
		$pesanError = array();
		if(trim($id_admin)=="") {
			$pesanError[] = "error !";		
		}
		# VALIDASI ID_UDER DI DATABASE, jika sudah ada akan ditolak
		$id_admin	= $_POST['id_admin'];
		$sqlCek="SELECT * FROM tbl_admin WHERE id_admin='$id_admin' AND NOT(id_admin='$id_admin')";
		$qryCek=mysql_query($sqlCek) or die ("Eror Query".mysql_error()); 
		if(mysql_num_rows($qryCek)>=1){
			$pesanError[] = "Maaf, Judul <b> $data </b> sudah ada, ganti dengan yang lain";
		}
		
		# JIKA ADA PESAN ERROR DARI VALIDASI
		if (count($pesanError)>=1 ){
			echo "<div class='mssgBox'>";
			echo "<img src='images/attention.png'> <br><hr>";
				$noPesan=0;
				foreach ($pesanError as $indeks=>$pesan_tampil) { 
				$noPesan++;
					echo "&nbsp;&nbsp; $noPesan. $pesan_tampil<br>";	
				} 
			echo "</div> <br>"; 
		}else {
			# SIMPAN DATA KE DATABASE. Jika tidak menemukan pesan error, simpan data ke database	
					
			// Membaca Kode dari form hidden
			$id_admin	= $_POST['id_admin'];
			
		// SQL Simpan data ke tabel database
			$mySql	= mysql_query("UPDATE tbl_admin SET 
							id_admin='$id_admin',nama='$nama',telp='$telp' WHERE id_admin='$id_admin'");
			if($mySql){
				?>
				<blockquote>
				  <p></p>
				  <p>Data Anda berhasil disimpan...</p>
				  <p></p>
				</blockquote>
				<?php
			}
			exit;
		}	
	} // Penutup POST
			
	// Skrip membaca variable dari URL (Kode dikirim dari menu Edit)
	$id_admin	= isset($_GET['id_admin']) ?  $_GET['id_admin'] : $_POST['id_admin']; 

	# TAMPILKAN DATA LOGIN UNTUK DIEDIT
	$mySql 	= "SELECT * FROM tbl_admin WHERE id_admin='$id_admin'";
	$myQry 	= mysql_query($mySql)  or die ("Query ambil data salah : ".mysql_error());
	$myData = mysql_fetch_array($myQry); 

		# MEMBUAT NILAI DATA PADA FORM
		// Masukkan data ke dalam variabel, supaya bisa dipanggil di Form
		$id_admin 	= isset($_POST['id_admin']) ? $_POST['id_admin'] : $myData['id_admin'];
		$nama		= isset($_POST['nama']) ? $_POST['nama'] : $myData['nama'];
		$telp		= isset($_POST['telp']) ? $_POST['telp'] : $myData['telp'];
		
	?>

		<form action="" method="post" name="post" enctype="multipart/form-data" target="_self">
			<table class="table-list" width="100%" border="0" cellpadding="3" cellspacing="1">
				<tr>
					<td colspan="3" bgcolor="#F5F5F5"><b>Ubah Akun Admin</b></td>
				</tr>

				<tr>
					<td>Nama Admin</td>
					<td>&nbsp;</td>
					<td><input name="nama" type="text" value="<?php echo $nama; ?>" size="50" maxlength="100"></td>
				</tr>
                <tr>
					<td>ID Admin</td>
					<td>&nbsp;</td>
					<td><input name="nama" type="text" value="<?php echo $id_admin; ?>" size="50" maxlength="100"></td>
				</tr>
                <tr>
					<td>No. Telp</td>
					<td>&nbsp;</td>
					<td><input name="nama" type="text" value="<?php echo $telp; ?>" size="50" maxlength="100"></td>
				</tr>

				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td><input name="btnSimpan" type="submit" value=" Simpan "></td>
				</tr>	
			</table>
		</form>
	</body>
</html>
</div>